<?php
define('ADMIN_PASSWORD', '@@user@@');

session_start();
$blocklistFile = 'sampah.txt';

function getIpInfo($ip) {
    static $cache = [];
    if (isset($cache[$ip])) return $cache[$ip];
    $geoUrl = 'http://ip-api.com/json/' . urlencode($ip) . '?fields=status,message,country,countryCode';
    $curl = curl_init($geoUrl);
    curl_setopt_array($curl, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 5, CURLOPT_USERAGENT => 'IPBlockerPanel/1.0']);
    $resp = curl_exec($curl);
    curl_close($curl);
    $data = json_decode($resp, true);
    if ($data && $data['status'] == 'success') {
        $cache[$ip] = $data;
        return $data;
    }
    return ['country' => 'Unknown', 'countryCode' => null];
}
function getFlagEmoji($countryCode) {
    if (empty($countryCode)) return '🏳️';
    $countryCode = strtoupper($countryCode);
    return mb_convert_encoding('&#' . (0x1F1A5 + ord($countryCode[0])) . ';', 'UTF-8', 'HTML-ENTITIES') . mb_convert_encoding('&#' . (0x1F1A5 + ord($countryCode[1])) . ';', 'UTF-8', 'HTML-ENTITIES');
}

if (!empty($_POST['action'])) {
    header('Content-Type: application/json');
    if (empty($_SESSION['is_admin_logged_in'])) {
        echo json_encode(['status' => 'error', 'message' => 'Authentication required.']);
        exit();
    }
    $ip_sanitized = filter_var(trim($_POST['ip'] ?? ''), FILTER_VALIDATE_IP);

    if ($_POST['action'] === 'delete_ip' && $ip_sanitized) {
        $blockedIps = file($blocklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $newBlockedIps = array_diff($blockedIps, [$ip_sanitized]);
        file_put_contents($blocklistFile, implode(PHP_EOL, $newBlockedIps) . PHP_EOL, LOCK_EX);
        echo json_encode(['status' => 'success', 'message' => "IP $ip_sanitized deleted."]);
        exit();
    }
    if ($_POST['action'] === 'add_ip' && $ip_sanitized) {
        $blockedIps = file_exists($blocklistFile) ? file($blocklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
        if (!in_array($ip_sanitized, $blockedIps)) {
            file_put_contents($blocklistFile, $ip_sanitized . PHP_EOL, FILE_APPEND | LOCK_EX);
            $geo = getIpInfo($ip_sanitized);
            $geo['flag'] = getFlagEmoji($geo['countryCode']);
            echo json_encode(['status' => 'success', 'message' => "IP $ip_sanitized added.", 'ip' => $ip_sanitized, 'geo' => $geo]);
        } else {
            echo json_encode(['status' => 'exists', 'message' => "IP $ip_sanitized already exists."]);
        }
        exit();
    }
    echo json_encode(['status' => 'error', 'message' => 'Invalid action or IP.']);
    exit();
}

if (isset($_POST['password'])) {
    if ($_POST['password'] === ADMIN_PASSWORD) {
        $_SESSION['is_admin_logged_in'] = true;
        header('Location: block.php');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - IP Blocker</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>.fade-in { animation: fadeIn 0.5s ease; } @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }</style>
</head>
<body class="bg-gray-900 text-gray-200">
<?php if (empty($_SESSION['is_admin_logged_in'])): ?>
    <div class="flex items-center justify-center min-h-screen">
        <div class="w-full max-w-md p-8 space-y-6 bg-gray-800 rounded-lg shadow-md">
            <h1 class="text-2xl font-bold text-center">Admin Panel Login</h1>
            <form method="POST">
                <input type="password" name="password" placeholder="Masukkan Password" class="w-full px-4 py-2 mt-4 text-gray-800 bg-gray-700 text-gray-200 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                <button type="submit" class="w-full px-4 py-2 mt-6 font-bold text-white bg-blue-600 rounded-md hover:bg-blue-700">Login</button>
            </form>
        </div>
    </div>
<?php else: ?>
    <div class="container mx-auto p-4 md:p-8">
        <h1 class="text-3xl font-bold mb-6 text-center">Panel Manajemen IP Diblokir</h1>
        <div class="bg-gray-800 p-6 rounded-lg shadow-lg mb-8 fade-in">
            <h2 class="text-xl font-semibold mb-4">Tambah IP Manual</h2>
            <form id="add-ip-form" class="flex items-center space-x-4">
                <input type="text" id="ip-to-add" name="ip" placeholder="Masukkan IP, contoh: 8.8.8.8" class="flex-grow px-4 py-2 bg-gray-700 text-gray-200 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <button type="submit" class="px-6 py-2 font-bold text-white bg-green-600 rounded-md hover:bg-green-700"><i class="fas fa-plus mr-2"></i>Tambah</button>
            </form>
            <div id="add-ip-status" class="mt-3 text-sm"></div>
        </div>
        <div class="bg-gray-800 p-6 rounded-lg shadow-lg fade-in">
            <h2 class="text-xl font-semibold mb-4">Daftar IP Diblokir (<span id="ip-count">0</span>)</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-700">
                    <thead class="bg-gray-700"><th class="px-6 py-3 text-left text-xs font-medium uppercase">IP Address</th><th class="px-6 py-3 text-left text-xs font-medium uppercase">Negara</th><th class="px-6 py-3 text-center text-xs font-medium uppercase">Aksi</th></thead>
                    <tbody id="blocked-ip-list" class="divide-y divide-gray-700">
                    <?php
                    $blockedIps = file_exists($blocklistFile) ? file($blocklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
                    if (empty($blockedIps)) { echo '<tr id="no-ip-row"><td colspan="3" class="px-6 py-4 text-center text-gray-500">Tidak ada IP yang diblokir.</td></tr>'; }
                    else {
                        foreach ($blockedIps as $ip) {
                            if(empty(trim($ip))) continue;
                            $geo = getIpInfo($ip);
                            echo '<tr id="ip-row-'.str_replace('.', '-', $ip).'" class="fade-in">
                                <td class="px-6 py-4 font-mono">'.htmlspecialchars($ip).'</td>
                                <td class="px-6 py-4"><span class="mr-3 text-2xl">'.getFlagEmoji($geo['countryCode']).'</span> '.htmlspecialchars($geo['country']).'</td>
                                <td class="px-6 py-4 text-center"><button class="delete-ip-btn px-4 py-2 font-bold text-white bg-red-600 rounded-md hover:bg-red-700" data-ip="'.htmlspecialchars($ip).'"><i class="fas fa-trash-alt mr-1"></i> Hapus</button></td>
                            </tr>';
                        }
                    } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
    $(document).ready(function() {
        const updateIpCount = () => $('#ip-count').text($('#blocked-ip-list tr').not('#no-ip-row').length);
        updateIpCount();

        const handleAjax = (action, ip, button) => {
            button?.html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
            $.ajax({ url: 'block.php', type: 'POST', data: { action, ip }, dataType: 'json' })
            .done(function(res) {
                if (res.status === 'success') {
                    if (action === 'delete_ip') {
                        $('#ip-row-' + ip.replace(/\./g, '-')).fadeOut(500, function() { $(this).remove(); updateIpCount(); });
                    } else if (action === 'add_ip') {
                        $('#add-ip-status').text(res.message).addClass('text-green-500').removeClass('text-red-500');
                        $('#ip-to-add').val('');
                        const newRow = `<tr id="ip-row-${res.ip.replace(/\./g, '-')}" class="fade-in"><td class="px-6 py-4 font-mono">${res.ip}</td><td class="px-6 py-4"><span class="mr-3 text-2xl">${res.geo.flag}</span> ${res.geo.country}</td><td class="px-6 py-4 text-center"><button class="delete-ip-btn px-4 py-2 font-bold text-white bg-red-600 rounded-md hover:bg-red-700" data-ip="${res.ip}"><i class="fas fa-trash-alt mr-1"></i> Hapus</button></td></tr>`;
                        $('#blocked-ip-list').prepend(newRow);
                        if($('#no-ip-row').length) $('#no-ip-row').remove();
                        updateIpCount();
                    }
                } else {
                    alert('Gagal: ' + res.message);
                }
            })
            .fail(() => alert('Terjadi kesalahan pada server.'))
            .always(() => button?.html(action === 'delete_ip' ? '<i class="fas fa-trash-alt mr-1"></i> Hapus' : '<i class="fas fa-plus mr-2"></i>Tambah').prop('disabled', false));
        };

        $('#blocked-ip-list').on('click', '.delete-ip-btn', function() {
            if (confirm(`Yakin ingin menghapus IP ${$(this).data('ip')}?`)) handleAjax('delete_ip', $(this).data('ip'), $(this));
        });
        $('#add-ip-form').on('submit', function(e) { e.preventDefault(); handleAjax('add_ip', $('#ip-to-add').val(), $(this).find('button')); });
    });
    </script>
<?php endif; ?>
</body>
</html>