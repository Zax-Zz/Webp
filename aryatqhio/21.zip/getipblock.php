<?php
header('Content-Type: application/json');

$blocklistFile = 'sampah.txt';

function getClientIP() {
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) { $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; }
    elseif (isset($_SERVER['HTTP_CLIENT_IP'])) { $ip = $_SERVER['HTTP_CLIENT_IP']; }
    else { $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN'; }
    return explode(',', $ip)[0];
}

$visitorIp = getClientIP();

if ($visitorIp !== 'UNKNOWN') {
    $blockedIps = file_exists($blocklistFile) ? file($blocklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
    if (!in_array($visitorIp, $blockedIps)) {
        file_put_contents($blocklistFile, $visitorIp . PHP_EOL, FILE_APPEND | LOCK_EX);
        echo json_encode(['status' => 'success']);
        exit();
    }
}

echo json_encode(['status' => 'exists']);
?>